package com.zavvytech.pharmacy.ui.main;

import android.support.annotation.Nullable;

import com.zavvytech.pharmacy.backend.myApi.model.SQLGetItem;
import com.zavvytech.pharmacy.data.CompletionListener;
import com.zavvytech.pharmacy.data.SQLCallback;
import com.zavvytech.pharmacy.ui.BaseModelInformation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Uwais on 01/09/2017.
 */

class MainPresenter implements MainMvp.Presenter {

    private MainMvp.View currView;
    private Map<MainMvp.View, MainMvp.Model> models = new HashMap<>();
    private BaseModelInformation modelInformation;

    MainPresenter() {}

    @Override
    public void onCreate(BaseModelInformation modelInformation) {
        setAllModelInformations(modelInformation);
    }

    @Override
    public void onDestroy() {
        setAllModelInformations(null);
    }

    @Override
    public void getMoreItems(final MainMvp.View requestingView) {
        final MainMvp.Model model = models.get(requestingView);
        requestingView.setLoading(true);
        if (model.moreItemsExist()) {
            model.getMoreItems(new SQLCallback() {
                @Override
                public void onQueryFinished(List<SQLGetItem> result) {
                    super.onQueryFinished(result);
                    requestingView.updateItems(model.getItems());
                    requestingView.setLoading(false);
                }
            });
        } else {
            requestingView.setLoading(false);
        }
    }

    @Override
    public void performSearch(String search) {
        final MainMvp.View requestingView = currView;
        final MainMvp.Model model = models.get(requestingView);
        requestingView.setLoading(true);
        model.performSearch(search, new SQLCallback(){
            @Override
            public void onQueryFinished(List<SQLGetItem> result) {
                super.onQueryFinished(result);
                requestingView.updateItems(model.getItems());
                requestingView.setLoading(false);
            }
        });

    }

    @Override
    public void refreshItems() {
        final MainMvp.View requestingView = currView;
        final MainMvp.Model model = models.get(requestingView);
        requestingView.setLoading(true);
        model.performRefresh(new SQLCallback(){
            @Override
            public void onQueryFinished(List<SQLGetItem> result) {
                super.onQueryFinished(result);
                requestingView.updateItems(model.getItems());
                requestingView.setLoading(false);
            }
        });
    }

    @Override
    public void connectWithStripe() {
        getModel().connectWithStripe();
    }

    @Override
    public void setStripeIdWithAuthCode(String authCode, CompletionListener completionListener) {
        getModel().setStripeIdWithAuthCode(authCode, completionListener);
    }



    @Override
    public void setCurrentView(MainMvp.View currentView) {
        this.currView = currentView;
        addView(currentView);
    }

    @Override
    public void addView(MainMvp.View view) {
        if (!models.containsKey(view)) {
            models.put(view, new MainModel(view.getDefaultSQLQuery(), modelInformation));
        }
    }

    @Override
    public void removeView(MainMvp.View view) {
        models.remove(view);
    }

    private void setAllModelInformations(@Nullable BaseModelInformation modelInformation) {
        this.modelInformation = modelInformation;
        for (MainMvp.Model model : models.values()) {
            model.setModelInformation(modelInformation);
        }
    }

    private MainMvp.Model getModel() {
        return models.get(currView);
    }

}
