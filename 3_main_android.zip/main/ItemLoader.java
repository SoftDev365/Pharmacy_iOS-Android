package com.zavvytech.pharmacy.ui.main;

/**
 * Created by Uwais on 19/09/2017.
 */

public interface ItemLoader {
    void loadMoreItems();
}
