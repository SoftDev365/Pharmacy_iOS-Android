package com.zavvytech.pharmacy.ui.main.views;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.zavvytech.pharmacy.data.Item;

/**
 * Created by Uwais on 15/07/2017.
 */

public abstract class ViewHolderAbstractItem extends RecyclerView.ViewHolder {
    protected Item mItem;
    protected View mView;

    ViewHolderAbstractItem(View itemView) {
        super(itemView);
        mView = itemView;
    }

    public void setItem(Item item) {
        this.mItem = item;
        bindItem();
    }

    protected abstract void bindItem();

    public View getView() {
        return mView;
    }
}
