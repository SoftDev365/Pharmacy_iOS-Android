package com.zavvytech.pharmacy.ui.main.views;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.zavvytech.pharmacy.R;
import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.data.PharmacyBase;
import com.zavvytech.pharmacy.ui.UIUtils;
import com.zavvytech.pharmacy.ui.interfaces.PharmacyDisplayer;

/**
 * Created by Uwais on 13/07/2017.
 */

public abstract class ViewHolderAbstractPurchasedItem extends ViewHolderAbstractItem implements PharmacyDisplayer {
    final View mView;
    protected final ImageView brandImageView, deliveryImageView;
    protected final TextView brandTextView, expiryTextView, dispatchState, deliveryState;
    private PharmacyBase attachedPharmacy;

    ViewHolderAbstractPurchasedItem(View view, final MainViewAbstract.OnListFragmentInteractionListener listener) {
        super(view);
        centraliseInfoTableLines(view);
        mView = view;
        mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    listener.onListFragmentInteraction(mItem, v);
                }
            }
        });

        brandImageView = (ImageView) mView.findViewById(R.id.purchased_item_brand_image);
        brandTextView = (TextView) mView.findViewById(R.id.purchased_item_brand_text);
        expiryTextView = (TextView) mView.findViewById(R.id.purchased_item_expiry_text);
        dispatchState = (TextView) mView.findViewById(R.id.purchased_item_dispatch);
        deliveryState = (TextView) mView.findViewById(R.id.purchased_item_delivery);
        deliveryImageView = (ImageView) mView.findViewById(R.id.purchased_item_delivery_image);
    }

    @Override
    public void bindItem() {
        Item.setImgBitmap(brandImageView, mItem.getBrandImgRef());

        brandTextView.setText(mItem.getBrand());
        expiryTextView.setText(mItem.getExpiryDateAsString());
        if (mItem.getDispatchDate() > 0) {
            dispatchState.setText(String.format("Dispatch: %s", mItem.getDispatchDateAsString()));
        } else {
            dispatchState.setText("Dispatch: unknown");
        }
        if (mItem.getEstDeliveryDate() > 0) {
            deliveryState.setText(String.format("Delivery: %s", mItem.getEstDeliveryDateAsString()));
        } else {
            deliveryState.setText("Delivery: unknown");
        }
        if ((mItem.getDispatchDate() > 0 && mItem.getDispatchDate() < System.currentTimeMillis())
                || (mItem.getEstDeliveryDate() > 0 && mItem.getEstDeliveryDate() < System.currentTimeMillis())) {
            deliveryImageView.setImageResource(R.drawable.ic_van_transit_24dp);
        }
        attachPharmacyListener(pharmacyToAttach());
    }

    public void attachPharmacyListener(PharmacyBase pharmacy) {
        detachPharmacyListener();
        this.attachedPharmacy = pharmacy;
        if (pharmacy != null) {
            pharmacy.addObserver(this);
        }
    }

    public void detachPharmacyListener() {
        if (this.attachedPharmacy != null) {
            attachedPharmacy.deleteObserver(this);
            attachedPharmacy = null;
        }
    }

    private void centraliseInfoTableLines(View root) {
        TableLayout infoTable = (TableLayout) root.findViewById(R.id.purchased_item_info_table);
        int tableRows = infoTable.getChildCount();
        for(int i = 0; i < tableRows; i++) {
            View view = ((TableRow) infoTable.getChildAt(i)).getChildAt(1);
            int centeredPadding = view.getPaddingTop();
            if (view instanceof TextView) {
                centeredPadding = (int) (UIUtils.dpToPx(20) - ((TextView) view).getTextSize() / 2f);
            } else if (view instanceof LinearLayout) {
                TextView tv = (TextView) ((LinearLayout) view).getChildAt(0);
                centeredPadding = (int) (UIUtils.dpToPx(20) - tv.getTextSize() / 2f);
            }
            view.setPadding(view.getPaddingLeft(), centeredPadding, view.getPaddingRight(), view.getPaddingBottom());
        }
    }
}