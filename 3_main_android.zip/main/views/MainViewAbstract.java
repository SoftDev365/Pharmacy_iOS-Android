package com.zavvytech.pharmacy.ui.main.views;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zavvytech.pharmacy.R;
import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.ui.main.ItemLoader;
import com.zavvytech.pharmacy.ui.main.MainMvp;
import com.zavvytech.pharmacy.ui.main.adapters.AbstractItemRecyclerViewAdapter;

import java.util.List;

/**
 * Created by Uwais on 04/09/2017.
 */

public abstract class MainViewAbstract extends Fragment implements MainMvp.View, ItemLoader {

    protected int mColumnCount = 2;
    protected RecyclerView recyclerView;
    protected SwipeRefreshLayout swipeRefreshLayout;
    private OnListFragmentInteractionListener mListener;
    protected MainMvp.Presenter presenter;
    protected AbstractItemRecyclerViewAdapter recyclerViewAdapter;

    public AbstractItemRecyclerViewAdapter getAdapter() {
        return recyclerViewAdapter;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_item_list, container, false);
        // Set the adapter
        initialiseViews((SwipeRefreshLayout) view);
        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        presenter.addView(this);
        if (context instanceof OnListFragmentInteractionListener) {
            mListener = (OnListFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnListFragmentInteractionListener");
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) presenter.setCurrentView(this);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        presenter.removeView(this);
        mListener = null;
    }

    @Override
    public void setPresenter(MainMvp.Presenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public void updateItems(List<Item> items) {
        ((AbstractItemRecyclerViewAdapter) recyclerView.getAdapter()).setItems(items);
    }

    @Override
    public void loadMoreItems() {
        presenter.getMoreItems(this);
    }

    @Override
    public void setLoading(boolean loading) {
        swipeRefreshLayout.setRefreshing(loading);
    }

    protected void initialiseViews(SwipeRefreshLayout view) {
        Context context = view.getContext();
        swipeRefreshLayout = view;
        recyclerView = (RecyclerView) view.findViewById(R.id.list);
        if (mColumnCount <= 1) recyclerView.setLayoutManager(new LinearLayoutManager(context));
        else recyclerView.setLayoutManager(new GridLayoutManager(context, mColumnCount));
        recyclerView.setAdapter(getAdapter());
        getAdapter().loadMoreIfNeeded(0);

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                presenter.refreshItems();
            }
        });
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnListFragmentInteractionListener {
        void onListFragmentInteraction(Item item, View clicked);
    }
}
