package com.zavvytech.pharmacy.ui.main.views;

import com.zavvytech.pharmacy.data.ApiMethods;
import com.zavvytech.pharmacy.data.Database;
import com.zavvytech.pharmacy.data.MySQLQuery;
import com.zavvytech.pharmacy.ui.main.MainMvp;
import com.zavvytech.pharmacy.ui.main.adapters.MyPurchasedItemRecyclerViewAdapter;

/**
 * Created by Uwais on 20/09/2017.
 */

public class MainViewBought extends MainViewAbstract {

    public static MainViewBought newInstance(MainViewAbstract.OnListFragmentInteractionListener listener, MainMvp.Presenter presenter) {
        MainViewBought mainViewBought = new MainViewBought();
        mainViewBought.setPresenter(presenter);
        mainViewBought.mColumnCount = 1;
        mainViewBought.recyclerViewAdapter = new MyPurchasedItemRecyclerViewAdapter(0, listener, mainViewBought);
        return mainViewBought;
    }

    @Override
    public MySQLQuery getDefaultSQLQuery() {
        return new MySQLQuery(null, 0, Long.MAX_VALUE, Integer.MAX_VALUE, 0, null, Database.getInstance().getSignedInUser().getUid(), null, ApiMethods.DEFAULT_LIMIT, Long.MAX_VALUE);

    }

}
