package com.zavvytech.pharmacy.ui.main.views;

import com.zavvytech.pharmacy.data.ApiMethods;
import com.zavvytech.pharmacy.data.Database;
import com.zavvytech.pharmacy.data.MySQLQuery;
import com.zavvytech.pharmacy.ui.main.MainMvp;
import com.zavvytech.pharmacy.ui.main.adapters.MyPurchasedItemRecyclerViewAdapter;

/**
 * Created by Uwais on 20/09/2017.
 */

public class MainViewSold extends MainViewAbstract {

    public static MainViewSold newInstance(MainViewAbstract.OnListFragmentInteractionListener listener, MainMvp.Presenter presenter) {
        MainViewSold mainViewSold = new MainViewSold();
        mainViewSold.setPresenter(presenter);
        mainViewSold.mColumnCount = 1;
        mainViewSold.recyclerViewAdapter = new MyPurchasedItemRecyclerViewAdapter(3, listener, mainViewSold);
        return mainViewSold;
    }

    @Override
    public MySQLQuery getDefaultSQLQuery() {
        return new MySQLQuery(null, 0, Long.MAX_VALUE, Integer.MAX_VALUE, 0, null, "", Database.getInstance().getSignedInUser().getUid(), ApiMethods.DEFAULT_LIMIT, Long.MAX_VALUE);
    }
}
