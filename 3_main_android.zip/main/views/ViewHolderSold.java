package com.zavvytech.pharmacy.ui.main.views;

import android.view.View;
import android.widget.TextView;

import com.zavvytech.pharmacy.R;
import com.zavvytech.pharmacy.data.Pharmacy;
import com.zavvytech.pharmacy.data.PharmacyBase;

import java.util.Observable;

/**
 * Created by Uwais on 13/07/2017.
 */

public class ViewHolderSold extends ViewHolderAbstractPurchasedItem {
    private final TextView buyerAddressTextView;

    public ViewHolderSold(View view, final MainViewAbstract.OnListFragmentInteractionListener listener) {
        super(view, listener);
        buyerAddressTextView = (TextView) mView.findViewById(R.id.purchased_item_buyer_address_text);
    }

    public static int getLayoutResource() {
        return R.layout.fragment_purchased_item_sold;
    }

    @Override
    public void update(Observable o, Object arg) {
        buyerAddressTextView.setText(Pharmacy.getAddressAsString(((PharmacyBase) o)));
    }

    @Override
    public PharmacyBase pharmacyToAttach() {
        return mItem == null ? null : mItem.getBuyer();
    }

    @Override
    public String toString() {
        return super.toString() + " '" + brandTextView.getText() + "'";
    }
}
