package com.zavvytech.pharmacy.ui.main.views;

import android.graphics.Bitmap;
import android.support.v7.graphics.Palette;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.firebase.ui.storage.images.FirebaseImageLoader;
import com.google.firebase.storage.StorageReference;
import com.zavvytech.pharmacy.R;

/**
 * Created by Uwais on 15/07/2017.
 */

public class ViewHolderItem extends ViewHolderAbstractItem {
    private final TextView brandTextView;
    private final TextView expiryTextView;
    private final TextView priceTextView;
    private final ImageView brandImageView;
    private final MainViewAbstract.OnListFragmentInteractionListener listener;
    private static final Palette.Filter darkFilter = new Palette.Filter() {
        @Override
        public boolean isAllowed(int rgb, float[] hsl) {
            return hsl[2] < 0.7f;
        }
    };

    public ViewHolderItem(View view, final MainViewAbstract.OnListFragmentInteractionListener listener) {
        super(view);
        brandTextView = (TextView) view.findViewById(R.id.item_quick_view_brand);
        expiryTextView = (TextView) view.findViewById(R.id.item_quick_view_expiry);
        priceTextView = (TextView) view.findViewById(R.id.item_quick_view_price);
        brandImageView = (ImageView) view.findViewById(R.id.item_quick_view_image);
        this.listener = listener;
        mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != listener) {
                    // Notify the active callbacks interface (the activity, if the
                    // fragment is attached to one) that an item has been selected.
                    listener.onListFragmentInteraction(mItem, mView);
                }
            }
        });
    }

    @Override
    public String toString() {
        return super.toString() + " '" + brandTextView.getText() + ", " + expiryTextView + "'";
    }

    public void bindItem() {
        brandTextView.setText(mItem.getBrand());
        expiryTextView.setText(mItem.getExpiryDateAsString());
        priceTextView.setText(mItem.getPriceAsString());

        //clear current attempts at adding something
        if (brandImageView.getDrawable() != null) {
            Glide.clear(brandImageView);
            brandImageView.setImageDrawable(null);
        }
        Glide.with(getView().getContext().getApplicationContext())
                .using(new FirebaseImageLoader())
                .load(mItem.getBrandImgRef())
                .asBitmap()
                .listener(new RequestListener<StorageReference, Bitmap>() {
                    @Override
                    public boolean onException(Exception e, StorageReference model, Target<Bitmap> target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Bitmap resource, StorageReference model, Target<Bitmap> target, boolean isFromMemoryCache, boolean isFirstResource) {
                        setPaletteColourAsBackground(mView.findViewById(R.id.item_quick_view_info_layout), resource);
                        return false;
                    }
                })
                .placeholder(R.drawable.ic_pill_24dp)
                .into(brandImageView);
    }

    private void setPaletteColourAsBackground(final View backgroundView, Bitmap extractColour) {
        Palette.from(extractColour).addFilter(darkFilter).generate(new Palette.PaletteAsyncListener() {
            @Override
            public void onGenerated(Palette palette) {
                backgroundView.setBackgroundColor(palette.getDominantColor(0xffffff));
            }
        });
    }
}
