package com.zavvytech.pharmacy.ui.main.views;

import com.zavvytech.pharmacy.data.ApiMethods;
import com.zavvytech.pharmacy.data.MySQLQuery;
import com.zavvytech.pharmacy.ui.main.MainMvp;
import com.zavvytech.pharmacy.ui.main.adapters.MyItemRecyclerViewAdapter;

/**
 * Created by Uwais on 03/09/2017.
 */

public class MainViewBuy extends MainViewAbstract {

    public static MainViewBuy newInstance(MainViewAbstract.OnListFragmentInteractionListener listener, MainMvp.Presenter presenter) {
        MainViewBuy mainViewBuy = new MainViewBuy();
        mainViewBuy.setPresenter(presenter);
        mainViewBuy.mColumnCount = 2;
        mainViewBuy.recyclerViewAdapter = new MyItemRecyclerViewAdapter(listener, mainViewBuy);
        return mainViewBuy;
    }

    @Override
    public MySQLQuery getDefaultSQLQuery() {
        return new MySQLQuery(null, 0, Long.MAX_VALUE, Integer.MAX_VALUE, 0, null, null, null, ApiMethods.DEFAULT_LIMIT, Long.MAX_VALUE);
    }

}
