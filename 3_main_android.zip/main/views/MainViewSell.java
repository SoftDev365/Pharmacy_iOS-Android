package com.zavvytech.pharmacy.ui.main.views;

import com.zavvytech.pharmacy.data.ApiMethods;
import com.zavvytech.pharmacy.data.Database;
import com.zavvytech.pharmacy.data.MySQLQuery;
import com.zavvytech.pharmacy.ui.main.MainMvp;
import com.zavvytech.pharmacy.ui.main.adapters.MyItemRecyclerViewAdapter;

/**
 * Created by Uwais on 03/09/2017.
 */

public class MainViewSell extends MainViewAbstract {

    public static MainViewSell newInstance(MainViewAbstract.OnListFragmentInteractionListener listener, MainMvp.Presenter presenter) {
        MainViewSell mainViewSell = new MainViewSell();
        mainViewSell.setPresenter(presenter);
        mainViewSell.mColumnCount = 2;
        mainViewSell.recyclerViewAdapter = new MyItemRecyclerViewAdapter(listener, mainViewSell);
        return mainViewSell;
    }

    @Override
    public MySQLQuery getDefaultSQLQuery() {
        return new MySQLQuery(null, 0, Long.MAX_VALUE, Integer.MAX_VALUE, 0, null, null, Database.getInstance().getSignedInUser().getUid(), ApiMethods.DEFAULT_LIMIT, Long.MAX_VALUE);
    }

}
