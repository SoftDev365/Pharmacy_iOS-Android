package com.zavvytech.pharmacy.ui.main.views;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.TextView;

import com.zavvytech.pharmacy.R;
import com.zavvytech.pharmacy.data.Pharmacy;
import com.zavvytech.pharmacy.data.PharmacyBase;

import java.util.Observable;

/**
 * Created by Uwais on 13/07/2017.
 */

public class ViewHolderBought extends ViewHolderAbstractPurchasedItem {
    private final TextView sellerPhoneTextView;

    public ViewHolderBought(View view, final MainViewAbstract.OnListFragmentInteractionListener listener) {
        super(view, listener);
        sellerPhoneTextView = (TextView) mView.findViewById(R.id.purchased_item_seller_phone_text);
        sellerPhoneTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callPharmacy(v.getContext(), pharmacyToAttach());
            }
        });
    }

    public static int getLayoutResource() {
        return R.layout.fragment_purchased_item_bought;
    }

    @Override
    public void update(Observable o, Object arg) {
        sellerPhoneTextView.setText(((Pharmacy) o).getPhoneNo());
    }

    @Override
    public PharmacyBase pharmacyToAttach() {
        return mItem == null ? null : mItem.getSeller();
    }

    public void callPharmacy(Context context, PharmacyBase pharmacy) {
        if (pharmacy == null) return;
        Intent phoneIntent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", pharmacy.getPhoneNo(), null));
        context.startActivity(phoneIntent);
    }

    @Override
    public String toString() {
        return super.toString() + " '" + brandTextView.getText() + "'";
    }
}
