package com.zavvytech.pharmacy.ui.main;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import com.zavvytech.pharmacy.R;
import com.zavvytech.pharmacy.data.CompletionListener;
import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.data.SuccessWrapper;
import com.zavvytech.pharmacy.data.remote.Authentication;
import com.zavvytech.pharmacy.ui.BaseModelInformation;
import com.zavvytech.pharmacy.ui.activities.EditItemPage;
import com.zavvytech.pharmacy.ui.activities.ItemPage;
import com.zavvytech.pharmacy.ui.activities.SoldItemPage;
import com.zavvytech.pharmacy.ui.login.LoginActivity;
import com.zavvytech.pharmacy.ui.main.views.MainViewAbstract;
import com.zavvytech.pharmacy.ui.main.views.MainViewBought;
import com.zavvytech.pharmacy.ui.main.views.MainViewBuy;
import com.zavvytech.pharmacy.ui.main.views.MainViewSell;
import com.zavvytech.pharmacy.ui.main.views.MainViewSold;

/**
 * Created by Uwais on 01/09/2017.
 */

public class MainActivity extends AppCompatActivity implements MainMvp.Organiser,
        MainViewAbstract.OnListFragmentInteractionListener {

    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide
     * fragments for each of the sections. We use a
     * {@link FragmentPagerAdapter} derivative, which will keep every
     * loaded fragment in memory. If this becomes too memory intensive, it
     * may be best to switch to a
     * {@link android.support.v4.app.FragmentStatePagerAdapter}.
     */
    private SectionsPagerAdapter mSectionsPagerAdapter;
    /**
     * The {@link ViewPager} that will host the section contents.
     */
    private ViewPager mViewPager;

    FloatingActionButton fab;

    private Menu optionsMenu;
    private SearchView searchView;
    private ViewPager.OnPageChangeListener pageChangeListener;

    private MainMvp.Presenter presenter;
    private AlertDialog connectWithStripeDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BaseModelInformation modelInformation = new BaseModelInformation(PreferenceManager.getDefaultSharedPreferences(getApplicationContext()), this);
        presenter = new MainPresenter();
        presenter.onCreate(modelInformation);

        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        pageChangeListener = new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                switch (position) {
                    case 0:
                    case 1:
                    case 3:
                        setFabImage(R.drawable.ic_search_white_24dp);
                        getFab().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                onOptionsItemSelected(optionsMenu.findItem(R.id.action_search));
                            }
                        });
                        break;
                    case 2:
                        setFabImage(R.drawable.ic_add_white_24dp);
                        getFab().setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                createNewItem();
                            }
                        });
                        break;
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        };
        mViewPager.addOnPageChangeListener(pageChangeListener);
        mViewPager.setCurrentItem(1);


        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
        receiveStripeIntent(getIntent());
    }

    protected void onResume() {
        super.onResume();
        Authentication.getInstance().setAuthStateChangeListener(new Authentication.AuthStateChangeListener() {
            boolean startingLogin = false;

            @Override
            public void onAuthStateChanged(Authentication auth) {
                if (auth.getSignedInUser() != null) {
                    startingLogin = false;
                    //Should already have been signed in
                } else {
                    if (!startingLogin) {
                        startingLogin = true;
                        Intent backToLogin = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(backToLogin);
                        finish();
                    }
                }
            }
        });
    }

    @Override
    public void onListFragmentInteraction(Item item, View clicked) {
        int tab = mViewPager.getCurrentItem();
        //TODO change to new View classes
        if (tab == 0) {
            launchActivityWithAnimation(item, clicked.findViewById(R.id.purchased_item_brand_image), ItemPage.class);
        } else if (tab == 1) {
            launchActivityWithAnimation(item, clicked.findViewById(R.id.item_quick_view_image), ItemPage.class);
        } else if (tab == 2) {
            launchActivityWithAnimation(item, clicked.findViewById(R.id.item_quick_view_image), EditItemPage.class);
        } else if (tab == 3) {
            launchActivityWithAnimation(item, clicked.findViewById(R.id.purchased_item_brand_image), SoldItemPage.class);
        }
    }

    private void receiveStripeIntent(Intent intent) {
        if (intent.getData() != null && intent.getData().getQueryParameter("code") != null) {
            String authCode = intent.getData().getQueryParameter("code");
            presenter.setStripeIdWithAuthCode(authCode, new CompletionListener() {
                @Override
                public void onComplete(SuccessWrapper successWrapper) {
                    if (connectWithStripeDialog != null && connectWithStripeDialog.isShowing()) {
                        connectWithStripeDialog.dismiss();
                    }
                    createNewItem();
                }
            });
        }
    }

    @Override
    protected void onDestroy() {
        presenter.onDestroy();
        mViewPager.removeOnPageChangeListener(pageChangeListener);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        //TODO are you sure?
    }

    @Override
    public void launchNewItem() {
        Intent intent = new Intent(MainActivity.this, EditItemPage.class);
        startActivity(intent);
    }

    private void createNewItem() {
        if (!connectStripeIfNeeded()) {
            launchNewItem();
        }
    }

    private boolean connectStripeIfNeeded() {
        if (!Authentication.getInstance().hasStripeAccountId()) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

            final View dialogLayout = getLayoutInflater().inflate(R.layout.connect_to_stripe_popup, null);

            // set dialog message
            alertDialogBuilder
                    .setView(dialogLayout)
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });

            // create alert dialog
            connectWithStripeDialog = alertDialogBuilder.create();
            connectWithStripeDialog.show();

            ImageButton connectWithStripeBut = (ImageButton) dialogLayout.findViewById(R.id.connect_with_stripe_but);
            connectWithStripeBut.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    presenter.connectWithStripe();
                    dialogLayout.findViewById(R.id.connect_loading_spinner).setVisibility(View.VISIBLE);
                }
            });
            return true;
        }
        return false;
    }

    private void launchActivityWithAnimation(Item item, View viewToAnimate, Class activityToOpen) {
        Intent intent = new Intent(MainActivity.this, activityToOpen);
        intent.putExtra(Item.ITEM_KEY, item);
        ActivityOptionsCompat options = ActivityOptionsCompat.
                makeSceneTransitionAnimation(this, viewToAnimate, "brand_image_transition");
        startActivity(intent, options.toBundle());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        optionsMenu = menu;

        // SEARCH HANDLER
        final MenuItem myActionMenuItem = menu.findItem(R.id.action_search);
        MenuItemCompat.setOnActionExpandListener(myActionMenuItem, new MenuItemCompat.OnActionExpandListener() {
            @Override
            public boolean onMenuItemActionExpand(MenuItem item) {
                return true;
            }

            @Override
            public boolean onMenuItemActionCollapse(MenuItem item) {
                presenter.performSearch("");
                return true;
            }
        });
        searchView = (SearchView) myActionMenuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                presenter.performSearch(query);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });
        return true;
    }


    public FloatingActionButton getFab() {
        return fab;
    }

    public void setFabImage(@DrawableRes int drawableRes) {
        getFab().setImageResource(drawableRes);
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    private class SectionsPagerAdapter extends FragmentPagerAdapter {

        MainViewAbstract[] fragments = new MainViewAbstract[getCount()];

        SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            if (fragments[position] != null) {
                return fragments[position];
            }
            MainViewAbstract frag;
            // getItem is called to instantiate the fragment for the given page.
            if (position == 0) {
                frag = MainViewBought.newInstance(MainActivity.this, presenter);
            } else if (position == 1) {
                frag = MainViewBuy.newInstance(MainActivity.this, presenter);
            } else if (position == 2) {
                frag = MainViewSell.newInstance(MainActivity.this, presenter);
            } else if (position == 3) {
                frag = MainViewSold.newInstance(MainActivity.this, presenter);
            } else {
                throw new IllegalArgumentException("Unexpected tab position number");
            }
            fragments[position] = frag;
            return frag;
        }

        @Override
        public int getCount() {
            return 4;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0: return "BOUGHT";
                case 1: return "BUY";
                case 2: return "SELL";
                case 3: return "SOLD";
                default: throw new IllegalArgumentException("Unexpected tab position number");
            }
        }

        MainViewAbstract getCurrentFragment() {
            int position =  mViewPager.getCurrentItem();
            if (position < fragments.length && position >= 0) {
                return fragments[position];
            }
            return null;
        }
    }

}
