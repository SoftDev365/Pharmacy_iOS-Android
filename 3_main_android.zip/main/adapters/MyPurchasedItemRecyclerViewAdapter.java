package com.zavvytech.pharmacy.ui.main.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.ui.interfaces.PharmacyDisplayer;
import com.zavvytech.pharmacy.ui.main.ItemLoader;
import com.zavvytech.pharmacy.ui.main.views.MainViewAbstract;
import com.zavvytech.pharmacy.ui.main.views.ViewHolderAbstractItem;
import com.zavvytech.pharmacy.ui.main.views.ViewHolderAbstractPurchasedItem;
import com.zavvytech.pharmacy.ui.main.views.ViewHolderBought;
import com.zavvytech.pharmacy.ui.main.views.ViewHolderSold;

/**
 * {@link RecyclerView.Adapter} that can display a {@link Item} and makes a call to the
 * specified {@link MainViewAbstract.OnListFragmentInteractionListener}.
 */
public class MyPurchasedItemRecyclerViewAdapter extends AbstractItemRecyclerViewAdapter {

    private final int tabNo;

    public MyPurchasedItemRecyclerViewAdapter(int tabNo, MainViewAbstract.OnListFragmentInteractionListener interactionListener, ItemLoader itemLoader) {
        super(interactionListener, itemLoader);
        this.tabNo = tabNo;
    }

    @Override
    public ViewHolderAbstractPurchasedItem onCreateViewHolder(ViewGroup parent, int viewType) {
        if (tabNo == 0) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(ViewHolderBought.getLayoutResource(), parent, false);
            return new ViewHolderBought(view, interactionListener);
        } else if (tabNo == 3) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(ViewHolderSold.getLayoutResource(), parent, false);
            return new ViewHolderSold(view, interactionListener);
        } else {
            throw new RuntimeException("Unexpected tab number in onCreateViewHolder()");
        }
    }

    @Override
    public void onBindViewHolder(final ViewHolderAbstractItem holder, int position) {
        holder.setItem(mValues.get(position));
        loadMoreIfNeeded(position);
    }

    @Override
    public void onViewAttachedToWindow(ViewHolderAbstractItem holder) {
        super.onViewAttachedToWindow(holder);
        ((ViewHolderAbstractPurchasedItem) holder).attachPharmacyListener(((PharmacyDisplayer) holder).pharmacyToAttach());
    }

    @Override
    public void onViewDetachedFromWindow(ViewHolderAbstractItem holder) {
        super.onViewDetachedFromWindow(holder);
        ((ViewHolderAbstractPurchasedItem) holder).detachPharmacyListener();
    }
}
