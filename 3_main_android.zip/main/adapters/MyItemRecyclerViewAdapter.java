package com.zavvytech.pharmacy.ui.main.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;

import com.zavvytech.pharmacy.R;
import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.ui.main.ItemLoader;
import com.zavvytech.pharmacy.ui.main.views.MainViewAbstract;
import com.zavvytech.pharmacy.ui.main.views.ViewHolderAbstractItem;
import com.zavvytech.pharmacy.ui.main.views.ViewHolderItem;

/**
 * {@link RecyclerView.Adapter} that can display a {@link Item} and makes a call to the
 * specified {@link MainViewAbstract.OnListFragmentInteractionListener}.
 */
public class MyItemRecyclerViewAdapter extends AbstractItemRecyclerViewAdapter {

    private int maxPosition = -1;

    public MyItemRecyclerViewAdapter(MainViewAbstract.OnListFragmentInteractionListener listener, ItemLoader itemLoader) {
        super(listener, itemLoader);
    }

    @Override
    public ViewHolderItem onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_item_object, parent, false);
        return new ViewHolderItem(view, interactionListener);
    }

    @Override
    public void onBindViewHolder(final ViewHolderAbstractItem holder, int position) {
        holder.setItem(mValues.get(position));
        setAnimation(holder.getView(), position);
        loadMoreIfNeeded(position);
    }

    private void setAnimation(View mView, int position) {
        if (position > maxPosition) {
            mView.startAnimation(AnimationUtils.loadAnimation(mView.getContext(), R.anim.fade_up));
            maxPosition = position;
        }
    }

}
