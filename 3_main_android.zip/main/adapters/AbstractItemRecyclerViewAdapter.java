package com.zavvytech.pharmacy.ui.main.adapters;

import android.support.v7.widget.RecyclerView;

import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.ui.main.ItemLoader;
import com.zavvytech.pharmacy.ui.main.views.MainViewAbstract;
import com.zavvytech.pharmacy.ui.main.views.ViewHolderAbstractItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Uwais on 15/07/2017.
 */

public abstract class AbstractItemRecyclerViewAdapter extends RecyclerView.Adapter<ViewHolderAbstractItem> {

    final MainViewAbstract.OnListFragmentInteractionListener interactionListener;
    List<Item> mValues;
    private ItemLoader itemLoader;

    AbstractItemRecyclerViewAdapter(MainViewAbstract.OnListFragmentInteractionListener interactionListener, ItemLoader itemLoader) {
        this.interactionListener = interactionListener;
        this.mValues = new ArrayList<>();
        this.itemLoader = itemLoader;
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public void loadMoreIfNeeded(int position) {
        if (position >= getItemCount() - 1) {
            itemLoader.loadMoreItems();
        }
    }

    public void setItems(List<Item> items) {
        this.mValues = items;
        this.notifyDataSetChanged();
    }

}
