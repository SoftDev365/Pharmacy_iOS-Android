package com.zavvytech.pharmacy.ui.main;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.annotation.Nullable;

import com.google.firebase.auth.FirebaseUser;
import com.zavvytech.pharmacy.BuildConfig;
import com.zavvytech.pharmacy.backend.myApi.model.SQLGetItem;
import com.zavvytech.pharmacy.data.ApiMethods;
import com.zavvytech.pharmacy.data.CompletionListener;
import com.zavvytech.pharmacy.data.DataUtils;
import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.data.MySQLQuery;
import com.zavvytech.pharmacy.data.SQLCallback;
import com.zavvytech.pharmacy.data.remote.Authentication;
import com.zavvytech.pharmacy.ui.BaseModelInformation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static com.zavvytech.pharmacy.data.SharedPrefStrings.STRIPE_STATE_UUID;

/**
 * Created by Uwais on 01/09/2017.
 */

class MainModel implements MainMvp.Model {

    private MySQLQuery query;
    private boolean noMoreItems = false;
    @Nullable
    private BaseModelInformation modelInformation;
    private List<Item> items = new ArrayList<>();
    private static final String CLIENT_ID =  BuildConfig.DEBUG ? "ca_ASOPSsjyDsjKFTzKZcVO2oH1MDZh38mP" : "ca_ASOPst5JEKmjFZxXCZT2aZP6FPGf9mPA";

    MainModel(MySQLQuery query, BaseModelInformation modelInformation) {
        this.query = query;
        setModelInformation(modelInformation);
    }

    @Override
    public void setModelInformation(@Nullable BaseModelInformation modelInformation) {
        this.modelInformation = modelInformation;
    }

    @Override
    public void performSearch(String search, SQLCallback sqlCallback) {
        query.setSearch(search);
        query.setMaxItemID(Long.MAX_VALUE);
        items.clear();
        noMoreItems = false;
        performQuery(sqlCallback);
    }

    @Override
    public boolean moreItemsExist() {
        return !noMoreItems;
    }

    @Override
    public void getMoreItems(SQLCallback sqlCallback) {
        if (!noMoreItems) {
            performQuery(sqlCallback);
        } else {
            sqlCallback.onQueryFinished(Collections.<SQLGetItem>emptyList());
        }
    }

    @Override
    public void performRefresh(SQLCallback sqlCallback) {
        performSearch(query.getSearch(), sqlCallback);
    }

    private void performQuery(final SQLCallback sqlCallback) {
        ApiMethods.getInstance().getItems(query, new SQLCallback(){
            @Override
            public void onQueryFinished(List<SQLGetItem> result) {
                super.onQueryFinished(result);
                noMoreItems = result.size() < query.getLimit();
                items.addAll(DataUtils.sqlItemListToItemList(result));
                for (SQLGetItem sqlItem : result) {
                    query.setMaxItemID(Math.min(query.getMaxItemID(), sqlItem.getItemId()));
                }
                sqlCallback.onQueryFinished(result);
            }

            @Override
            public void onAddFinished() {
                super.onAddFinished();
                sqlCallback.onAddFinished();
            }

            @Override
            public void onError(String reason) {
                super.onError(reason);
                sqlCallback.onError(reason);
            }
        });
    }

    @Override
    public void connectWithStripe() {
        FirebaseUser signedInUser = Authentication.getInstance().getSignedInUser();
        if (signedInUser == null) {
            //TODO show error msg - redirect to login - not sure how this happened
            return;
        }

        SharedPreferences.Editor edit = modelInformation.getSharedPreferences().edit();
        String stateUUID = UUID.randomUUID().toString() + "-_-" + signedInUser.getUid();
        edit.putString(STRIPE_STATE_UUID, stateUUID);
        edit.apply();
        String authURL = "https://connect.stripe.com/oauth/authorize?response_type=code&client_id=" + CLIENT_ID +
                "&scope=read_write&state=" + stateUUID;
        Intent authorizeAccount = new Intent(Intent.ACTION_VIEW, Uri.parse(authURL));
        modelInformation.getActivity().startActivity(authorizeAccount);
    }

    @Override
    public List<Item> getItems() {
        return items;
    }

    @Override
    public void setStripeIdWithAuthCode(String authCode, CompletionListener completionListener) {
        ApiMethods.getInstance().setStripeIdWithAuthCode(authCode, completionListener);
    }
}
