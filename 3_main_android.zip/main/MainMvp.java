package com.zavvytech.pharmacy.ui.main;

import com.zavvytech.pharmacy.data.CompletionListener;
import com.zavvytech.pharmacy.data.Item;
import com.zavvytech.pharmacy.data.MySQLQuery;
import com.zavvytech.pharmacy.data.SQLCallback;
import com.zavvytech.pharmacy.ui.BaseModelInformation;

import java.util.List;

/**
 * Created by Uwais on 31/08/2017.
 */

public interface MainMvp {
    interface Model {
        void setModelInformation(BaseModelInformation modelInformation);
        void performSearch(String search, SQLCallback sqlCallback);
        boolean moreItemsExist();
        void getMoreItems(SQLCallback sqlCallback);
        void performRefresh(SQLCallback sqlCallback);
        void connectWithStripe();
        List<Item> getItems();
        void setStripeIdWithAuthCode(String authCode, CompletionListener completionListener);
    }

    interface Presenter {
        void onCreate(BaseModelInformation modelInformation);
        void onDestroy();
        void getMoreItems(View requestingView);
        void performSearch(String search);
        void refreshItems();
        void connectWithStripe();
        void setStripeIdWithAuthCode(String authCode, CompletionListener completionListener);
        void setCurrentView(MainMvp.View currentView);
        void addView(View view);
        void removeView(View view);
    }

    interface Organiser {
        void launchNewItem();
    }

    interface View {
        void setPresenter(Presenter presenter);
        void updateItems(List<Item> items);
        void setLoading(boolean loading);
        MySQLQuery getDefaultSQLQuery();
    }
}
