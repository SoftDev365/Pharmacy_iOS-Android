package com.zavvytech.pharmacy.ui.main;

import android.app.Activity;
import android.content.SharedPreferences;

import com.zavvytech.pharmacy.ui.BaseModelInformation;

/**
 * Created by Uwais on 31/08/2017.
 */

public class MainModelInformation extends BaseModelInformation {

    public MainModelInformation(SharedPreferences sharedPreferences, Activity activity) {
        super(sharedPreferences, activity);
    }
}
