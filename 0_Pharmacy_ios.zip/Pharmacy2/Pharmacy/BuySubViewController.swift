//
//  BuySubViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit

import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

import MessageUI
import CoreLocation

import Stripe

class BuySubViewController: UIViewController, UITextFieldDelegate, MFMailComposeViewControllerDelegate {
    
    let GlobalVar = Global()
    
    @IBOutlet weak var Pay_Button: UIButton!
    
    @IBOutlet weak var Payment_View: UIView!
    
    @IBOutlet weak var Payment_Small_View: UIView!
    @IBOutlet weak var Payment_Large_View: UIView!
    
    @IBOutlet weak var Large_UseImageView: UIImageView!
    @IBOutlet weak var Large_NoneImageView: UIImageView!
    
    //Strip Payment
    //======================================================
    @IBOutlet weak var Stripe_View: STPPaymentCardTextField!
    //======================================================
    
    
    // Images
    @IBOutlet weak var brand_Image: UIImageView!
    @IBOutlet weak var batch_Image: UIImageView!
    @IBOutlet weak var expiry_Image: UIImageView!
    
    // Labels
    @IBOutlet weak var brand_Label: UILabel!
    @IBOutlet weak var price_Label: UILabel!
    @IBOutlet weak var quantity_Label: UILabel!
    
    // Details
    @IBOutlet weak var purchaseDate_Label: UILabel!
    @IBOutlet weak var description_Label: UILabel!
    
    @IBOutlet weak var tradingName_Label: UILabel!
    @IBOutlet weak var address1_Label: UILabel!
    @IBOutlet weak var town_Label: UILabel!
    @IBOutlet weak var postcode_Label: UILabel!
    
    @IBOutlet weak var phoneNum_Label: UILabel!
    
    
    
    @IBOutlet weak var LargeSecondHide_View: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        brand_Image.layer.borderColor = UIColor.white.cgColor
        brand_Image.layer.borderWidth = 1
        batch_Image.layer.borderColor = UIColor.white.cgColor
        batch_Image.layer.borderWidth = 1
        expiry_Image.layer.borderColor = UIColor.white.cgColor
        expiry_Image.layer.borderWidth = 1
        
        
        if g_BoughtORBuy_Flag == true {
            Pay_Button.isHidden = true
        } else {
            Pay_Button.isHidden = false
        }
        
        
        Payment_Small_View.layer.cornerRadius = 3.0
        Payment_Large_View.layer.cornerRadius = 3.0
        
        Large_UseImageView.image = UIImage(named: "purchase_check.png")
        Large_NoneImageView.image = UIImage(named: "purchase_none.png")
        
        
        Payment_View.fadeOut(duration: 0.0, delay: 0.0)
        Payment_Large_View.fadeOut(duration: 0.0, delay: 0.0)
        
        // email delegate
        if !MFMailComposeViewController.canSendMail() {
            //print("Mail services are not available")
            return
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        LargeSecondHide_View.isHidden = false
        
        if g_BoughtORBuy_Flag == true { //false: Buy, true: Bought
            showAllData_Bought()
        }
            
        else {
            showAllData_Buy()
        }
    }
    
    func showAllData_Bought() {
        
        let storage = FIRStorage.storage()
        var reference1: FIRStorageReference!
        var reference2: FIRStorageReference!
        var reference3: FIRStorageReference!
        
        reference1 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Bought_Array[g_sel_index_1].sellerId)/\(g_Bought_Array[g_sel_index_1].itemUUID)/brand.jpg")
        reference1.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.brand_Image.image = UIImage(named: "Pill.png")
            } else {
                // Data for "images/island.jpg" is returned
                self.brand_Image?.sd_setShowActivityIndicatorView(true)
                self.brand_Image?.sd_setIndicatorStyle(.gray)
                self.brand_Image?.sd_setImage(with: url)
            }
        }
        reference2 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Bought_Array[g_sel_index_1].sellerId)/\(g_Bought_Array[g_sel_index_1].itemUUID)/batch.jpg")
        reference2.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.batch_Image.image = UIImage(named: "Pill.png")
            } else {
                self.batch_Image?.sd_setShowActivityIndicatorView(true)
                self.batch_Image?.sd_setIndicatorStyle(.gray)
                self.batch_Image?.sd_setImage(with: url)
            }
        }
        reference3 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Bought_Array[g_sel_index_1].sellerId)/\(g_Bought_Array[g_sel_index_1].itemUUID)/expiry.jpg")
        reference3.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.expiry_Image.image = UIImage(named: "Pill.png")
            } else {
                self.expiry_Image?.sd_setShowActivityIndicatorView(true)
                self.expiry_Image?.sd_setIndicatorStyle(.gray)
                self.expiry_Image?.sd_setImage(with: url)
            }
        }
        
        brand_Label.text = g_Bought_Array[g_sel_index_1].brand
        
        let poundString = String(format: "%.02f", Double(g_Bought_Array[g_sel_index_1].price) / 100)
        price_Label.text = "£\(poundString)"     //170,00
        
        quantity_Label.text = g_Bought_Array[g_sel_index_1].quantity
        
        Get_PhoneNum(sellerID: g_Bought_Array[g_sel_index_1].sellerId, completionHandler: { success in
            if success != "" {
                self.phoneNum_Label.text = success
            } else {
                self.phoneNum_Label.text = success //""
            }
        })
        
        Get_Location(sellerID: g_Bought_Array[g_sel_index_1].sellerId, completionHandler: { success in
            if success == true {
                self.tradingName_Label.text = g_location.tradingName
                self.address1_Label.text = g_location.address1
                self.town_Label.text = g_location.town
                self.postcode_Label.text = g_location.postcode
            } else {
            }
        })
    }
    
    func showAllData_Buy() {
        
        let storage = FIRStorage.storage()
        var reference1: FIRStorageReference!
        var reference2: FIRStorageReference!
        var reference3: FIRStorageReference!
        
        
        reference1 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Buy_Array[g_sel_index_2].sellerId)/\(g_Buy_Array[g_sel_index_2].itemUUID)/brand.jpg")
        reference1.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.brand_Image.image = UIImage(named: "Pill.png")
                
            } else {
                // Data for "images/island.jpg" is returned
                self.brand_Image?.sd_setShowActivityIndicatorView(true)
                self.brand_Image?.sd_setIndicatorStyle(.gray)
                self.brand_Image?.sd_setImage(with: url)
            }
        }
        reference2 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Buy_Array[g_sel_index_2].sellerId)/\(g_Buy_Array[g_sel_index_2].itemUUID)/batch.jpg")
        reference2.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.batch_Image.image = UIImage(named: "Pill.png")
                
            } else {
                self.batch_Image?.sd_setShowActivityIndicatorView(true)
                self.batch_Image?.sd_setIndicatorStyle(.gray)
                self.batch_Image?.sd_setImage(with: url)
            }
        }
        reference3 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Buy_Array[g_sel_index_2].sellerId)/\(g_Buy_Array[g_sel_index_2].itemUUID)/expiry.jpg")
        reference3.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.expiry_Image.image = UIImage(named: "Pill.png")
                
            } else {
                self.expiry_Image?.sd_setShowActivityIndicatorView(true)
                self.expiry_Image?.sd_setIndicatorStyle(.gray)
                self.expiry_Image?.sd_setImage(with: url)
            }
        }
        
        
        brand_Label.text = g_Buy_Array[g_sel_index_2].brand
        
        let poundString = String(format: "%.02f", Double(g_Buy_Array[g_sel_index_2].price) / 100)
        price_Label.text = "£\(poundString)"     //170,00
        
        quantity_Label.text = g_Buy_Array[g_sel_index_2].quantity
        
        Get_PhoneNum(sellerID: g_Buy_Array[g_sel_index_2].sellerId, completionHandler: { success in
            if success != "" {
                self.phoneNum_Label.text = success
            } else {
                self.phoneNum_Label.text = success //""
            }
        })
        
        Get_Location(sellerID: g_Buy_Array[g_sel_index_2].sellerId, completionHandler: { success in
            if success == true {
                self.tradingName_Label.text = g_location.tradingName
                self.address1_Label.text = g_location.address1
                self.town_Label.text = g_location.town
                self.postcode_Label.text = g_location.postcode
            } else {
            }
        })
    }
    
    
    
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
        
    }
    
    // Payment View ================================================
    @IBAction func onTappedPaymentButton(_ sender: Any) {
        
        Check_customerID(completionHandler: { success in
            if success != "" {
                
                
                self.Large_UseImageView.image = UIImage(named: "purchase_check.png")
                self.Large_NoneImageView.image = UIImage(named: "purchase_none.png")
                
                self.LargeSecondHide_View.isHidden = false
                
                
                self.Payment_Small_View.fadeIn(duration: 0.0, delay: 0.0)
                self.Payment_Large_View.fadeOut(duration: 0.0, delay: 0.0)
                self.Payment_View.fadeIn(duration: 0.3, delay: 0.3)
                
            } else {
                //ProgressHUD.dismiss()
                
                self.Large_UseImageView.image = UIImage(named: "purchase_check.png")
                self.Large_NoneImageView.image = UIImage(named: "purchase_none.png")
                
                self.LargeSecondHide_View.isHidden = true
                
                self.Payment_Small_View.fadeOut(duration: 0.0, delay: 0.0)
                self.Payment_Large_View.fadeIn(duration: 0.0, delay: 0.0)
                self.Payment_View.fadeIn(duration: 0.3, delay: 0.3)
                
                
                
                print("you should purchase using new card id")
            }
        })
        
        
        
        
    }
    
    // Payment Small View
    @IBAction func onTappedUseSavedCardButton(_ sender: Any) {
        
//        Large_UseImageView.image = UIImage(named: "purchase_check.png")
//        Large_NoneImageView.image = UIImage(named: "purchase_none.png")
        
        Payment_Large_View.fadeIn(duration: 0.3, delay: 0.3)
        Payment_Small_View.fadeOut(duration: 0.0, delay: 0.0)
    }
    
    @IBAction func onTappedSmallCancelButton(_ sender: Any) {
        Payment_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    @IBAction func onTappedLargeCancelButton(_ sender: Any) {
        Payment_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    
    
    
    
    
    
    
    //================================================================================
    // check customerID in firebase
    //
    func Check_customerID(completionHandler: @escaping (_ success: String) -> ()) {
                
                
        let currentUser = FIRAuth.auth()?.currentUser
        let Ref = FIRDatabase.database().reference().child("readOnlyUserIDs").child((currentUser?.uid)!)
        
        var handle: UInt = 0
        handle = Ref.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if snapshot.exists() {
                
                Ref.removeObserver(withHandle: handle)
                
                if let dict = snapshot.value as?  NSDictionary {
                    //print(dict)
                    
                    if let customerID = dict["customerID"] as? String {
                        completionHandler(customerID)
                    } else {
                        completionHandler("")
                    }
                    
                } else {
                    completionHandler("")
                }
            }
            else {
                //print("snapshot exists")
                completionHandler("")
            }
        })
    }
    
    //===== True call
    @IBAction func onTappedSmallPurchaseButton(_ sender: Any) {
        
        //ProgressHUD.show("purchasing...")
        Check_customerID(completionHandler: { success in
            if success != "" {
                self.tryToPostPurchase(idToken: g_current_fireToken, apiver: 2147483647, itemId: g_Buy_Array[g_sel_index_2].itemId, saveCardDetail: false, buyerAcctToken: "")
                
            } else {
                //ProgressHUD.dismiss()
                print("you should purchase using new card id")
            }
        })
        
    }
    
    //tok_1BAOVzEZ25h26rwioy1nDqfp   type Stripe token
    @IBAction func onTappedLargePurchaseButton(_ sender: Any) {
        
        let cardParams = STPCardParams()
       
        
        cardParams.number = Stripe_View.cardNumber
        cardParams.expMonth = Stripe_View.expirationMonth
        cardParams.expYear = Stripe_View.expirationYear
        cardParams.cvc = Stripe_View.cvc
        
        if STPCardValidator.validationState(forCard: cardParams) == .valid {
            
            STPAPIClient.shared().createToken(withCard: cardParams) { token, error in
                
                guard let stripeToken = token else {
                    NSLog("Error creating token: %@", error!.localizedDescription);
                    return
                }
                
                print("\(token!)")
                
                if self.Large_UseImageView.image == UIImage(named: "purchase_check.png") {
                    self.tryToPostPurchase(idToken: g_current_fireToken, apiver: 2147483647, itemId: g_Buy_Array[g_sel_index_2].itemId, saveCardDetail: true, buyerAcctToken: "\(token!)")
                } else {
                    self.tryToPostPurchase(idToken: g_current_fireToken, apiver: 2147483647, itemId: g_Buy_Array[g_sel_index_2].itemId, saveCardDetail: false, buyerAcctToken: "\(token!)")
                }
                
                
                
                // TODO: send the token to your server so it can create a charge
//                    let alert = UIAlertController(title: "Welcome to Stripe", message: "Token created: \(stripeToken)", preferredStyle: .alert)
//                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//                    self.present(alert, animated: true, completion: nil)
            }
        }
    }
    

//    @IBAction func onTappedLargePurchaseButton(_ sender: Any) {
//     
//        purchaseWith()
//
//    }

    // src_1BAOavEZ25h26rwi880YbuUG   type Stripe token
    func purchaseWith() {
        
        let stripCard = STPCardParams()
        
        stripCard.number = Stripe_View.cardNumber
        stripCard.cvc = Stripe_View.cvc
        stripCard.expMonth = Stripe_View.expirationMonth
        stripCard.expYear = Stripe_View.expirationYear
        let sourceParams = STPSourceParams.cardParams(withCard: stripCard)

        STPAPIClient.shared().createSource(with: sourceParams) { (source, error) in
            if let s = source, s.flow == .none && s.status == .chargeable {
                
                print(g_current_fireToken)
                print(g_Buy_Array[g_sel_index_2].itemId)
                
                //self.createBackendChargeWithSourceID(s.stripeID)
                
                if self.Large_UseImageView.image == UIImage(named: "purchase_check.png") {
                    self.tryToPostPurchase(idToken: g_current_fireToken, apiver: 2147483647, itemId: g_Buy_Array[g_sel_index_2].itemId, saveCardDetail: true, buyerAcctToken: s.stripeID)
                    print(s.stripeID)
                } else {
                    self.tryToPostPurchase(idToken: g_current_fireToken, apiver: 2147483647, itemId: g_Buy_Array[g_sel_index_2].itemId, saveCardDetail: false, buyerAcctToken: s.stripeID)
                    print(s.stripeID)
                }
                
                
            }else{
            }
        }
    }
    
    // Payment Large View
    @IBAction func onTappedLargeUseButton(_ sender: Any) {
        
        //===== false call
        
        if Large_UseImageView.image == UIImage(named: "purchase_check.png") {
            Large_UseImageView.image = UIImage(named: "purchase_none.png")
        } else {
            Large_UseImageView.image = UIImage(named: "purchase_check.png")
        }
        
//        Large_UseImageView.image = UIImage(named: "purchase_check.png")
        Large_NoneImageView.image = UIImage(named: "purchase_none.png")
    }
    @IBAction func onTappedLargeNoneButton(_ sender: Any) {
        
        //===== True call
        
        Large_NoneImageView.image = UIImage(named: "purchase_none.png")
        //Large_NoneImageView.image = UIImage(named: "purchase_check.png")
        Large_UseImageView.image = UIImage(named: "purchase_none.png")
        
        Payment_Large_View.fadeOut(duration: 0.3, delay: 0.3)
        Payment_Small_View.fadeIn(duration: 0.0, delay: 0.0)
    }
    
    
    
    
    
    // UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // User finished typing (hit return): hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            self.Payment_Large_View.frame.origin.y -= 50
        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField.tag {
        case 1:
            self.Payment_Large_View.frame.origin.y += 50
        default: break
        }
    }
    
    //################################################################
    @IBAction func onTappedGotoMapButton(_ sender: Any) {
        
        let address = "\(g_location.address1), \(g_location.town), \(g_location.postcode)"
        //let address = "\(g_location.tradingName), \(g_location.address1), \(g_location.postcode)"
        
        print(address)
        
        let encodedAddress = address.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)
        let directionUrl = "http://maps.apple.com/?daddr=\(encodedAddress!)"
        
        print(directionUrl)
        if (UIApplication.shared.canOpenURL(URL(string:"http://maps.apple.com")!)) {
            UIApplication.shared.openURL(URL(string: directionUrl)!)
        } else {
            NSLog("Can't use Apple Maps");
        }

        

        
//        var geocoder = CLGeocoder()
//        geocoder.geocodeAddressString(address) {
//            placemarks, error in
//            let placemark = placemarks?.first
//            let lat = placemark?.location?.coordinate.latitude
//            let lon = placemark?.location?.coordinate.longitude
//            print("Lat: \(lat), Lon: \(lon)")
//            
//            //Apple Map
//            let directionUrl = "http://maps.apple.com/?daddr=\(lat),\(lon)&dirflg=w"
//            
//            if (UIApplication.shared.canOpenURL(URL(string:"http://maps.apple.com")!)) {
//                UIApplication.shared.openURL(URL(string: directionUrl)!)
//            } else {
//                NSLog("Can't use Apple Maps");
//            }
//        }
    }
    
    @IBAction func onTappedPhoneCallButton(_ sender: Any) {
        let ph = phoneNum_Label.text
//        if let phoneURL = NSURL(string: "tel:\(ph)") {
//            let alert = UIAlertController(title: ("Call \(ph) ?"), message: nil, preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "Call", style: .default, handler: { (action) in
//                UIApplication.shared.openURL(phoneURL as URL)
//            }))
//            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
//            self.present(alert, animated: true, completion: nil)
//        }
        
        
        //let ph = "+44207228076"
        print(ph!)
        
        if let phoneURL = NSURL(string: "tel://\(ph!)") {
            let alert = UIAlertController(title: ("Call \(ph!) ?"), message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Call", style: .default, handler: { (action) in
                UIApplication.shared.openURL(phoneURL as URL)
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    @IBAction func onTappedReportButton(_ sender: Any) {
        let composeVC = MFMailComposeViewController()
        composeVC.mailComposeDelegate = self
        
        // Configure the fields of the interface.
        composeVC.setToRecipients(["support@zavvytech.co.uk"])
        composeVC.setSubject("\(g_Bought_Array[g_sel_index_1].sellerId)")
        composeVC.setMessageBody("", isHTML: false)
        
        // Present the view controller modally.
        self.present(composeVC, animated: true, completion: nil)
    }
    func mailComposeController(_ controller: MFMailComposeViewController,
                               didFinishWith result: MFMailComposeResult, error: Error?) {
        // Check the result or perform other tasks.
        
        // Dismiss the mail compose view controller.
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    //====================================================================================================
    // tryPost purchase Item
    //
    
    func tryToPostPurchase(idToken: String, apiver: Int, itemId: String, saveCardDetail: Bool, buyerAcctToken: String) {
        
        let params: NSDictionary = [:]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show("purchasing...")
        var header = String()
        if (buyerAcctToken == "") {
            header  = "\(GlobalVar.PurchaseItem)\(apiver)/\(itemId)/\(saveCardDetail)"
        }else{
            header  = "\(GlobalVar.PurchaseItem)\(apiver)/\(itemId)/\(saveCardDetail)/?buyerAcctToken=\(buyerAcctToken)"
        }
        
        serviceObj.servicePostMethodWithAPIHeaderValue2(apiValue: GlobalVar.APIHEADER, headerValue: header, parameters: params, fields: idToken, completion: {(responseObject) in
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["successful"] as! Bool
                if returnTemp == false {
                    ProgressHUD.dismiss()
                    self.Payment_View.fadeOut(duration: 0.3, delay: 0.3)
                    self.Pay_Button.isHidden = true
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                    
                } else {
                    ProgressHUD.dismiss()
                    self.Payment_View.fadeOut(duration: 0.3, delay: 0.3)
                    self.Pay_Button.isHidden = true
                    
                    g_sel_index_3 = -2
                    //self.navigationController?.popViewController(animated: true)
                }
            }
            else {
                ProgressHUD.dismiss()
            }
        })
    }
    
}
