//
//  SignUpViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/26/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import JVFloatLabeledTextField

import Firebase
import FirebaseAuth

import Foundation


class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    
    
    @IBOutlet weak var Email_Text: JVFloatLabeledTextField!
    @IBOutlet weak var Email_UI_Text: UITextField!
    
    @IBOutlet weak var Password_Text: JVFloatLabeledTextField!
    @IBOutlet weak var Password_UI_Text: UITextField!
    
    @IBOutlet weak var ConfrimPassword_Text: JVFloatLabeledTextField!
    @IBOutlet weak var ConfrimPassword_UI_Text: UITextField!
    
    @IBOutlet weak var Email_UnderView: UIView!
    @IBOutlet weak var Password_UnderView: UIView!
    @IBOutlet weak var ConfrimPassword_UnderView: UIView!
    
     @IBOutlet weak var Round_Signup_Button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Text Delegate
        Email_UI_Text.delegate = self
        Password_UI_Text.delegate = self
        ConfrimPassword_UI_Text.delegate = self
        // tags
        Email_UI_Text.tag = 1
        Password_UI_Text.tag = 2
        ConfrimPassword_UI_Text.tag = 3
        
        // Round Button
        Round_Signup_Button.layer.cornerRadius = 3.0
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        Email_Text.text = g_email
        Password_Text.text = g_password
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // User finished typing (hit return): hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            Email_UnderView.backgroundColor = UIColor.init(red: 239.0/255.0, green: 47.0/255.0, blue: 106.0/255.0, alpha: 1.0)
        case 2:
            Password_UnderView.backgroundColor = UIColor.init(red: 239.0/255.0, green: 47.0/255.0, blue: 106.0/255.0, alpha: 1.0)
        case 3:
            ConfrimPassword_UnderView.backgroundColor = UIColor.init(red: 239.0/255.0, green: 47.0/255.0, blue: 106.0/255.0, alpha: 1.0)
        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField.tag {
        case 1:
            Email_UnderView.backgroundColor = UIColor.gray
        case 2:
            Password_UnderView.backgroundColor = UIColor.gray
        case 3:
            ConfrimPassword_UnderView.backgroundColor = UIColor.gray

        default: break
        }
    }

    @IBAction func onTappedSignupButton(_ sender: Any) {
        
        var goFlag: Bool = true
        
        if Email_Text.text == "" {
            UIApplication.shared.windows.first?.makeToast("Please insert your email.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if Email_Text.text?.isEmail == false {
            UIApplication.shared.windows.first?.makeToast("Email type is not valid.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if Password_Text.text == "" {
            UIApplication.shared.windows.first?.makeToast("Please insert your password.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if (Password_Text.text?.characters.count)! < 8 {
            UIApplication.shared.windows.first?.makeToast("You must input 8 length password.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if ConfrimPassword_Text.text == "" {
            UIApplication.shared.windows.first?.makeToast("Please insert your confirm password.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if ConfrimPassword_Text.text != Password_Text.text {
            UIApplication.shared.windows.first?.makeToast("Password don't match with confirm password.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        
        //=================================================================================================
        if goFlag {
            
            ProgressHUD.show("SignUp...")
            FIRAuth.auth()?.createUser(withEmail: self.Email_Text.text!, password: self.Password_Text.text!) { (user, error) in
                
                if error == nil
                {
                    DispatchQueue.main.async {
                        
                        ProgressHUD.dismiss()
                        
                        // replace gphc
                        let currentUser = FIRAuth.auth()?.currentUser
                        currentUser?.getTokenForcingRefresh(true) {idToken, error in
                            if let error = error {
                                
                                self.view.makeToast("Internet is busy.", duration: 3.0, position: .bottom)
                                // Handle error
                                return;
                            }
                            
                            g_ByLogin_GphcSignUp = false
                            
                            g_current_fireToken = idToken!
                            
                            DispatchQueue.main.async {
                                self.performSegue(withIdentifier: StorySegues.FromSignUpToGPhcSubmit.rawValue, sender: self)
                            }
                        }

                        
                    }
                }
                else
                {
                    
                    ProgressHUD.dismiss()
                    
                    let alertController = UIAlertController(title: "Alert!", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            }
            
            
        }
        
        
     }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
