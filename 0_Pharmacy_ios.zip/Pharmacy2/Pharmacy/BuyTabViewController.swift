//
//  BuyTabViewController.swift
//  Pharmacy
//
//  Created by LEE on 9/2/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit

import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage
import FirebaseStorageUI

class BuyTabViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UISearchBarDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var BuyCollectionView: UICollectionView!
    
    
    let GlobalVar = Global()
    
    var refreshControl:UIRefreshControl!
    
    var filtered:[Bought_Info] = []
    var searchActive : Bool = false
    
    
    var small_DataArry:[Bought_Info] = []
    var Reload_Flag: Bool = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.hideKeyboardWhenTappedAround()
        
        // Search Bar
        searchBar.delegate = self
        self.searchBar.backgroundImage = UIImage()
        
        // Collection View
        BuyCollectionView.delegate = self
        BuyCollectionView.dataSource = self
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.tintColor = UIColor.gray
        
        //self.refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        let attributes = [NSForegroundColorAttributeName: UIColor.gray, NSFontAttributeName: UIFont.systemFont(ofSize: 12)]
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh", attributes: attributes)
        
        self.refreshControl.addTarget(self, action: #selector(loadData), for: UIControlEvents.valueChanged)
        BuyCollectionView!.addSubview(refreshControl)
        
        // Loading datas
        loadData()
        
    }
    
    func loadData() {

        g_Buy_Array.removeAll()
        
        //9223372036854775807
        //print(Int.max)
        //code to execute during refresher
        let currentUser = FIRAuth.auth()?.currentUser
        GetItems_Buy(idToken: g_current_fireToken, apiver: 1, maxItemID: Int.max, expiryStart: 0, expiryEnd: Int.max, priceH: 2147483647, priceL: 0, limit: 6)
        stopRefresher()
        BuyCollectionView.reloadData()
    }
    
    //Reload Data====================================================================================
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        //Bottom Refresh
        
        if scrollView == BuyCollectionView{
            
            if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height)
            {
                //print("came to last row")
                
                if searchActive == false {
                    //print("test")
                    
                    if Reload_Flag {
                        let currentUser = FIRAuth.auth()?.currentUser
                        GetItems_Buy(idToken: g_current_fireToken, apiver: 1, maxItemID: Int(small_DataArry[5].itemId)!, expiryStart: 0, expiryEnd: Int.max, priceH: 2147483647, priceL: 0, limit: 6)
                    }
                }
            }
        }
    }
    
    
    func stopRefresher() {
        self.refreshControl.endRefreshing()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(filtered.count == 0){
            searchActive = false;
            searchBar.text = ""
        } else {
            searchActive = true;
        }
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onTappedLogOutButton(_ sender: Any) {
        
        if g_ByLogin_GphcSignUp ==  true {
            var viewControllers = self.navigationController?.viewControllers
            viewControllers?.removeLast(3)
            self.navigationController?.setViewControllers(viewControllers!, animated: true)
            return
        }
        
        if g_ByLoginSignUp == false {
            self.navigationController?.popViewController(animated: true)
        } else {
            var viewControllers = self.navigationController?.viewControllers
            viewControllers?.removeLast(4)
            self.navigationController?.setViewControllers(viewControllers!, animated: true)
        }
    }
    
//    var item_images1 = [UIImage(named: "Collection_1"), UIImage(named: "Collection_2")]
//    var item_name1 = ["Blue iron1", "Audio tech1"]
//    var item_date1 = ["28 Sep 2018", "22 Feb 2019"]
//    var item_price1 = ["£25.01", "£170.01"]
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
         if searchActive == false {
            return g_Buy_Array.count
        } else {
            return filtered.count
        }
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BuyCollectionCell", for: indexPath as IndexPath) as! BuyCollectionCell
        
        cell.backgroundColor =  UIColor.clear
        
        //Cell shape
        cell.Round_View.layer.borderColor = UIColor.white.cgColor
        cell.Round_View.layer.borderWidth = 2
        
        if searchActive == false {
            
            DispatchQueue.main.async {
                
                cell.name.text = g_Buy_Array[indexPath.row].brand
                cell.date.text = GetStrDate(timestamp: g_Buy_Array[indexPath.row].expiryDateTime)
                
                let poundString = String(format: "%.02f", Double(g_Buy_Array[indexPath.row].price) / 100)
                cell.price.text = "£\(poundString)"     //170,00
                
                
                let storage = FIRStorage.storage()
                var reference: FIRStorageReference!
                reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Buy_Array[indexPath.row].sellerId)/\(g_Buy_Array[indexPath.row].itemUUID)/brand.jpg")
                
                cell.Image?.sd_setShowActivityIndicatorView(true)
                cell.Image?.sd_setIndicatorStyle(.gray)
                
                cell.Image?.sd_setImage(with: reference)
            }
        }
        
        else {
            DispatchQueue.main.async {
                
                cell.name.text = self.filtered[indexPath.row].brand
                cell.date.text = GetStrDate(timestamp: self.filtered[indexPath.row].expiryDateTime)
                
                let poundString = String(format: "%.02f", Double(self.filtered[indexPath.row].price) / 100)
                cell.price.text = "£\(poundString)"     //170,00
                
                
                let storage = FIRStorage.storage()
                var reference: FIRStorageReference!
                reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(self.filtered[indexPath.row].sellerId)/\(self.filtered[indexPath.row].itemUUID)/brand.jpg")
                cell.Image?.sd_setShowActivityIndicatorView(true)
                cell.Image?.sd_setIndicatorStyle(.gray)
                
                cell.Image?.sd_setImage(with: reference)
            }
            
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        
        let newCellWidth = 180 * ScreenWidth / 375
        let newCellHeight = 230 * ScreenWidth / 375
        
        return CGSize(width: newCellWidth, height: newCellHeight)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 3.5 * ScreenWidth / 375 - 1;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 3.5 * ScreenWidth / 375 - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    // MARK: - UICollectionViewDelegate protocol
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")
        
        if searchActive == false {
            g_sel_index_2 = indexPath.item
            g_BoughtORBuy_Flag = false //false: Buy, true: Bought
            self.performSegue(withIdentifier: StorySegues.FromBuyTabToBuySub.rawValue, sender: self)
        }
            
        else {
            if let search_index = g_Buy_Array.index(where: {$0.itemId == filtered[indexPath.item].itemId}) {
                g_sel_index_2 = search_index
                g_BoughtORBuy_Flag = false //false: Buy, true: Bought
                self.performSegue(withIdentifier: StorySegues.FromBuyTabToBuySub.rawValue, sender: self)
            }
        }
    }
    
    //================================================================================
    // Search delegate
    //
    //================================================================================
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchBar.text == "" {
            
            let count = g_Buy_Array.count
            filtered.removeAll()
            
            searchActive = false
            
            self.BuyCollectionView.reloadData()
            searchBar.resignFirstResponder()
            return
        }
//        
//        print(searchText)
//        let count = g_Buy_Array.count
//        
//        filtered.removeAll()
//        
//        for i in 0 ... count - 1 {
//            let temp: NSString = g_Buy_Array[i].brand as NSString
//            let range = temp.range(of: searchText, options: .caseInsensitive)
//            if range.location != NSNotFound {
//                filtered.append(g_Buy_Array[i])
//            }
//        }
//        
//        if(filtered.count == 0){
//            searchActive = false;
//        } else {
//            searchActive = true;
//        }
//        self.BuyCollectionView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        //searchBar.resignFirstResponder()
        //searchActive = false;
        
        if searchBar.text == "" {
            
            let count = g_Buy_Array.count
            filtered.removeAll()
            
            searchActive = false
            
            self.BuyCollectionView.reloadData()
            searchBar.resignFirstResponder()
            return
        }
        
        //print(searchBar.text)
        let count = g_Buy_Array.count
        
        filtered.removeAll()
        
        for i in 0 ... count - 1 {
            let temp: NSString = g_Buy_Array[i].brand as NSString
            let range = temp.range(of: searchBar.text!, options: .caseInsensitive)
            if range.location != NSNotFound {
                filtered.append(g_Buy_Array[i])
            }
        }
        
        if(filtered.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.BuyCollectionView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        //searchActive = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    
    
    
    //=========================================================================================
    //
    // Get GetItems for Buy
    //
    //=========================================================================================
    func GetItems_Buy(idToken: String, apiver: Int, maxItemID: Int, expiryStart: Int, expiryEnd: Int, priceH: Int, priceL: Int, limit:Int) {
        
        self.Reload_Flag = false
        
        searchActive = false
        filtered.removeAll()
        searchBar.text = ""
        
        self.small_DataArry.removeAll()
        //g_Buy_Array.removeAll()
        let serviceObj = ServiceClass()
        
        ProgressHUD.show("Loading...")
        serviceObj.serviceGetMethodWithAPIHeaderValue1(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.GetItems)\(apiver)/\(maxItemID)/\(expiryStart)/\(expiryEnd)/\(priceH)/\(priceL)/\(limit)", fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                if responseObject["items"] == nil {
                    ProgressHUD.dismiss()
                    //self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
                    return
                }
                
                let items_dict = responseObject["items"] as! NSArray
                if (items_dict != nil ) {
                    
                    for items_data in items_dict {
                        let dict = items_data as! [String: AnyObject]
                        
                        var temp: Bought_Info = Bought_Info(success: false, itemId: "", itemUUID: "", brand: "", description: "", expiryDateTime: "", price: -1, quantity: "", sellerId: "", buyerId: "", purchaseDate: "", dispatchDate: "", estDeliveryDate: "", uploadDate: "", lastEdited: "")
                        
                        temp.success    = dict["success"] as! Bool
                        temp.itemId     = dict["itemId"] as! String
                        temp.itemUUID   = dict["itemUUID"] as! String
                        temp.brand      = dict["brand"] as! String
                        
                        temp.description    = dict["description"] as! String
                        temp.expiryDateTime = dict["expiryDateTime"] as! String
                        temp.price          = dict["price"] as! Int
                        temp.quantity       = dict["quantity"] as! String
                        
                        temp.sellerId       = dict["sellerId"] as! String
                        //temp.buyerId        = dict["buyerId"] as! String
                        temp.purchaseDate   = dict["purchaseDate"] as! String
                        temp.dispatchDate   = dict["dispatchDate"] as! String
                        
                        temp.estDeliveryDate = dict["estDeliveryDate"] as! String
                        temp.uploadDate      = dict["uploadDate"] as! String
                        temp.lastEdited      = dict["lastEdited"] as! String
                        
                        self.small_DataArry.append(temp)
                        g_Buy_Array.append(temp)
                        //self.BuyCollectionView.reloadData()
                        
                    }
                    
                    if self.small_DataArry.count == limit {
                        self.Reload_Flag = true
                    } else {
                        self.Reload_Flag = false
                    }
                    
                    DispatchQueue.main.async {
                        ProgressHUD.dismiss()
                        self.BuyCollectionView.reloadData()
                    }
                    
                } else {
                }
            } else {
                ProgressHUD.dismiss()
                //self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
            }
        })
    }
    
    
}





