//
//  SoldTabViewController.swift
//  Pharmacy
//
//  Created by LEE on 9/2/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit

import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage


class SoldTabViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    
    let GlobalVar = Global()
    

    
    @IBOutlet weak var searchBar: UISearchBar!

    @IBOutlet weak var soldTableView: UITableView!
    
    
    var refreshControl:UIRefreshControl!
    
    var searchActive : Bool = false
    var filtered:[Bought_Info] = []
    
    
    var small_DataArry:[Bought_Info] = []
    var Reload_Flag: Bool = false
    let spinner = UIActivityIndicatorView(activityIndicatorStyle: .gray)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
 
        self.hideKeyboardWhenTappedAround()
        
        // Search Bar
        searchBar.delegate = self
        self.searchBar.backgroundImage = UIImage()
        
        soldTableView.delegate = self
        soldTableView.dataSource = self
        soldTableView.backgroundColor = UIColor.clear
        
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.tintColor = UIColor.gray
        
        //self.refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        let attributes = [NSForegroundColorAttributeName: UIColor.gray, NSFontAttributeName: UIFont.systemFont(ofSize: 12)]
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh", attributes: attributes)
        
        self.refreshControl.addTarget(self, action: #selector(loadData), for: UIControlEvents.valueChanged)
        soldTableView!.addSubview(refreshControl)
        
        //Tabel View Bottom Progress
        spinner.color = UIColor.darkGray
        spinner.hidesWhenStopped = true
        soldTableView.tableFooterView = spinner
        
        // Loading datas
        loadData()
        
    }
    
    func loadData() {
        //code to execute during refresher
        
        g_Sold_Array.removeAll()
        
        let currentUser = FIRAuth.auth()?.currentUser
        GetItems_Sold(idToken: g_current_fireToken, apiver: 1, maxItemID: Int.max, expiryStart: 0, expiryEnd: Int.max, priceH: 2147483647, priceL: 0, limit: 3, sellerID: (currentUser?.uid)!)
        stopRefresher()
        soldTableView.reloadData()
    }
    
    //Reload Data====================================================================================
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        //Bottom Refresh
        
        if scrollView == soldTableView{
            
            if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height)
            {
                //print("came to last row")
                
                if searchActive == false {
                    //print("test")
                    
                    if Reload_Flag {
                        
                        spinner.startAnimating()
                        
                        let currentUser = FIRAuth.auth()?.currentUser
                        GetItems_Sold(idToken: g_current_fireToken, apiver: 1, maxItemID: Int(small_DataArry[2].itemId)!, expiryStart: 0, expiryEnd: Int.max, priceH: 2147483647, priceL: 0, limit: 3, sellerID: (currentUser?.uid)!)
                    }
                }
            }
        }
    }

    
    func stopRefresher() {
        self.refreshControl.endRefreshing()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(filtered.count == 0){
            searchActive = false;
            searchBar.text = ""
        } else {
            searchActive = true;
        }
        
        if g_sel_index_4 == -2 {
            
            g_sel_index_4 = -1
            loadData()
        }
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func onTappedLogOutButton(_ sender: Any) {
        
        if g_ByLogin_GphcSignUp ==  true {
            var viewControllers = self.navigationController?.viewControllers
            viewControllers?.removeLast(3)
            self.navigationController?.setViewControllers(viewControllers!, animated: true)
            return
        }
        
        if g_ByLoginSignUp == false {
            self.navigationController?.popViewController(animated: true)
        } else {
            var viewControllers = self.navigationController?.viewControllers
            viewControllers?.removeLast(4)
            self.navigationController?.setViewControllers(viewControllers!, animated: true)
        }
    }
    
//    var data_images2 = [UIImage(named: "Collection_4"), UIImage(named: "Collection_5")]
//    var data_name2 = ["Braeburn", "minions handwarmers"]
//    var data_date2 = ["11 Aug 2017", "23 Dec 2022"]
//    var data_dispatch2 = ["unknown", "unknown"]
//    var data_delivery2 = ["unknown", "unknown"]
//    var data_address2 = ["Boots 6 Eve's Corner Danbury CHELMSFORD Essex CM34QF", "Boots 6 Eve's Corner Danbury CHELMSFORD Essex CM34QF"]
    
    //================================================================================
    // table delegate
    //
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchActive == false {
            return g_Sold_Array.count
        } else {
            return filtered.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SoldTableCell") as? SoldTableCell

        if searchActive == false {
            DispatchQueue.main.async {
                
                cell?.brand.text = g_Sold_Array[indexPath.row].brand
                cell?.date.text = GetStrDate(timestamp: g_Sold_Array[indexPath.row].expiryDateTime)
                cell?.Dispatch.text = "Dispatch: " + GetStrDate(timestamp: g_Sold_Array[indexPath.row].dispatchDate)
                cell?.Delivery.text = "Delivery: " + GetStrDate(timestamp: g_Sold_Array[indexPath.row].estDeliveryDate)
                
                Get_Location(sellerID: g_Sold_Array[indexPath.row].sellerId, completionHandler: { success in
                    if success == true {
                        cell?.address.text = "\(g_location.tradingName) \(g_location.address1) \(g_location.town) \(g_location.postcode)"
                    } else {
                        cell?.address.text = "unknown"
                    }
                })
                
                
                
                
                let storage = FIRStorage.storage()
                var reference: FIRStorageReference!
                reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sold_Array[indexPath.row].sellerId)/\(g_Sold_Array[indexPath.row].itemUUID)/brand.jpg")
                cell?.ProductImage?.sd_setShowActivityIndicatorView(true)
                cell?.ProductImage?.sd_setIndicatorStyle(.gray)
                
                cell?.ProductImage?.sd_setImage(with: reference)
            }
            
        }
            
            
        else {
            DispatchQueue.main.async {
                cell?.brand.text = self.filtered[indexPath.row].brand
                cell?.date.text = GetStrDate(timestamp: self.filtered[indexPath.row].purchaseDate)
                cell?.Dispatch.text = "Dispatch: " + GetStrDate(timestamp: self.filtered[indexPath.row].dispatchDate)
                cell?.Delivery.text = "Delivery: " + GetStrDate(timestamp: self.filtered[indexPath.row].estDeliveryDate)
                
                Get_Location(sellerID: self.filtered[indexPath.row].sellerId, completionHandler: { success in
                    if success == true {
                        cell?.address.text = "\(g_location.tradingName) \(g_location.address1) \(g_location.town) \(g_location.postcode)"
                    } else {
                        cell?.address.text = "unknown"
                    }
                })
                
                
                
                let storage = FIRStorage.storage()
                var reference: FIRStorageReference!
                reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(self.filtered[indexPath.row].sellerId)/\(self.filtered[indexPath.row].itemUUID)/brand.jpg")
                cell?.ProductImage?.sd_setShowActivityIndicatorView(true)
                cell?.ProductImage?.sd_setIndicatorStyle(.gray)
                
                cell?.ProductImage?.sd_setImage(with: reference)
            }
            
        }
        
        
        cell?.select_Button.tag  =  indexPath.row
        
        return cell!
    }
    
    //    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
    //    }
    
    //Select Table Buttons
    @IBAction func onTappedSoldSelectButton(_ sender: Any) {
        let index = (sender as! UIButton).tag
        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PickTableCell
        //print("select Button!")
        //g_Pick_Restaurant_Id = g_pickTable_Array[index].id
        
        if searchActive == false {
            g_sel_index_4 = index
            self.performSegue(withIdentifier: StorySegues.FromSoldTabToSoldSub.rawValue, sender: self)
        }
            
        else {
            if let search_index = g_Sold_Array.index(where: {$0.itemId == filtered[index].itemId}) {
                g_sel_index_4 = search_index
                self.performSegue(withIdentifier: StorySegues.FromSoldTabToSoldSub.rawValue, sender: self)
            }
        }
        
    }
    
    
    
    //================================================================================
    // Search delegate
    //
    //================================================================================
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchBar.text == "" {
            
            let count = g_Sold_Array.count
            filtered.removeAll()
            
            searchActive = false
            
            self.soldTableView.reloadData()
            searchBar.resignFirstResponder()
            return
        }
//
//        print(searchText)
//        let count = g_Sold_Array.count
//        
//        filtered.removeAll()
//        
//        for i in 0 ... count - 1 {
//            let temp: NSString = g_Sold_Array[i].brand as NSString
//            let range = temp.range(of: searchText, options: .caseInsensitive)
//            if range.location != NSNotFound {
//                filtered.append(g_Sold_Array[i])
//            }
//        }
//        
//        if(filtered.count == 0){
//            searchActive = false;
//        } else {
//            searchActive = true;
//        }
//        self.soldTableView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        //searchBar.resignFirstResponder()
        //searchActive = false;
        
        if searchBar.text == "" {
            
            let count = g_Sold_Array.count
            filtered.removeAll()
            
            searchActive = false
            
            self.soldTableView.reloadData()
            searchBar.resignFirstResponder()
            return
        }
        
        //print(searchBar.text)
        let count = g_Sold_Array.count
        
        filtered.removeAll()
        
        for i in 0 ... count - 1 {
            let temp: NSString = g_Sold_Array[i].brand as NSString
            let range = temp.range(of: searchBar.text!, options: .caseInsensitive)
            if range.location != NSNotFound {
                filtered.append(g_Sold_Array[i])
            }
        }
        
        if(filtered.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.soldTableView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        //searchActive = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    
    
    // apiver       1
    // maxItemID    9223372036854775807
    // expiryStart  0
    // expiryEnd    9223372036854775807
    // priceH       2147483647
    // priceL       0
    // limit        20
    // buyerID      qzeVbt808GRG4hieNjIga1cNvWL2

    //=========================================================================================
    //
    // Get GetItems for Sold
    //
    //=========================================================================================
    func GetItems_Sold(idToken: String, apiver: Int, maxItemID: Int, expiryStart: Int, expiryEnd: Int, priceH: Int, priceL: Int, limit:Int, sellerID:String) {
        
        Reload_Flag = false
        
        searchActive = false
        filtered.removeAll()
        searchBar.text = ""
        
        self.small_DataArry.removeAll()
        //g_Sold_Array.removeAll()
        let serviceObj = ServiceClass()
        
        // /_ah/api/myApi/v1/sqlgetitemcollection/2147483647/9223372036854775807/0/9223372036854775807/2147483647/0/3?buyerID&sellerID=SELLER_ID

        // But your query looks like this:
        // /_ah/api/myApi/v1/sqlgetitemcollection/2147483647/9223372036854775807/0/9223372036854775807/2147483647/0/3?buyerID&amp;sellerID=SELLER_ID

        
        ProgressHUD.show("Loading...")
        //serviceObj.serviceGetMethodWithAPIHeaderValue1(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.GetItems)\(apiver)/\(maxItemID)/\(expiryStart)/\(expiryEnd)/\(priceH)/\(priceL)/\(limit)?buyerID=&amp;sellerID=\(sellerID)", fields: idToken, completion: {(responseObject) in
        
        serviceObj.serviceGetMethodWithAPIHeaderValue1(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.GetItems)\(apiver)/\(maxItemID)/\(expiryStart)/\(expiryEnd)/\(priceH)/\(priceL)/\(limit)?buyerID&sellerID=\(sellerID)", fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                if responseObject["items"] == nil {
                    ProgressHUD.dismiss()
                    //self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
                    return
                }
                
                let items_dict = responseObject["items"] as! NSArray
                if (items_dict != nil ) {
                    
                    for items_data in items_dict {
                        let dict = items_data as! [String: AnyObject]
                        
                        var temp: Bought_Info = Bought_Info(success: false, itemId: "", itemUUID: "", brand: "", description: "", expiryDateTime: "", price: -1, quantity: "", sellerId: "", buyerId: "", purchaseDate: "", dispatchDate: "", estDeliveryDate: "", uploadDate: "", lastEdited: "")
                        
                        
                        temp.success    = dict["success"] as! Bool
                        temp.itemId     = dict["itemId"] as! String
                        temp.itemUUID   = dict["itemUUID"] as! String
                        temp.brand      = dict["brand"] as! String
                        
                        temp.description    = dict["description"] as! String
                        temp.expiryDateTime = dict["expiryDateTime"] as! String
                        temp.price          = dict["price"] as! Int
                        temp.quantity       = dict["quantity"] as! String
                        
                        temp.sellerId       = dict["sellerId"] as! String
                        temp.buyerId        = dict["buyerId"] as! String
                        temp.purchaseDate   = dict["purchaseDate"] as! String
                        temp.dispatchDate   = dict["dispatchDate"] as! String
                        
                        temp.estDeliveryDate = dict["estDeliveryDate"] as! String
                        temp.uploadDate      = dict["uploadDate"] as! String
                        temp.lastEdited      = dict["lastEdited"] as! String
                        
                        g_Sold_Array.append(temp)
                        self.small_DataArry.append(temp)
                        self.soldTableView.reloadData()
                        
                    }
                    
                    if self.small_DataArry.count == limit {
                        self.Reload_Flag = true
                    } else {
                        self.Reload_Flag = false
                    }
                    
                    DispatchQueue.main.async {
                        ProgressHUD.dismiss()
                        
                        self.spinner.stopAnimating()
                        
                        self.soldTableView.reloadData()
                    }
                    
                } else {
                }
            } else {
                ProgressHUD.dismiss()
                //self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
            }
        })
    }
    
    
}




