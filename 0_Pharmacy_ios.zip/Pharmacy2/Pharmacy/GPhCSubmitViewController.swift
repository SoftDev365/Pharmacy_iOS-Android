//
//  GPhCSubmitViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import JVFloatLabeledTextField
import MessageUI

class GPhCSubmitViewController: UIViewController, UITextFieldDelegate, MFMailComposeViewControllerDelegate {

    let GlobalVar = Global()
    
    @IBOutlet weak var GPhc_number_Text: UITextField!
    @IBOutlet weak var GPhc_number_View: UIView!
    
    @IBOutlet weak var Round_SUBMIT_Button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.hideKeyboardWhenTappedAround()
        
        // Text Delegate
        GPhc_number_Text.delegate = self
        GPhc_number_Text.keyboardType = .numberPad

        // tags
        GPhc_number_Text.tag = 1
        
        // Round Button
        Round_SUBMIT_Button.layer.cornerRadius = 3.0
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.Round_SUBMIT_Button.isUserInteractionEnabled = true
        self.Round_SUBMIT_Button.setTitle("SUBMIT", for: .normal)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // User finished typing (hit return): hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            GPhc_number_View.backgroundColor = UIColor.init(red: 239.0/255.0, green: 47.0/255.0, blue: 106.0/255.0, alpha: 1.0)

        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField.tag {
        case 1:
            GPhc_number_View.backgroundColor = UIColor.gray
        default: break
        }
    }

    @IBAction func onTappedSUBMITButton(_ sender: Any) {
        
        var goFlag: Bool = true
        if GPhc_number_Text.text == "" {
            UIApplication.shared.windows.first?.makeToast("Please insert your GPhc number.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if (GPhc_number_Text.text?.characters.count)! != 7 {
            UIApplication.shared.windows.first?.makeToast("You must input 7 length GPhc number.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        
        if goFlag == true {
            Round_SUBMIT_Button.setTitle("FINDING PHONE NUMBER...", for: .normal)
            Round_SUBMIT_Button.isUserInteractionEnabled = false
            
            g_GphcNum = GPhc_number_Text.text!
            
            //self.performSegue(withIdentifier: StorySegues.FromGPhcSubmitToVerification.rawValue, sender: self)
            
            //==========================================================================
            tryGetPhoneNo(idToken: g_current_fireToken, GphcNum: g_GphcNum)
            //==========================================================================
        }
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //=========================================================================================
    //
    // Get GetPhoneNo
    //
    //=========================================================================================
    func tryGetPhoneNo(idToken: String, GphcNum: String) {

        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue1(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.GetPhoneNo)\(GphcNum)", fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                if responseObject["successful"] == nil {
                    ProgressHUD.dismiss()
                    
                    print(responseObject)
                    
                    let dict_error = responseObject["error"] as! [String: AnyObject]
                    print(dict_error)
                    
                    if dict_error != nil {
                        let dict_message = dict_error["message"] as! String
                        print(dict_message)
                        
                        if dict_message == "Phone number not found" {
                            
                            DispatchQueue.main.async {
                                //send email
                                let composeVC = MFMailComposeViewController()
                                composeVC.mailComposeDelegate = self
                                
                                // Configure the fields of the interface.
                                composeVC.setToRecipients(["support@zavvytech.co.uk"])
                                composeVC.setSubject("this is subject.")
                                composeVC.setMessageBody("", isHTML: false)
                                
                                // Present the view controller modally.
                                self.present(composeVC, animated: true, completion: nil)
                                
                                
                                self.Round_SUBMIT_Button.isUserInteractionEnabled = true
                                self.Round_SUBMIT_Button.setTitle("SUBMIT", for: .normal)
                            }
                            
                            return
                        }
                        if dict_message == "Phone number could not be found" {
                            
                            DispatchQueue.main.async {
                                //self.view.makeToast("Phone number could not be found", duration: 3.0, position: .bottom)
                                let refreshAlert = UIAlertController(title: "", message: "Phone number could not be found", preferredStyle: UIAlertControllerStyle.alert)
                                refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                                    //print("Handle Ok logic here")
                                }))
                                refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                                    //print("Handle Cancel Logic here")
                                }))
                                self.present(refreshAlert, animated: true, completion: nil)
                                
                                self.Round_SUBMIT_Button.isUserInteractionEnabled = true
                                self.Round_SUBMIT_Button.setTitle("SUBMIT", for: .normal)
                            }
                            
                            return
                        }
                        
                        DispatchQueue.main.async {
                            
                            // show toast for dict_message
                            self.view.makeToast(dict_message, duration: 3.0, position: .bottom)
                            
                            self.Round_SUBMIT_Button.isUserInteractionEnabled = true
                            self.Round_SUBMIT_Button.setTitle("SUBMIT", for: .normal)
                        }
                        
                    }
                    
                    return
                    
                }
                
                let returnTemp = responseObject["successful"] as! Bool
                if returnTemp == false {
                    
                    ProgressHUD.dismiss()
                    
                    DispatchQueue.main.async {
                        
                        //self.view.makeToast("Phone number could not be found", duration: 3.0, position: .bottom)
                        
                        let refreshAlert = UIAlertController(title: "", message: "Phone number could not be found", preferredStyle: UIAlertControllerStyle.alert)
                        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                            //print("Handle Ok logic here")
                            
                            //in this
                            
                        }))
                        refreshAlert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (action: UIAlertAction!) in
                            //print("Handle Cancel Logic here")
                        }))
                        self.present(refreshAlert, animated: true, completion: nil)
                        
                        //1037647
                    }
                    
                } else {
                    
//                    let when = DispatchTime.now() + 2 // change 2 to desired number of seconds
//                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        ProgressHUD.dismiss()
//                    }
                    
                    g_current_phoneNum = responseObject["reason"] as! String
                    
                    // Your code with delay
//                    self.Round_SUBMIT_Button.isUserInteractionEnabled = true
//                    self.Round_SUBMIT_Button.setTitle("SUBMIT", for: .normal)
                    
                    DispatchQueue.main.async {
                        self.performSegue(withIdentifier: StorySegues.FromGPhcSubmitToVerification.rawValue, sender: self)
                    }
                    
                    
                    //self.onTappedSigninFlagButton(self)
                    //self.view.makeToast("You have been succeed for sign up", duration: 3.0, position: .bottom)
                }
            }
            else {
                g_ByLogin_GphcSignUp = false
                self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
            }
        })
    }
    
}
