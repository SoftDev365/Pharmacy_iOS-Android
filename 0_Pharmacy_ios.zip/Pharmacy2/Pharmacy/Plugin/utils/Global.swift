//
//  Global.swift
//  Amoureuse
//
//  Created by LEE on 3/30/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit


//By SignUp to Main Page
var g_ByLoginSignUp: Bool = false
var g_ByLogin_GphcSignUp: Bool = false

var g_email: String = ""
var g_password: String = ""

var g_BoughtORBuy_Flag: Bool = false // false: Buy, true: Bought


var g_current_fireToken: String = ""
var g_GphcNum:           String = ""
var g_current_phoneNum:  String = ""

var g_code:              String = ""

var g_FirstVistFlag:     Bool = false

// Bought Page
struct Bought_Info {
    var success:          Bool
    var itemId:           String
    var itemUUID:         String
    var brand:            String
    
    var description:      String
    var expiryDateTime:   String
    var price:            Int
    var quantity:         String
    
    var sellerId:         String
    var buyerId:          String
    
    var purchaseDate:     String
    var dispatchDate:     String
    var estDeliveryDate:  String
    var uploadDate:       String
    var lastEdited:       String
}
var g_Bought_Array:       Array<Bought_Info> = Array<Bought_Info>()
var g_sel_index_1:        Int = -1

var g_Buy_Array:          Array<Bought_Info> = Array<Bought_Info>()
var g_sel_index_2:        Int = -1

var g_Sell_Array:         Array<Bought_Info> = Array<Bought_Info>()
var g_sel_index_3:        Int = -1

var g_Sold_Array:         Array<Bought_Info> = Array<Bought_Info>()
var g_sel_index_4:        Int = -1

















































