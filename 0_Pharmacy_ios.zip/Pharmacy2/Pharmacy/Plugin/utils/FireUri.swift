//
//  FireUri.swift
//  Pharmacy
//
//  Created by Unjang on 9/19/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage

//================================================================================
// Get Phone number
//
func Get_PhoneNum(sellerID: String, completionHandler: @escaping (_ success: String) -> ()) {
    
    let currentUser = FIRAuth.auth()?.currentUser
    let Ref = FIRDatabase.database().reference().child("userIDs").child(sellerID)
    
    var handle: UInt = 0
    handle =  Ref.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
        
        if snapshot.exists() {
            //print("snapshot exists")
            //print(snapshot.childrenCount)
            Ref.removeObserver(withHandle: handle)
            
            if let dict = snapshot.value as?  NSDictionary {
                //print(dict)
                
                let phoneNo = dict["phoneNo"] as! String
                //print(phoneNo)
                
                completionHandler(phoneNo)
                
            } else {
                completionHandler("")
            }
        }
        else {
            //print("snapshot exists")
            completionHandler("")
        }
    })
}

//pharmacy.tradingName == null || pharmacy.tradingName.equals(LOADING) ? "" : pharmacy.tradingName,
//pharmacy.address1 == null || pharmacy.address1.equals(LOADING) ? "" : pharmacy.address1,
//pharmacy.address2 == null || pharmacy.address2.equals(LOADING) ? "" : pharmacy.address2,
//pharmacy.address3 == null || pharmacy.address3.equals(LOADING) ? "" : pharmacy.address3,
//pharmacy.town == null || pharmacy.town.equals(LOADING) ? "" : pharmacy.town,
//pharmacy.county == null || pharmacy.county.equals(LOADING) ? "" : pharmacy.county,
//pharmacy.postcode == null || pharmacy.postcode.equals(LOADING) ? "" : pharmacy.postcode).replaceAll("\\n{2,}", "\n").trim();P057 0D3
//return "\n".equals(addressAsString) ? LOADING : addressAsString;

struct paddress_info {
    var tradingName: String
    var address1:    String
    var address2:    String
    var address3:    String
    var town:        String
    var county:      String
    var postcode:    String
}
var g_location: paddress_info = paddress_info(tradingName: "~", address1: "~", address2: "~", address3: "~", town: "~", county: "~", postcode: "~")

//================================================================================
// Get Phone number
//
func Get_Location(sellerID: String, completionHandler: @escaping (_ success: Bool) -> ()) {
    
    let currentUser = FIRAuth.auth()?.currentUser
    let Ref = FIRDatabase.database().reference().child("userIDs").child(sellerID)
    
    var handle: UInt = 0
    handle = Ref.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
        
        if snapshot.exists() {
            //print("snapshot exists")
            //print(snapshot.childrenCount)
            
            Ref.removeObserver(withHandle: handle)
            
            if let dict = snapshot.value as?  NSDictionary {
                //print(dict)
                
                g_location.tradingName = dict["tradingName"] as! String
                g_location.address1 = dict["address1"] as! String
                g_location.address2 = dict["address2"] as! String
                g_location.address3 = dict["address3"] as! String
                
                g_location.town     = dict["town"] as! String
                g_location.county   = dict["county"] as! String
                g_location.postcode = dict["postcode"] as! String

                
                completionHandler(true)
                
            } else {
                completionHandler(false)
            }
        }
        else {
            //print("snapshot exists")
            completionHandler(false)
        }
    })
}
