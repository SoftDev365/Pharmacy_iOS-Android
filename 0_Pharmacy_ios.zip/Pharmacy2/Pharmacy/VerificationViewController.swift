//
//  VerificationViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import MessageUI

class VerificationViewController: UIViewController, MFMailComposeViewControllerDelegate {

    let GlobalVar = Global()
    
    //Hide, Show View
    @IBOutlet weak var including_CallMe_View: UIView!
    @IBOutlet weak var including_SubMit_View: UIView!
    
    @IBOutlet weak var currentPhoneNum_Label_1: UILabel!
    @IBOutlet weak var currentPhoneNum_Label_2: UILabel!
    
    @IBOutlet weak var verifyCode_Text: UITextField!
    
    // Round Button
    @IBOutlet weak var CallMe_Button: UIButton!
    @IBOutlet weak var Submit_Button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        including_SubMit_View.fadeOut(duration: 0.0, delay: 0.0)
        
        verifyCode_Text.keyboardType = .numberPad
        
        CallMe_Button.layer.cornerRadius = 3.0
        Submit_Button.layer.cornerRadius = 3.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        currentPhoneNum_Label_1.text = g_current_phoneNum
        currentPhoneNum_Label_2.text = g_current_phoneNum
    }
    @IBAction func onTappedCallMeButton(_ sender: Any) {
  
        CallMe_Button.setTitle("REQUESTING CALL...", for: .normal)
        
        //==========================================================================
        GetRequestPhoneCall(idToken: g_current_fireToken, GphcNum: g_GphcNum)
        //==========================================================================
        
        
//        let when = DispatchTime.now() + 2 // change 2 to desired number of seconds
//        DispatchQueue.main.asyncAfter(deadline: when) {
//            // Your code with delay
//            self.including_CallMe_View.fadeOut(duration: 0.0, delay: 0.0)
//            self.including_SubMit_View.fadeIn(duration: 0.3, delay: 0.3)
//            self.CallMe_Button.setTitle("CALL ME", for: .normal)
//        }
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedSubMitButton(_ sender: Any) {
        
        var goFlag: Bool = true
        if verifyCode_Text.text == "" {
            UIApplication.shared.windows.first?.makeToast("Please insert your verification code.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if (verifyCode_Text.text?.characters.count)! != 8 {
            UIApplication.shared.windows.first?.makeToast("You must input 8 length verification code.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        
        if goFlag == true {
            
            GetVerifyPhoneCode(idToken: g_current_fireToken, GphcNum: g_GphcNum, VCode: verifyCode_Text.text!)
        }
    }
    
    //=========================================================================================
    //
    // Get GetRequestPhoneCall
    //
    //=========================================================================================
    func GetRequestPhoneCall(idToken: String, GphcNum: String) {
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue1(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.GetRequestPhoneCall)\(GphcNum)", fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                if responseObject["successful"] == nil {
                    return
                }
                
                let returnTemp = responseObject["successful"] as! Bool
                if returnTemp == false {
                    ProgressHUD.dismiss()
                    self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
                } else {
                    
//                    let when = DispatchTime.now() + 2 // change 2 to desired number of seconds
//                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        ProgressHUD.dismiss()
//                    }
                    
                    DispatchQueue.main.async {
                        let reasonTemp = responseObject["reason"] as! String
                        self.view.makeToast(reasonTemp, duration: 3.0, position: .bottom)
                        
                        // Your code with delay
                        self.including_CallMe_View.fadeOut(duration: 0.0, delay: 0.0)
                        self.including_SubMit_View.fadeIn(duration: 0.3, delay: 0.3)
                        self.CallMe_Button.setTitle("CALL ME", for: .normal)
                    }
                    
                }
            }
            else {
                self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
            }
        })
    }
    
    //=========================================================================================
    //
    // Get GetVerifyPhoneCode
    //
    //=========================================================================================
    func GetVerifyPhoneCode(idToken: String, GphcNum: String, VCode: String) {
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        serviceObj.serviceGetMethodWithAPIHeaderValue1(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.GetVerifyPhoneCode)\(GphcNum)/\(VCode)", fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                if responseObject["successful"] == nil {
                    return
                }
                
                let returnTemp = responseObject["successful"] as! Bool
                if returnTemp == false {
                    DispatchQueue.main.async {
                        ProgressHUD.dismiss()
                        self.view.makeToast("Incorrect verification code.", duration: 3.0, position: .bottom)
                    }
                } else {
                    
//                    let when = DispatchTime.now() + 2 // change 2 to desired number of seconds
//                    DispatchQueue.main.asyncAfter(deadline: when) {
                        // Your code with delay
                        ProgressHUD.dismiss()
//                    }
                    
                    let reasonTemp = responseObject["reason"] as! String
                    self.view.makeToast(reasonTemp, duration: 3.0, position: .bottom)
                    
                    // Your code with delay
                    g_ByLoginSignUp = true
                    
                    DispatchQueue.main.async {
                        self.performSegue(withIdentifier: StorySegues.FromVerificationToMainTab.rawValue, sender: self)
                    }
                    
                }
            }
            else {
                g_ByLogin_GphcSignUp = false
                self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
            }
        })
    }
    
    
    @IBAction func onTappedNotCorrectButton(_ sender: Any) {
        
        let composeVC = MFMailComposeViewController()
        composeVC.mailComposeDelegate = self
        
        // Configure the fields of the interface.
        composeVC.setToRecipients(["support@zavvytech.co.uk"])
        composeVC.setSubject("this is subject.")
        composeVC.setMessageBody("", isHTML: false)
        
        // Present the view controller modally.
        self.present(composeVC, animated: true, completion: nil)
    }

    
    
    
}
