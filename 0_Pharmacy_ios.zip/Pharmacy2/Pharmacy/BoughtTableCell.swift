//
//  BoughtTableCell.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import Foundation
import UIKit

class BoughtTableCell: UITableViewCell {
    
    @IBOutlet weak var productImage: UIImageView!
    
    @IBOutlet weak var brand: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var dispatch: UILabel!
    @IBOutlet weak var delivery: UILabel!
    @IBOutlet weak var phoneNum: UILabel!
    
    @IBOutlet weak var select_Button: UIButton!
    
}
