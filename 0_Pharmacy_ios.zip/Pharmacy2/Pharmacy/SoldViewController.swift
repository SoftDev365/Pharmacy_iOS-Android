//
//  SoldViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/29/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import FSCalendar
    

import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage


class SoldViewController: UIViewController, FSCalendarDataSource, FSCalendarDelegate {
    
    let GlobalVar = Global()
    
    
    @IBOutlet weak var Calendar_Back_View: UIView!
    var str_selectDate : String = ""    // Calendar
    
    
    
    
    @IBOutlet weak var WeekDay_Label: UILabel!
    @IBOutlet weak var Month_Label: UILabel!
    @IBOutlet weak var Date_Label: UILabel!
    @IBOutlet weak var Year_Label: UILabel!
    
    // Images
    @IBOutlet weak var brand_Image: UIImageView!
    @IBOutlet weak var batch_Image: UIImageView!
    @IBOutlet weak var expiry_Image: UIImageView!
    
    // Labels
    @IBOutlet weak var brand_Label: UILabel!
    @IBOutlet weak var price_Label: UILabel!
    @IBOutlet weak var quantity_Label: UILabel!
    
    // Details
    @IBOutlet weak var purchaseDate_Label: UILabel!
    @IBOutlet weak var description_Label: UILabel!
    
    @IBOutlet weak var tradingName_Label: UILabel!
    @IBOutlet weak var address1_Label: UILabel!
    @IBOutlet weak var town_Label: UILabel!
    @IBOutlet weak var postcode_Label: UILabel!
    
    @IBOutlet weak var phoneNum_Label: UILabel!
    
    
    var DispatchOrDelivery_Flag: Bool = false // false: Dispatch, true: Delivery
    @IBOutlet weak var Dispatch_date_Text: UITextField!
    @IBOutlet weak var Delivery_date_Text: UITextField!
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
        
        // Do any additional setup after loading the view.
        
        Calendar_Back_View.layer.cornerRadius = 3.0
        Calendar_Back_View.fadeOut(duration: 0.0, delay: 0.0)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        showCurrentDate()
        
        showAllData_Sold()
    }
    
//    private static int afterStripeFees(int pricePennies) {
//    float appFeePercent = (float) FirebaseRemoteConfig.getInstance().getDouble("stripe_app_fee");
//    int appFee = Math.round((appFeePercent * pricePennies) / 100);
//    int minusAppFee = pricePennies - appFee;
//    int minusPercentFee = Math.min(Math.round(minusAppFee * 0.986f), minusAppFee - 1);
//    return minusPercentFee - 20;
//    }
    
    func showAllData_Sold() {
        
        let storage = FIRStorage.storage()
        var reference1: FIRStorageReference!
        var reference2: FIRStorageReference!
        var reference3: FIRStorageReference!
        
        reference1 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sold_Array[g_sel_index_4].sellerId)/\(g_Sold_Array[g_sel_index_4].itemUUID)/brand.jpg")
        reference1.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.brand_Image.image = UIImage(named: "Pill.png")
            } else {
                // Data for "images/island.jpg" is returned
                self.brand_Image?.sd_setShowActivityIndicatorView(true)
                self.brand_Image?.sd_setIndicatorStyle(.gray)
                self.brand_Image?.sd_setImage(with: url)
            }
        }
        reference2 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sold_Array[g_sel_index_4].sellerId)/\(g_Sold_Array[g_sel_index_4].itemUUID)/batch.jpg")
        reference2.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.batch_Image.image = UIImage(named: "Pill.png")
            } else {
                self.batch_Image?.sd_setShowActivityIndicatorView(true)
                self.batch_Image?.sd_setIndicatorStyle(.gray)
                self.batch_Image?.sd_setImage(with: url)
            }
        }
        reference3 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sold_Array[g_sel_index_4].sellerId)/\(g_Sold_Array[g_sel_index_4].itemUUID)/expiry.jpg")
        reference3.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.expiry_Image.image = UIImage(named: "Pill.png")
            } else {
                self.expiry_Image?.sd_setShowActivityIndicatorView(true)
                self.expiry_Image?.sd_setIndicatorStyle(.gray)
                self.expiry_Image?.sd_setImage(with: url)
            }
        }
        
        brand_Label.text = g_Sold_Array[g_sel_index_4].brand
        
        let poundString = String(format: "%.02f", Double(g_Sold_Array[g_sel_index_4].price) / 100)
        price_Label.text = "£\(poundString)"     //170,00
        
        quantity_Label.text = g_Sold_Array[g_sel_index_4].quantity
        
        Get_PhoneNum(sellerID: g_Sold_Array[g_sel_index_4].sellerId, completionHandler: { success in
            if success != "" {
                self.phoneNum_Label.text = success
            } else {
                self.phoneNum_Label.text = success //""
            }
        })
        
        Get_Location(sellerID: g_Sold_Array[g_sel_index_4].sellerId, completionHandler: { success in
            if success == true {
                self.tradingName_Label.text = g_location.tradingName
                self.address1_Label.text = g_location.address1
                self.town_Label.text = g_location.town
                self.postcode_Label.text = g_location.postcode
            } else {
            }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .lightContent
//    }
    
    

    // Calendar Back View ==========================================
    @IBAction func onTappedCancelCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }

    @IBAction func onTappedDoneCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    
    // Select Dispatch and Delivery Buttons
    @IBAction func onTappedDispatchButton(_ sender: Any) {
        DispatchOrDelivery_Flag = false
        Calendar_Back_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    @IBAction func onTappedDeliveryButton(_ sender: Any) {
        DispatchOrDelivery_Flag = true
        Calendar_Back_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    
    
    // Calendar =====================================================
    //Select Point
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        
        str_selectDate = dateFormatter.string(from: date)
        
        if DispatchOrDelivery_Flag == false {
            Dispatch_date_Text.text = str_selectDate
        } else {
            Delivery_date_Text.text = str_selectDate
        }
        
        
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: date)
        
        let weekday = date.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: date)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func showCurrentDate() {
        
        let todayDate = Date()
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: todayDate)
        
        let weekday = todayDate.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: todayDate)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: todayDate)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
    }
    
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        
        //if check_Add() {

        let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "dd MMM yyyy"
                
//                if Dispatch_date_Text.text == "" {
//                    Dispatch_date_Text.text = "01 Feb 1970"
//                }
//                if Delivery_date_Text.text == "" {
//                    Delivery_date_Text.text = "01 Feb 1970"
//                }
            
            
            
            if Dispatch_date_Text.text != "" && Delivery_date_Text.text != "" {
                
                let date1 = dateFormatter.date(from: Dispatch_date_Text.text!)
                let ss1 = date1?.millisecondsSince1970 // 1476889390939
                print(ss1!)
                
                let date2 = dateFormatter.date(from: Delivery_date_Text.text!)
                let ss2 = date2?.millisecondsSince1970 // 1476889390939
                print(ss2!)
                
                
                EditItem_Sold(idToken: g_current_fireToken, apiver: 1, itemID: g_Sold_Array[g_sel_index_4].itemId, Dispatch_date: "\(ss1!)", Delivery_date: "\(ss2!)")
                return
            }
            
            else if Dispatch_date_Text.text != "" {
                let date1 = dateFormatter.date(from: Dispatch_date_Text.text!)
                let ss1 = date1?.millisecondsSince1970 // 1476889390939
                print(ss1!)
                
                // make call to  /_ah/api/myApi/v1/editItem/1/51?dispatchDate={ss1}
                EditItem_Sold(idToken: g_current_fireToken, apiver: 1, itemID: g_Sold_Array[g_sel_index_4].itemId, Dispatch_date: "\(ss1!)", Delivery_date: "")
                return
            }
            
            else if Delivery_date_Text.text != "" {
                let date2 = dateFormatter.date(from: Delivery_date_Text.text!)
                let ss2 = date2?.millisecondsSince1970 // 1476889390939
                print(ss2!)
                
                // make call to  /_ah/api/myApi/v1/editItem/1/51?dispatchDate={ss2}
                EditItem_Sold(idToken: g_current_fireToken, apiver: 1, itemID: g_Sold_Array[g_sel_index_4].itemId, Dispatch_date: "", Delivery_date: "\(ss2!)")
                return
            }
            
            
            g_sel_index_4 = -1
            self.navigationController?.popViewController(animated: true)


    }
    
    func check_change() -> Bool {
        
        var Flag: Bool = false
        
        if Dispatch_date_Text.text != GetStrDate(timestamp: g_Sold_Array[g_sel_index_4].dispatchDate) {
            Flag = true
        }
        
        if Delivery_date_Text.text != GetStrDate(timestamp: g_Sold_Array[g_sel_index_4].estDeliveryDate) {
            Flag = true
        }
        
        return Flag
    }
    
    func check_Add() -> Bool {
        
        var Flag: Bool = true
        
        if Dispatch_date_Text.text != "" {
        } else {
            Flag = false
        }
        
        if Delivery_date_Text.text != "" {
        } else {
            Flag = false
        }

        if Flag == false {
            self.view.makeToast("Please input all feilds.")
        } else {
        }
        
        return Flag
    }
    
    //https://pharmacy-165422.appspot.com/_ah/api/myApi/v1/editItem/1/12?brand=ttt&quantity=123123
    
    //=========================================================================================
    //
    // Get EditItem for Sold
    //
    //=========================================================================================
    func EditItem_Sold(idToken: String, apiver: Int, itemID: String, Dispatch_date: String, Delivery_date: String) {
        
        let params: NSDictionary = [:]
        
        let serviceObj = ServiceClass()
        
        var headerValue: String = ""
        if Dispatch_date != "" && Delivery_date != "" {
            headerValue = "\(GlobalVar.EditItem)\(apiver)/\(itemID)?dispatchDate=\(Dispatch_date)&estDeliveryDate=\(Delivery_date)"
        }
        
        if Dispatch_date != "" && Delivery_date == "" {
            headerValue = "\(GlobalVar.EditItem)\(apiver)/\(itemID)?dispatchDate=\(Dispatch_date)"
        }
        
        if Dispatch_date == "" && Delivery_date != "" {
            headerValue = "\(GlobalVar.EditItem)\(apiver)/\(itemID)?estDeliveryDate=\(Delivery_date)"
        }
        
        
        
        
        ProgressHUD.show("updating...")
        serviceObj.servicePostMethodWithAPIHeaderValue2(apiValue: GlobalVar.APIHEADER, headerValue: headerValue, parameters: params, fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["successful"] as! Bool
                if returnTemp == false {
                    ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                    
                } else {
                    ProgressHUD.dismiss()
                    
                    
                    g_Sold_Array[g_sel_index_4].dispatchDate = Dispatch_date
                    g_Sold_Array[g_sel_index_4].estDeliveryDate = Delivery_date
                    
                    g_sel_index_4 = -2
                    self.navigationController?.popViewController(animated: true)
                }
            }
            else {
                ProgressHUD.dismiss()
            }
        })
    }
}
