//
//  SoldTableCell.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import Foundation
import UIKit

class SoldTableCell: UITableViewCell {

    @IBOutlet weak var ProductImage: UIImageView!
    
    @IBOutlet weak var Delivery: UILabel!
    @IBOutlet weak var brand: UILabel!
    
    @IBOutlet weak var date: UILabel!
    
    
    @IBOutlet weak var address: UILabel!
    
    @IBOutlet weak var Dispatch: UILabel!
    
    @IBOutlet weak var select_Button: UIButton!
}
