//
//  SellSubViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import FSCalendar


import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage




class SellEditViewController: UIViewController, UITextFieldDelegate, WDImagePickerDelegate, UIImagePickerControllerDelegate, FSCalendarDataSource, FSCalendarDelegate {
    
    let GlobalVar = Global()
        
    @IBOutlet weak var Calendar_Back_View: UIView!
    var str_selectDate : String = ""    // Calendar
    
    @IBOutlet weak var WeekDay_Label: UILabel!
    @IBOutlet weak var Month_Label: UILabel!
    @IBOutlet weak var Date_Label: UILabel!
    @IBOutlet weak var Year_Label: UILabel!
    
    @IBOutlet weak var product_Image1: UIImageView!
    @IBOutlet weak var product_Image2: UIImageView!
    @IBOutlet weak var product_Image3: UIImageView!
    
    @IBOutlet weak var Brand_Text: UITextField!
    @IBOutlet weak var Brand_Len_Label: UILabel!
    
    @IBOutlet weak var Price_Text: UITextField!
    @IBOutlet weak var Price_fees_Label: UILabel!
    
    @IBOutlet weak var Description_Text: UITextField!
    @IBOutlet weak var description_Len_Label: UILabel!
    
    @IBOutlet weak var Expiry_Text: UITextField!
    
    @IBOutlet weak var Quantity_Text: UITextField!
    @IBOutlet weak var Quantity_Len_Label: UILabel!
    
    
    //WDImagePicker
    var imagePicker: WDImagePicker!
    var fixedImage: UIImage?
    
    var oneTap_Flag: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
        
        // Do any additional setup after loading the view.
        
        Calendar_Back_View.layer.cornerRadius = 3.0
        Calendar_Back_View.fadeOut(duration: 0.0, delay: 0.0)

        product_Image1.layer.borderColor = UIColor.white.cgColor
        product_Image1.layer.borderWidth = 1
        product_Image2.layer.borderColor = UIColor.white.cgColor
        product_Image2.layer.borderWidth = 1
        product_Image3.layer.borderColor = UIColor.white.cgColor
        product_Image3.layer.borderWidth = 1
        
        
        Brand_Text.delegate = self
        //Brand_Text.delegate = self
        
        Description_Text.delegate = self
        //Description_Text.delegate = self
        
        Quantity_Text.delegate = self
        //Quantity_Text.delegate = self
        
        Price_Text.delegate = self
        //Price_Text.delegate = self
        
        //Price_Text.keyboardType = .numberPad
        
        Price_Text.keyboardType = .decimalPad
        
        // tags
        Brand_Text.tag = 1
        Description_Text.tag = 2
        Quantity_Text.tag = 3
        Price_Text.tag = 4
        
        Brand_Text.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        Description_Text.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        Quantity_Text.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        Price_Text.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        oneTap_Flag = true
        
        if g_FirstVistFlag == true {
            showCurrentDate()
            showAllData_Sell()
        }
    }
    
    func showAllData_Sell() {
        
        let storage = FIRStorage.storage()
        var reference1: FIRStorageReference!
        var reference2: FIRStorageReference!
        var reference3: FIRStorageReference!
        
        reference1 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sell_Array[g_sel_index_3].sellerId)/\(g_Sell_Array[g_sel_index_3].itemUUID)/brand.jpg")
        reference1.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.product_Image1.image = UIImage(named: "Pill.png")
            } else {
                // Data for "images/island.jpg" is returned
                self.product_Image1?.sd_setShowActivityIndicatorView(true)
                self.product_Image1?.sd_setIndicatorStyle(.gray)
                self.product_Image1?.sd_setImage(with: url)
            }
        }
        reference2 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sell_Array[g_sel_index_3].sellerId)/\(g_Sell_Array[g_sel_index_3].itemUUID)/expiry.jpg")
        reference2.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.product_Image2.image = UIImage(named: "Pill.png")
            } else {
                self.product_Image2?.sd_setShowActivityIndicatorView(true)
                self.product_Image2?.sd_setIndicatorStyle(.gray)
                self.product_Image2?.sd_setImage(with: url)
            }
        }
        reference3 = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sell_Array[g_sel_index_3].sellerId)/\(g_Sell_Array[g_sel_index_3].itemUUID)/batch.jpg")
        reference3.downloadURL { (url, error) in
            
            if let error = error {
                // Uh-oh, an error occurred!
                self.product_Image3.image = UIImage(named: "Pill.png")
            } else {
                self.product_Image3?.sd_setShowActivityIndicatorView(true)
                self.product_Image3?.sd_setIndicatorStyle(.gray)
                self.product_Image3?.sd_setImage(with: url)
            }
        }
        
        Brand_Text.text = g_Sell_Array[g_sel_index_3].brand
        Description_Text.text = g_Sell_Array[g_sel_index_3].description
        
        let poundString = String(format: "%.02f", Double(g_Sell_Array[g_sel_index_3].price) / 100)
        Price_Text.text = "\(poundString)"     //170,00
        
        let price: Double = Double(Price_Text.text!)!
        if price > 0.0 {
            Price_fees_Label.text = "£\(String(format: "%.2f", price * 0.9352)) after fees"
        }
        
        
        Quantity_Text.text = g_Sell_Array[g_sel_index_3].quantity
        Expiry_Text.text = GetStrDate(timestamp: g_Sell_Array[g_sel_index_3].expiryDateTime)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    @IBAction func onTappedLarge_CheckedButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    
    @IBAction func onTappedShowCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    
    // Calendar Back View ==========================================
    @IBAction func onTappedCancelCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }

    @IBAction func onTappedDoneCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    
    // UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // User finished typing (hit return): hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            if (Brand_Text.text?.characters.count)! > 0 && (Brand_Text.text?.characters.count)! < 76 {
                Brand_Len_Label.text = "\((Brand_Text.text?.characters.count)!) / 75"
            }
        case 2:
            if (Description_Text.text?.characters.count)! > 0 && (Description_Text.text?.characters.count)! < 501 {
                description_Len_Label.text = "\((Brand_Text.text?.characters.count)!) / 500"
            }
        case 3:
            if (Quantity_Text.text?.characters.count)! > 0 && (Quantity_Text.text?.characters.count)! < 76 {
                Quantity_Len_Label.text = "\((Quantity_Text.text?.characters.count)!) / 75"
            }
        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        //        switch textField.tag {
        //        case 1:
        //        default: break
        //        }
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
//    {
//        if textField == self.Price_Text {
//            
//            let invalidCharacters = CharacterSet(charactersIn: ".0123456789").inverted
//            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
//        } else {
//            let invalidCharacters = CharacterSet(charactersIn: "0123456789").inverted
//            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
//        }
//    }
    
    func textFieldDidChange(_ textField: UITextField) {
        switch textField.tag {
            
        case 1:
            Brand_Len_Label.text = "\((Brand_Text.text?.characters.count)!) / 75"
            
            if (Brand_Text.text?.characters.count)! > 0 && (Brand_Text.text?.characters.count)! < 76 {
                Brand_Len_Label.textColor = UIColor.black
            } else {
                Brand_Len_Label.textColor = UIColor.red
                //self.view.makeToast("Brand must be less than 75 characters")
            }
            if (Brand_Text.text?.characters.count) == 0 {
                Brand_Len_Label.text = ""
            }
        case 2:
            description_Len_Label.text = "\((Description_Text.text?.characters.count)!) / 500"
            
            if (Description_Text.text?.characters.count)! > 0 && (Description_Text.text?.characters.count)! < 501 {
                description_Len_Label.textColor = UIColor.black
            } else {
                description_Len_Label.textColor = UIColor.red
                //self.view.makeToast("Description must be less than 500 characters")
            }
            if (Description_Text.text?.characters.count) == 0 {
                description_Len_Label.text = ""
            }
        case 3:
            Quantity_Len_Label.text = "\((Quantity_Text.text?.characters.count)!) / 75"
            if (Quantity_Text.text?.characters.count)! > 0 && (Quantity_Text.text?.characters.count)! < 76 {
                Quantity_Len_Label.textColor = UIColor.black
            } else {
                Quantity_Len_Label.textColor = UIColor.red
                //self.view.makeToast("Quantity must be less than 75 characters")
            }
            if (Quantity_Text.text?.characters.count) == 0 {
                Quantity_Len_Label.text = ""
            }
        case 4:
            if (Price_Text.text?.characters.count) == 0 {
                Price_fees_Label.text = ""
                return
            } else {
                
                do {
                    let regex = try NSRegularExpression(pattern: "^\\d{0,5}(\\.\\d{2})?$")
                    //let results = regex.matches(in: Price_Text.text!, range: <#NSRange#>)
                    let results = regex.matches(in: Price_Text.text!, range: NSMakeRange(0, (Price_Text.text?.characters.count)!))
                    
                    if results.count > 0 {
                        
                        var price: Double = Double(Price_Text.text!)!
                        
                        if price > 1.0 {
                            Price_fees_Label.text = "£\(String(format: "%.2f", price * 0.9352)) after fees"
                        }
                        
                    }
                    
                } catch let error as NSError {
                    print("invalid regex: \(error.localizedDescription)")
                }
                
            }
            
            
        default: break
        }
    }

    // Calendar =====================================================
    //Select Point
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        
        str_selectDate = dateFormatter.string(from: date)
        Expiry_Text.text = str_selectDate
        
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: date)
        
        let weekday = date.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: date)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func showCurrentDate() {
        
        let todayDate = Date()
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: todayDate)
        
        let weekday = todayDate.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: todayDate)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: todayDate)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
    }
    
    

    //======================================================================================
    //  Cancel, Save
    //======================================================================================
    @IBAction func onTappedCancelButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func onTappedSaveButton(_ sender: Any) {
        
        if oneTap_Flag == false {
            return
        }
        
        if check_Add() {
            
            oneTap_Flag = false
            
            
            var price: Double = 0.0
            
            do {
                let regex = try NSRegularExpression(pattern: "^\\d{0,5}(\\.\\d{2})?$")
                //let results = regex.matches(in: Price_Text.text!, range: <#NSRange#>)
                let results = regex.matches(in: Price_Text.text!, range: NSMakeRange(0, (Price_Text.text?.characters.count)!))
                
                if results.count > 0 {
                    
                    price = Double(Price_Text.text!)!
                    
                    if price > 1.0 {
                        Price_fees_Label.text = "£\(String(format: "%.2f", price * 0.9352)) after fees"
                        
                        if check_change() {
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "dd MMM yyyy"
                            let date = dateFormatter.date(from: Expiry_Text.text!)
                            
                            let ss = date?.millisecondsSince1970 // 1476889390939
                            print(ss!)
                            
                            
                            
                            self.downcount = 0
                            let user = FIRAuth.auth()?.currentUser
                            
                            uploadMedia(uuid: g_Sell_Array[g_sel_index_3].itemUUID, myImage: product_Image1.image!, imageName: "brand.jpg", completion: { downloadUrl in
                                if self.downcount >= 3 {
                                    self.downcount = 0
                                    //self.tryAddItem(idToken: g_current_fireToken, apiver: 1, uuid: uuid, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                    self.EditItem_Sell(idToken: g_current_fireToken, apiver: 1, itemID: g_Sell_Array[g_sel_index_3].itemId, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price * 100.0), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                }
                            })
                            uploadMedia(uuid: g_Sell_Array[g_sel_index_3].itemUUID, myImage: product_Image2.image!, imageName: "expiry.jpg", completion: { downloadUrl in
                                if self.downcount >= 3 {
                                    self.downcount = 0
                                    self.EditItem_Sell(idToken: g_current_fireToken, apiver: 1, itemID: g_Sell_Array[g_sel_index_3].itemId, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price * 100.0), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                }
                            })
                            uploadMedia(uuid: g_Sell_Array[g_sel_index_3].itemUUID, myImage: product_Image3.image!, imageName: "batch.jpg", completion: { downloadUrl in
                                if self.downcount >= 3 {
                                    self.downcount = 0
                                    self.EditItem_Sell(idToken: g_current_fireToken, apiver: 1, itemID: g_Sell_Array[g_sel_index_3].itemId, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price * 100.0), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                }
                            })
                            
                            
                        } else {
                            g_sel_index_3 = -1
                            self.navigationController?.popViewController(animated: true)
                        }
                        
                        
                    } else {
                        self.view.makeToast("Price should be at least £1")
                    }
                    
                } else {
                    self.view.makeToast("Input a valid price less than £100000")
                }
                
            } catch let error as NSError {
                print("invalid regex: \(error.localizedDescription)")
            }
        }
    }
    
    /*@IBAction func onTappedBackButton(_ sender: Any) {
        //self.dismiss(animated: true, completion: nil)
        
        if oneTap_Flag == false {
            return
        }
        
        oneTap_Flag = false
        
        if check_Add() {
            
            var price: Double = 0.0
            
            do {
                let regex = try NSRegularExpression(pattern: "^\\d{0,5}(\\.\\d{2})?$")
                //let results = regex.matches(in: Price_Text.text!, range: <#NSRange#>)
                let results = regex.matches(in: Price_Text.text!, range: NSMakeRange(0, (Price_Text.text?.characters.count)!))
                
                if results.count > 0 {
                    
                    price = Double(Price_Text.text!)!
                    
                    if price > 1.0 {
                        Price_fees_Label.text = "£\(String(format: "%.2f", price * 0.9352)) after fees"
                        
                        if check_change() {
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "dd MMM yyyy"
                            let date = dateFormatter.date(from: Expiry_Text.text!)
                            
                            let ss = date?.millisecondsSince1970 // 1476889390939
                            print(ss!)
                            
                            
                            
                            self.downcount = 0
                            let user = FIRAuth.auth()?.currentUser
                            
                            uploadMedia(uuid: g_Sell_Array[g_sel_index_3].itemUUID, myImage: product_Image1.image!, imageName: "brand.jpg", completion: { downloadUrl in
                                if self.downcount >= 3 {
                                    self.downcount = 0
                                    //self.tryAddItem(idToken: g_current_fireToken, apiver: 1, uuid: uuid, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                    self.EditItem_Sell(idToken: g_current_fireToken, apiver: 1, itemID: g_Sell_Array[g_sel_index_3].itemId, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price * 100.0), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                }
                            })
                            uploadMedia(uuid: g_Sell_Array[g_sel_index_3].itemUUID, myImage: product_Image2.image!, imageName: "batch.jpg", completion: { downloadUrl in
                                if self.downcount >= 3 {
                                    self.downcount = 0
                                    self.EditItem_Sell(idToken: g_current_fireToken, apiver: 1, itemID: g_Sell_Array[g_sel_index_3].itemId, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price * 100.0), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                }
                            })
                            uploadMedia(uuid: g_Sell_Array[g_sel_index_3].itemUUID, myImage: product_Image3.image!, imageName: "expiry.jpg", completion: { downloadUrl in
                                if self.downcount >= 3 {
                                    self.downcount = 0
                                    self.EditItem_Sell(idToken: g_current_fireToken, apiver: 1, itemID: g_Sell_Array[g_sel_index_3].itemId, brand: (self.Brand_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, description: (self.Description_Text.text?.replacingOccurrences(of: " ", with: "%20"))!, expiry: "\(ss!)", price: Int(price * 100.0), quantity: (self.Quantity_Text.text?.replacingOccurrences(of: " ", with: "%20"))!)
                                }
                            })
                            
                            
                            
                            
                            
                            
                            
                        } else {
                            g_sel_index_3 = -1
                            self.navigationController?.popViewController(animated: true)
                        }
                        
                        
                    } else {
                        self.view.makeToast("Price should be at least £1")
                    }
                    
                } else {
                    self.view.makeToast("Input a valid price less than £100000")
                }
                
            } catch let error as NSError {
                print("invalid regex: \(error.localizedDescription)")
            }
        }
    }*/
    
    func check_change() -> Bool {
        
        var Flag: Bool = false
        
        if Brand_Text.text != g_Sell_Array[g_sel_index_3].brand {
            Flag = true
        }
        
        if Price_Text.text != "\(Double(g_Sell_Array[g_sel_index_3].price) / 100)" {
            Flag = true
        }
        
        if Description_Text.text != g_Sell_Array[g_sel_index_3].description {
            Flag = true
        }
        
        if Expiry_Text.text != GetStrDate(timestamp: g_Sell_Array[g_sel_index_3].expiryDateTime) {
            Flag = true
        }
        
        if Quantity_Text.text != g_Sell_Array[g_sel_index_3].quantity {
            Flag = true
        }
        
        if AddImage_Index != 0 {
            Flag = true
        }        
        
        return Flag
    }
    
    func check_Add() -> Bool {
        
        var Flag: Bool = true
        
        if Brand_Text.text != "" {
        } else {
            Flag = false
        }
        
        if Price_Text.text != "" {
        } else {
            Flag = false
        }
        
        if Expiry_Text.text != "" {
        } else {
            Flag = false
        }
        
        if Quantity_Text.text != "" {
        } else {
            Flag = false
        }
        
        if Flag == false {
            self.view.makeToast("Please input all feilds.")
            return false
        } else {
        }

        
        
        
        
        if (Brand_Text.text?.characters.count)! > 0 && (Brand_Text.text?.characters.count)! < 76 {
            Flag = true
        } else {
            self.view.makeToast("Brand must be less than 75 characters")
            return false
        }
        
//        if (Description_Text.text?.characters.count)! > 0 && (Description_Text.text?.characters.count)! < 501 {
//            Flag = true
//        } else {
//            self.view.makeToast("Description must be less than 500 characters")
//            return false
//        }
        
        if (Quantity_Text.text?.characters.count)! > 0 && (Quantity_Text.text?.characters.count)! < 76 {
            Flag = true
        } else {
            self.view.makeToast("Quantity must be less than 75 characters")
            return false
        }
        
        
        
        
        
        if Brand_Text.text != g_Sell_Array[g_sel_index_3].brand {
            return true
        }
        
        if Description_Text.text != g_Sell_Array[g_sel_index_3].description {
            return true
        }
        
        let poundString = String(format: "%.02f", Double(g_Sell_Array[g_sel_index_3].price) / 100)
        if Price_Text.text != "\(poundString)" {
            return true
        }
        
        if Quantity_Text.text != g_Sell_Array[g_sel_index_3].quantity {
            return true
        }
        
        if Expiry_Text.text != GetStrDate(timestamp: g_Sell_Array[g_sel_index_3].expiryDateTime) {
            return true
        }
        
        if g_FirstVistFlag == false {
            return true
        }
        
        return false
    }
    
    //https://pharmacy-165422.appspot.com/_ah/api/myApi/v1/editItem/1/12?brand=ttt&quantity=123123
    
    //=========================================================================================
    //
    // Get EditItem for Sell
    //
    //=========================================================================================
    func EditItem_Sell(idToken: String, apiver: Int, itemID: String, brand: String, description: String, expiry: String, price: Int, quantity: String) {

        let params: NSDictionary = [:]
        
        let serviceObj = ServiceClass()
        
        ProgressHUD.show("updating...")
        serviceObj.servicePostMethodWithAPIHeaderValue2(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.EditItem)\(apiver)/\(itemID)?brand=\(brand)&description=\(description)&expiry=\(expiry)&price=\(price)&quantity=\(quantity)", parameters: params, fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["successful"] as! Bool
                if returnTemp == false {
                    ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                    
                } else {
                    ProgressHUD.dismiss()
                    
                    self.oneTap_Flag = false
                    
                    g_Sell_Array[g_sel_index_3].brand = brand
                    g_Sell_Array[g_sel_index_3].price = price
                    g_Sell_Array[g_sel_index_3].description = description
                    g_Sell_Array[g_sel_index_3].expiryDateTime = expiry
                    g_Sell_Array[g_sel_index_3].quantity = quantity
                    
                    g_sel_index_3 = -2
                    self.navigationController?.popViewController(animated: true)
                }
            }
            else {
                ProgressHUD.dismiss()
            }
        })
    }

    
    
    // Change Image
    var AddImage_Index: Int = 0
    // Add Product Image ============================================
    @IBAction func onTappedAddImage1(_ sender: Any) {
        AddImage_Index = 1
        
        
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        let newCellWidth = 375 * ScreenWidth / 375
        
        
        
        
        
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: newCellWidth, height: newCellWidth)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "Option", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Choose from Album", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func onTappedAddImage2(_ sender: Any) {
        AddImage_Index = 2
        
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        let newCellWidth = 375 * ScreenWidth / 375
        
        
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: newCellWidth, height: newCellWidth)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "Option", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Choose from Album", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func onTappedAddImage3(_ sender: Any) {
        AddImage_Index = 3
        
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        let newCellWidth = 375 * ScreenWidth / 375
        
        
        
        imagePicker = WDImagePicker()
        imagePicker.cropSize = CGSize(width: newCellWidth, height: newCellWidth)
        imagePicker.delegate = self
        let alert = UIAlertController(title: "Option", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Take Photo", style: .default, handler:{
            action in
            self.imagePicker.imagePickerController.sourceType = .camera
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Choose from Album", style: .default, handler: {
            action in
            self.imagePicker.imagePickerController.sourceType = .photoLibrary
            self.present(self.imagePicker.imagePickerController, animated: true, completion: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func imageWithImage(image: UIImage, newSize: CGSize) -> UIImage{
        UIGraphicsBeginImageContext(newSize)
        image.draw(in: CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height))
        let newImage: UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return newImage
    }
    
    func imagePicker(_ imagePicker: WDImagePicker, pickedImage: UIImage) {
        
        
        self.fixedImage = self.imageWithImage(image: pickedImage, newSize: CGSize(width: 300, height: 300))
        
        g_FirstVistFlag = false
        
        switch AddImage_Index {
        case 1:
            product_Image1.image = self.fixedImage
        case 2:
            product_Image2.image = self.fixedImage
        case 3:
            product_Image3.image = self.fixedImage
        default:
            break
        }
        
        self.imagePicker.imagePickerController.dismiss(animated: true, completion: nil)
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingImage image: UIImage!, editingInfo:[AnyHashable: Any]!)
        {
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    
    var downcount = 0
    func uploadMedia(uuid: String, myImage: UIImage, imageName: String, completion: @escaping (_ url: String?) -> Void) {
        
        let tempImage = self.imageWithImage(image: myImage, newSize: CGSize(width: 300, height: 300))
        
        let user = FIRAuth.auth()?.currentUser
        
        var data: NSData = NSData()
        data = UIImageJPEGRepresentation(tempImage, 0.1)! as NSData
        let metadata = FIRStorageMetadata()
        metadata.contentType = "image/jpg"
        
        var DownloadUrl: String = ""
        
        FIRStorage.storage().reference().child("items/\((user?.uid)!)/\(uuid)/\(imageName)").put(data as Data , metadata: metadata, completion: { (metadata, error) in
            
            if error == nil {
                self.downcount += 1
                DownloadUrl = (metadata?.downloadURLs?[0].absoluteString)!
                completion(DownloadUrl)
            }
        })
    }
    
    
}
