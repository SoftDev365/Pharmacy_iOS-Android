//
//  SellTabViewController.swift
//  Pharmacy
//
//  Created by LEE on 9/2/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit

import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage


class SellTabViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UISearchBarDelegate {
    
    let GlobalVar = Global()
    

    
    @IBOutlet weak var searchBar: UISearchBar!

    @IBOutlet weak var SellCollectionView: UICollectionView!
    
    var refreshControl:UIRefreshControl!
    
    var filtered:[Bought_Info] = []
    var searchActive : Bool = false
    
    
    var small_DataArry:[Bought_Info] = []
    var Reload_Flag: Bool = false
    
    
    @IBOutlet weak var background_View: UIView!
    @IBOutlet weak var stripeConect_View: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.hideKeyboardWhenTappedAround()
        
        // Search Bar
        searchBar.delegate = self
        self.searchBar.backgroundImage = UIImage()
        
        // Collection View
        SellCollectionView.delegate = self
        SellCollectionView.dataSource = self
        
       SellCollectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl.tintColor = UIColor.gray
        
        //self.refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        let attributes = [NSForegroundColorAttributeName: UIColor.gray, NSFontAttributeName: UIFont.systemFont(ofSize: 12)]
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh", attributes: attributes)
        
        self.refreshControl.addTarget(self, action: #selector(loadData), for: UIControlEvents.valueChanged)
        SellCollectionView!.addSubview(refreshControl)

        
        background_View.backgroundColor = UIColor(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha: 0.6)
        stripeConect_View.layer.cornerRadius = 4.0
        background_View.fadeOut(duration: 0.0, delay: 0.0)
        stripeConect_View.fadeOut(duration: 0.0, delay: 0.0)
        
        // Loading datas
        loadData()

        
        NotificationCenter.default.addObserver(self, selector: #selector(self.myNotification), name: NSNotification.Name(rawValue: "checktheme"), object: nil)
        
        
    }
    
    // Notification
    // Connect Stripe ========================================================================
    func myNotification() {
        self.tryToPostConnect(idToken: g_current_fireToken, apiver: 2147483647, code: g_code)
    }
    
    func tryToPostConnect(idToken: String, apiver: Int, code: String) {
        
        let params: NSDictionary = [:]
        let serviceObj = ServiceClass()
        
        ProgressHUD.show()
        var header  = "\(GlobalVar.ConnectWithStripe)\(apiver)/\(code)"
        
        serviceObj.servicePostMethodWithAPIHeaderValue2(apiValue: GlobalVar.APIHEADER, headerValue: header, parameters: params, fields: idToken, completion: {(responseObject) in
            
            ProgressHUD.dismiss()
            
            if (responseObject != nil ) {
                
                let returnTemp = responseObject?["successful"] as! Bool
                if returnTemp == false {
                    ProgressHUD.dismiss()
                    //let errorTemp = responseObject?["error"] as! String
                    //self.view.makeToast(errorTemp, duration: 3.0, position: .bottom)
                    
                } else {
                    
                    DispatchQueue.main.async {
                        ProgressHUD.dismiss()
                        
                        self.background_View.backgroundColor = UIColor.clear
                        self.stripeConect_View.fadeOut(duration: 0.0, delay: 0.0)
                        self.background_View.fadeOut(duration: 0.0, delay: 0.0)
                        
                        self.performSegue(withIdentifier: StorySegues.FromSellTabToSellAdd.rawValue, sender: self)
                        //self.navigationController?.popViewController(animated: true)
                    }
                }
            }
            else {
                ProgressHUD.dismiss()
            }
        })
    }
    
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        background_View.backgroundColor = UIColor(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha: 0.6)
        stripeConect_View.layer.cornerRadius = 4.0
        background_View.fadeOut(duration: 0.0, delay: 0.0)
        stripeConect_View.fadeOut(duration: 0.0, delay: 0.0)
    }
    
    func loadData() {
        //code to execute during refresher
        
        g_Sell_Array.removeAll()
        
        
        let currentUser = FIRAuth.auth()?.currentUser
        GetItems_Sell(idToken: g_current_fireToken, apiver: 1, maxItemID: Int.max, expiryStart: 0, expiryEnd: Int.max, priceH: 2147483647, priceL: 0, limit: 6, sellerID: (currentUser?.uid)!)
        stopRefresher()
        SellCollectionView.reloadData()
    }
    
    //Reload Data====================================================================================
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
        //Bottom Refresh
        
        if scrollView == SellCollectionView{
            
            if ((scrollView.contentOffset.y + scrollView.frame.size.height) >= scrollView.contentSize.height)
            {
                //print("came to last row")
                
                if searchActive == false {
                    //print("test")
                    
                    if Reload_Flag {
                        let currentUser = FIRAuth.auth()?.currentUser
                        GetItems_Sell(idToken: g_current_fireToken, apiver: 1, maxItemID: Int(small_DataArry[5].itemId)!, expiryStart: 0, expiryEnd: Int.max, priceH: 2147483647, priceL: 0, limit: 6, sellerID: (currentUser?.uid)!)
                    }
                }
            }
        }
    }
    
    
    func stopRefresher() {
        self.refreshControl.endRefreshing()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if(filtered.count == 0){
            searchActive = false;
            searchBar.text = ""
        } else {
            searchActive = true;
        }
        
        if g_sel_index_3 == -2 {
            
            g_sel_index_3 = -1
            loadData()
        }
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onTappedLogOutButton(_ sender: Any) {
        
        if g_ByLogin_GphcSignUp ==  true {
            var viewControllers = self.navigationController?.viewControllers
            viewControllers?.removeLast(3)
            self.navigationController?.setViewControllers(viewControllers!, animated: true)
            return
        }
        
        if g_ByLoginSignUp == false {
            self.navigationController?.popViewController(animated: true)
        } else {
            var viewControllers = self.navigationController?.viewControllers
            viewControllers?.removeLast(4)
            self.navigationController?.setViewControllers(viewControllers!, animated: true)
        }
    }
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {

        if searchActive == false {
            return g_Sell_Array.count
        } else {
            return filtered.count
        }
        
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SellCollectionCell", for: indexPath as IndexPath) as! SellCollectionCell
        
        cell.backgroundColor =  UIColor.clear
        
        //Cell shape
        cell.Round_View.layer.borderColor = UIColor.white.cgColor
        cell.Round_View.layer.borderWidth = 2
        
        
        if searchActive == false {
            
//            DispatchQueue.main.async {
//                
//                cell.name.text = g_Sell_Array[indexPath.row].brand
//                cell.date.text = GetStrDate(timestamp: g_Sell_Array[indexPath.row].expiryDateTime)
//                
//                let poundString = String(format: "%.02f", Double(g_Sell_Array[indexPath.row].price) / 100)
//                cell.price.text = "£\(poundString)"     //170,00
//                
//                
//                let storage = FIRStorage.storage()
//                var reference: FIRStorageReference!
//                reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sell_Array[indexPath.row].sellerId)/\(g_Sell_Array[indexPath.row].itemUUID)/brand.jpg")
//                cell.Image?.sd_setShowActivityIndicatorView(true)
//                cell.Image?.sd_setIndicatorStyle(.gray)
//                cell.Image?.sd_setImage(with: reference)
//
//            }
            
            DispatchQueue.main.async {
                
                cell.name.text = g_Sell_Array[indexPath.row].brand
                cell.date.text = GetStrDate(timestamp: g_Sell_Array[indexPath.row].expiryDateTime)

                let poundString = String(format: "%.02f", Double(g_Sell_Array[indexPath.row].price) / 100)
                cell.price.text = "£\(poundString)"     //170,00
                
                
                let storage = FIRStorage.storage()
                var reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(g_Sell_Array[indexPath.row].sellerId)/\(g_Sell_Array[indexPath.row].itemUUID)/brand.jpg")
                reference.downloadURL { (url, error) in
                    
                    if let error = error {
                        // Uh-oh, an error occurred!
                        cell.Image.image = UIImage(named: "Pill.png")
                    } else {
                        // Data for "images/island.jpg" is returned
                        cell.Image?.sd_setShowActivityIndicatorView(true)
                        cell.Image?.sd_setIndicatorStyle(.gray)
                        cell.Image?.sd_setImage(with: url)
                    }
                }
            }
            
        }
            
        else {
//            DispatchQueue.main.async {
//                
//                cell.name.text = self.filtered[indexPath.row].brand
//                cell.date.text = GetStrDate(timestamp: self.filtered[indexPath.row].expiryDateTime)
//                
//                let poundString = String(format: "%.02f", Double(self.filtered[indexPath.row].price) / 100)
//                cell.price.text = "£\(poundString)"     //170,00
//                
//                let storage = FIRStorage.storage()
//                var reference: FIRStorageReference!
//                reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(self.filtered[indexPath.row].sellerId)/\(self.filtered[indexPath.row].itemUUID)/brand.jpg")
//                cell.Image?.sd_setShowActivityIndicatorView(true)
//                cell.Image?.sd_setIndicatorStyle(.gray)
//                
//                cell.Image?.sd_setImage(with: reference)
//            }
            
            
            DispatchQueue.main.async {
                
                cell.name.text = self.filtered[indexPath.row].brand
                cell.date.text = GetStrDate(timestamp: self.filtered[indexPath.row].expiryDateTime)

                let poundString = String(format: "%.02f", Double(self.filtered[indexPath.row].price) / 100)
                cell.price.text = "£\(poundString)"     //170,00
                
                
                
                let storage = FIRStorage.storage()
                var reference = storage.reference(forURL: "gs://pharmacy-165422.appspot.com/items/\(self.filtered[indexPath.row].sellerId)/\(self.filtered[indexPath.row].itemUUID)/brand.jpg")
                reference.downloadURL { (url, error) in
                    
                    if let error = error {
                        // Uh-oh, an error occurred!
                        cell.Image.image = UIImage(named: "Pill.png")
                    } else {
                        // Data for "images/island.jpg" is returned
                        cell.Image?.sd_setShowActivityIndicatorView(true)
                        cell.Image?.sd_setIndicatorStyle(.gray)
                        cell.Image?.sd_setImage(with: url)
                    }
                }
            }

            
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        
        let newCellWidth = 180 * ScreenWidth / 375
        let newCellHeight = 230 * ScreenWidth / 375
        
        return CGSize(width: newCellWidth, height: newCellHeight)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 3.5 * ScreenWidth / 375 - 1;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 3.5 * ScreenWidth / 375 - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    // MARK: - UICollectionViewDelegate protocol
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        //print("You selected cell #\(indexPath.item)!")
        
        if searchActive == false {
            
            g_FirstVistFlag = true
            
            g_sel_index_3 = indexPath.item
            self.performSegue(withIdentifier: StorySegues.FromSellTabToSellEdit.rawValue, sender: self)
        }
            
        else {
            if let search_index = g_Sell_Array.index(where: {$0.itemId == filtered[indexPath.item].itemId}) {
                g_sel_index_3 = search_index
                self.performSegue(withIdentifier: StorySegues.FromSellTabToSellEdit.rawValue, sender: self)
            }
        }
    }
    
    
    
    //================================================================================
    // check stripeAccountID in firebase
    //
    func Check_stripeAccountID(completionHandler: @escaping (_ success: String) -> ()) {
        
        let currentUser = FIRAuth.auth()?.currentUser
        let Ref = FIRDatabase.database().reference().child("readOnlyUserIDs").child((currentUser?.uid)!)
        
        var handle: UInt = 0
        handle = Ref.observe(.value, with: { (snapshot: FIRDataSnapshot!) in
            
            if snapshot.exists() {
                
                Ref.removeObserver(withHandle: handle)
                
                if let dict = snapshot.value as?  NSDictionary {
                    //print(dict)
                    
                    if let customerID = dict["stripeAccountID"] as? String {
                        completionHandler(customerID)
                    } else {
                        completionHandler("")
                    }
                    
                } else {
                    completionHandler("")
                }
            }
            else {
                //print("snapshot exists")
                completionHandler("")
            }
        })
    }

    //Connect Strip
    @IBAction func onTappedAddSellButton(_ sender: Any) {
        
        Check_stripeAccountID(completionHandler: { success in
            if success != "" {
                self.performSegue(withIdentifier: StorySegues.FromSellTabToSellAdd.rawValue, sender: self)
                
            } else {
                self.background_View.fadeIn(duration: 0.0, delay: 0.0)
                self.background_View.backgroundColor = UIColor(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha: 0.6)
                self.stripeConect_View.fadeIn(duration: 0.3, delay: 0.3)
            }
        })
    }
    
    @IBAction func onTappedConnectStripeButton(_ sender: Any) {
        
        let uuid = UUID().uuidString
        print(uuid)
        
        var CLIENT_ID =  "ca_ASOPSsjyDsjKFTzKZcVO2oH1MDZh38mP"
        //"ca_ASOPst5JEKmjFZxXCZT2aZP6FPGf9mPA"
        
        //             http://pharmacy.zavvytech.co.uk/connectStripe?state={UUID}&scope=read_write&code={account_code}
        
//        var authURL = "https://connect.stripe.com/oauth/authorize?response_type=code&client_id=" + CLIENT_ID +
//            "&scope=read_write&state=" + uuid;
        var authURL = "https://connect.stripe.com/oauth/authorize?response_type=code&client_id=" + CLIENT_ID +
            "&scope=read_write&state=" + uuid;
        print(authURL)
        
        UIApplication.shared.openURL(URL(string: authURL)!)
        
//        background_View.backgroundColor = UIColor.clear
//        stripeConect_View.fadeOut(duration: 0.0, delay: 0.0)
//        background_View.fadeOut(duration: 0.0, delay: 0.0)
    }
    
    @IBAction func onTappedCancelButton(_ sender: Any) {
        background_View.backgroundColor = UIColor.clear
        stripeConect_View.fadeOut(duration: 0.0, delay: 0.0)
        background_View.fadeOut(duration: 0.0, delay: 0.0)
    }
    
    
    
    //================================================================================
    // Search delegate
    //
    //================================================================================
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchBar.text == "" {
            
            let count = g_Sell_Array.count
            filtered.removeAll()
            
            searchActive = false
            
            self.SellCollectionView.reloadData()
            searchBar.resignFirstResponder()
            return
        }
//        
//        print(searchText)
//        let count = g_Sell_Array.count
//        
//        filtered.removeAll()
//        
//        for i in 0 ... count - 1 {
//            let temp: NSString = g_Sell_Array[i].brand as NSString
//            let range = temp.range(of: searchText, options: .caseInsensitive)
//            if range.location != NSNotFound {
//                filtered.append(g_Sell_Array[i])
//            }
//        }
//        
//        if(filtered.count == 0){
//            searchActive = false;
//        } else {
//            searchActive = true;
//        }
//        self.SellCollectionView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        //searchBar.resignFirstResponder()
        //searchActive = false;
        if searchBar.text == "" {
            
            let count = g_Sell_Array.count
            filtered.removeAll()
            
            searchActive = false
            
            self.SellCollectionView.reloadData()
            searchBar.resignFirstResponder()
            return
        }
        
        //print(searchBar.text)
        let count = g_Sell_Array.count
        
        filtered.removeAll()
        
        for i in 0 ... count - 1 {
            let temp: NSString = g_Sell_Array[i].brand as NSString
            let range = temp.range(of: searchBar.text!, options: .caseInsensitive)
            if range.location != NSNotFound {
                filtered.append(g_Sell_Array[i])
            }
        }
        
        if(filtered.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.SellCollectionView.reloadData()
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        //searchActive = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    
    
    // apiver       1
    // maxItemID    9223372036854775807
    // expiryStart  0
    // expiryEnd    9223372036854775807
    // priceH       2147483647
    // priceL       0
    // limit        20
    // buyerID      qzeVbt808GRG4hieNjIga1cNvWL2
    
    //=========================================================================================
    //
    // Get GetItems for Sell
    //
    //=========================================================================================
    func GetItems_Sell(idToken: String, apiver: Int, maxItemID: Int, expiryStart: Int, expiryEnd: Int, priceH: Int, priceL: Int, limit:Int, sellerID:String) {
        
        self.Reload_Flag = false
        searchActive = false
        filtered.removeAll()
        searchBar.text = ""
        
        self.small_DataArry.removeAll()
        //g_Sell_Array.removeAll()
        let serviceObj = ServiceClass()
        
        ProgressHUD.show("Loading...")
        serviceObj.serviceGetMethodWithAPIHeaderValue1(apiValue: GlobalVar.APIHEADER, headerValue: "\(GlobalVar.GetItems)\(apiver)/\(maxItemID)/\(expiryStart)/\(expiryEnd)/\(priceH)/\(priceL)/\(limit)?sellerID=\(sellerID)", fields: idToken, completion: {(responseObject) in
            
            if (responseObject != nil ) {
                
                if responseObject["items"] == nil {
                    ProgressHUD.dismiss()
                    //self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
                    return
                }
                
                let items_dict = responseObject["items"] as! NSArray
                if (items_dict != nil ) {
                    
                    for items_data in items_dict {
                        let dict = items_data as! [String: AnyObject]
                        
                        var temp: Bought_Info = Bought_Info(success: false, itemId: "", itemUUID: "", brand: "", description: "", expiryDateTime: "", price: -1, quantity: "", sellerId: "", buyerId: "", purchaseDate: "", dispatchDate: "", estDeliveryDate: "", uploadDate: "", lastEdited: "")
                        
                        
                        temp.success    = dict["success"] as! Bool
                        temp.itemId     = dict["itemId"] as! String
                        temp.itemUUID   = dict["itemUUID"] as! String
                        temp.brand      = dict["brand"] as! String
                        
                        temp.description    = dict["description"] as! String
                        temp.expiryDateTime = dict["expiryDateTime"] as! String
                        temp.price          = dict["price"] as! Int
                        temp.quantity       = dict["quantity"] as! String
                        
                        temp.sellerId       = dict["sellerId"] as! String
                        //temp.buyerId        = dict["buyerId"] as! String
                        temp.purchaseDate   = dict["purchaseDate"] as! String
                        temp.dispatchDate   = dict["dispatchDate"] as! String
                        
                        temp.estDeliveryDate = dict["estDeliveryDate"] as! String
                        temp.uploadDate      = dict["uploadDate"] as! String
                        temp.lastEdited      = dict["lastEdited"] as! String
                        
                        self.small_DataArry.append(temp)
                        g_Sell_Array.append(temp)
                        //self.SellCollectionView.reloadData()
                        
                    }
                    
                    if self.small_DataArry.count == limit {
                        self.Reload_Flag = true
                    } else {
                        self.Reload_Flag = false
                    }
                    
                    DispatchQueue.main.async {
                        ProgressHUD.dismiss()
                        self.SellCollectionView.reloadData()
                    }
                    
                } else {
                }
            } else {
                ProgressHUD.dismiss()
                //self.view.makeToast("Maybe Internet is busy now.", duration: 3.0, position: .bottom)
            }
        })
    }
    
    
}




