//
//  SoldViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/29/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import FSCalendar
    
    
class SoldViewController: UIViewController, FSCalendarDataSource, FSCalendarDelegate {
    
    @IBOutlet weak var Calendar_Back_View: UIView!
    var str_selectDate : String = ""    // Calendar
    
    var DispatchOrDelivery_Flag: Bool = false // false: Dispatch, true: Delivery
    @IBOutlet weak var Dispatch_date_Text: UITextField!
    @IBOutlet weak var Delivery_date_Text: UITextField!
    
    
    @IBOutlet weak var WeekDay_Label: UILabel!
    @IBOutlet weak var Month_Label: UILabel!
    @IBOutlet weak var Date_Label: UILabel!
    @IBOutlet weak var Year_Label: UILabel!
    
    /*@IBOutlet weak var product_Image1: UIImageView!
    @IBOutlet weak var product_Image2: UIImageView!
    @IBOutlet weak var product_Image3: UIImageView!
    
    @IBOutlet weak var Brand_Text: UITextField!
    @IBOutlet weak var Brand_Len_Label: UILabel!
    
    @IBOutlet weak var Price_Text: UITextField!
    
    @IBOutlet weak var Description_Text: UITextField!
    @IBOutlet weak var description_Len_Label: UILabel!
    
    @IBOutlet weak var Expiry_Text: UITextField!
    
    @IBOutlet weak var Quantity_Text: UITextField!
    @IBOutlet weak var Quantity_Len_Label: UILabel!
    */
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
        
        // Do any additional setup after loading the view.
        
        Calendar_Back_View.layer.cornerRadius = 3.0
        Calendar_Back_View.fadeOut(duration: 0.0, delay: 0.0)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        showCurrentDate()
    }
    
//    private static int afterStripeFees(int pricePennies) {
//    float appFeePercent = (float) FirebaseRemoteConfig.getInstance().getDouble("stripe_app_fee");
//    int appFee = Math.round((appFeePercent * pricePennies) / 100);
//    int minusAppFee = pricePennies - appFee;
//    int minusPercentFee = Math.min(Math.round(minusAppFee * 0.986f), minusAppFee - 1);
//    return minusPercentFee - 20;
//    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    override var preferredStatusBarStyle: UIStatusBarStyle {
//        return .lightContent
//    }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    // Calendar Back View ==========================================
    @IBAction func onTappedCancelCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }

    @IBAction func onTappedDoneCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    
    // Select Dispatch and Delivery Buttons
    @IBAction func onTappedDispatchButton(_ sender: Any) {
        DispatchOrDelivery_Flag = false
        Calendar_Back_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    @IBAction func onTappedDeliveryButton(_ sender: Any) {
        DispatchOrDelivery_Flag = true
        Calendar_Back_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    
    
    // Calendar =====================================================
    //Select Point
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        
        str_selectDate = dateFormatter.string(from: date)
        
        if DispatchOrDelivery_Flag == false {
            Dispatch_date_Text.text = str_selectDate
        } else {
            Delivery_date_Text.text = str_selectDate
        }
        
        
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: date)
        
        let weekday = date.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: date)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func showCurrentDate() {
        
        let todayDate = Date()
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: todayDate)
        
        let weekday = todayDate.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: todayDate)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: todayDate)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
    }
}
