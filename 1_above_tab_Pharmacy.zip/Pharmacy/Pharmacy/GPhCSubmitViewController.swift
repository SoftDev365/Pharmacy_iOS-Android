//
//  GPhCSubmitViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import JVFloatLabeledTextField

class GPhCSubmitViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var GPhc_number_Text: UITextField!
    @IBOutlet weak var GPhc_number_View: UIView!
    
    @IBOutlet weak var Round_SUBMIT_Button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Text Delegate
        GPhc_number_Text.delegate = self
        GPhc_number_Text.keyboardType = .numberPad

        // tags
        GPhc_number_Text.tag = 1
        
        // Round Button
        Round_SUBMIT_Button.layer.cornerRadius = 3.0
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // User finished typing (hit return): hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            GPhc_number_View.backgroundColor = UIColor.init(red: 239.0/255.0, green: 47.0/255.0, blue: 106.0/255.0, alpha: 1.0)

        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField.tag {
        case 1:
            GPhc_number_View.backgroundColor = UIColor.gray
        default: break
        }
    }

    @IBAction func onTappedSUBMITButton(_ sender: Any) {
        
        var goFlag: Bool = true
        if GPhc_number_Text.text == "" {
            UIApplication.shared.windows.first?.makeToast("Please insert your GPhc number.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if (GPhc_number_Text.text?.characters.count)! != 7 {
            UIApplication.shared.windows.first?.makeToast("You must input 7 length GPhc number.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        
        if goFlag == true {
            Round_SUBMIT_Button.setTitle("FINDING PHONE NUMBER...", for: .normal)
            Round_SUBMIT_Button.isUserInteractionEnabled = false
            
            let when = DispatchTime.now() + 2 // change 2 to desired number of seconds
            DispatchQueue.main.asyncAfter(deadline: when) {
                // Your code with delay
                self.Round_SUBMIT_Button.isUserInteractionEnabled = true
                self.Round_SUBMIT_Button.setTitle("SUBMIT", for: .normal)
                self.performSegue(withIdentifier: StorySegues.FromGPhcSubmitToVerification.rawValue, sender: self)
            }
        }
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
