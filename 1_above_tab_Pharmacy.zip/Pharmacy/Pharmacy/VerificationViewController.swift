//
//  VerificationViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit

class VerificationViewController: UIViewController {

    //Hide, Show View
    @IBOutlet weak var including_CallMe_View: UIView!
    @IBOutlet weak var including_SubMit_View: UIView!
    
    @IBOutlet weak var verifyCode_Text: UITextField!
    
    // Round Button
    @IBOutlet weak var CallMe_Button: UIButton!
    @IBOutlet weak var Submit_Button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        including_SubMit_View.fadeOut(duration: 0.0, delay: 0.0)
        
        verifyCode_Text.keyboardType = .numberPad
        
        CallMe_Button.layer.cornerRadius = 3.0
        Submit_Button.layer.cornerRadius = 3.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onTappedCallMeButton(_ sender: Any) {
  
        CallMe_Button.setTitle("REQUESTING CALL...", for: .normal)
        let when = DispatchTime.now() + 2 // change 2 to desired number of seconds
        DispatchQueue.main.asyncAfter(deadline: when) {
            // Your code with delay
            self.including_CallMe_View.fadeOut(duration: 0.0, delay: 0.0)
            self.including_SubMit_View.fadeIn(duration: 0.3, delay: 0.3)
            self.CallMe_Button.setTitle("CALL ME", for: .normal)
        }
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedSubMitButton(_ sender: Any) {
        
        var goFlag: Bool = true
        if verifyCode_Text.text == "" {
            UIApplication.shared.windows.first?.makeToast("Please insert your verification code.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        if (verifyCode_Text.text?.characters.count)! != 8 {
            UIApplication.shared.windows.first?.makeToast("You must input 8 length verification code.", duration: 2.0, position: .bottom)
            goFlag = false
            return
        }
        
        if goFlag == true {
            g_ByLoginSignUp = true
            self.performSegue(withIdentifier: StorySegues.FromVerificationToMain.rawValue, sender: self)
        }
    }
    

}
