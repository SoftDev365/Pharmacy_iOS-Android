//
//  MainViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/27/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit

class MainViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate, UISearchBarDelegate {

    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var BuyCollectionView: UICollectionView!
    @IBOutlet weak var SellCollectionView: UICollectionView!
    
    @IBOutlet weak var boughtTableView: UITableView!
    @IBOutlet weak var soldTableView: UITableView!
    
    // Title Status
    @IBOutlet weak var SearchSmall_Button: UIButton!
    @IBOutlet weak var MoreSmall_Button: UIButton!
    
    // Button Status
    var current_Button_Sel_Number: Int = -1
    
    @IBOutlet weak var Bought_ColorView_1: UIView!
    @IBOutlet weak var Buy_ColorView_2: UIView!
    @IBOutlet weak var Sell_ColorView_3: UIView!
    @IBOutlet weak var Sold_ColorView_4: UIView!
    
    @IBOutlet weak var Bought_ColorButton_1: UIButton!
    @IBOutlet weak var Buy_ColorButton_2: UIButton!
    @IBOutlet weak var Sell_ColorButton_3: UIButton!
    @IBOutlet weak var Sold_ColorButton_4: UIButton!
    
    // Swipe View
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var Swiped_View: UIView!
    
    @IBOutlet weak var swipe_view_1: UIView!
    @IBOutlet weak var swipe_view_2: UIView!
    @IBOutlet weak var swipe_view_3: UIView!
    @IBOutlet weak var swipe_view_4: UIView!
    
    // Top Bar
    @IBOutlet weak var including_Search_View: UIView!
    @IBOutlet weak var including_Title_View: UIView!
    
    @IBOutlet weak var Search_Text: UITextField!
    
    // Large Search Button
    @IBOutlet weak var LargeSearch_Button: UIButton!
    
    // Settings and Logout View
    @IBOutlet weak var Settings_View: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.hideKeyboardWhenTappedAround()
        UpdateSearchStatus_Hide()
        
        // When Keyboard Show
        /*NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: NSNotification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: NSNotification.Name.UIKeyboardDidHide, object: nil)*/
   
        // Search Bar
        searchBar.delegate = self
        self.searchBar.backgroundImage = UIImage()
        
        Search_Text.delegate = self
        Search_Text.delegate = self
        
        // tags
        Search_Text.tag = 1
     
        // Search Text
        let color = UIColor.init(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha: 1.0)
        Search_Text.attributedPlaceholder = NSAttributedString(string: Search_Text.placeholder!, attributes: [NSForegroundColorAttributeName : color])
        
        // Settings and Logout View
        Settings_View.fadeOut(duration: 0.0, delay: 0.0)
        Settings_View.layer.cornerRadius = 3.0
        
        // Swipe View
        let swiperight = UISwipeGestureRecognizer(target: self, action: #selector(self.getSwipeAction(_:)))
        swiperight.direction = .right
        Swiped_View.addGestureRecognizer(swiperight)
        let swipeleft = UISwipeGestureRecognizer(target: self, action: #selector(self.getSwipeAction(_:)))
        swiperight.direction = .left
        Swiped_View.addGestureRecognizer(swipeleft)
        
        // Button Status
        pageControl.isHidden = true
        InitLoad_SwipeDate()
        
        // Collection View
        BuyCollectionView.delegate = self
        BuyCollectionView.dataSource = self
        
        SellCollectionView.delegate = self
        SellCollectionView.dataSource = self
        
        BuyCollectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        SellCollectionView.backgroundColor = UIColor.clear.withAlphaComponent(0)
        
        // Table View
        boughtTableView.delegate = self
        boughtTableView.dataSource = self
        
        soldTableView.delegate = self
        soldTableView.dataSource = self
        
        boughtTableView.backgroundColor = UIColor.clear
        soldTableView.backgroundColor = UIColor.clear
        
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func InitLoad_SwipeDate() {

        pageControl.currentPage = 1
        pageControl.numberOfPages = 4
        current_Button_Sel_Number = pageControl.currentPage
        self.UpdateButtonStatus()
    }
    
    func getSwipeAction( _ recognizer : UISwipeGestureRecognizer){
        
        if pageControl.numberOfPages == 0 || pageControl.numberOfPages == 1 {
            return
        }
        var index = (recognizer.direction == .right) ? -1 : 1
        index = (pageControl.currentPage + index < 0) ? pageControl.numberOfPages - 1 : index
        pageControl.currentPage = (pageControl.currentPage + index) % pageControl.numberOfPages
        let direction = (recognizer.direction == .right) ? kCATransitionFromLeft :  kCATransitionFromRight
        animateImageView(direction: direction)
        
        current_Button_Sel_Number = pageControl.currentPage
        UpdateButtonStatus()
    }
    
    func animateImageView(direction: String) {
        CATransaction.begin()
        CATransaction.setAnimationDuration(0.5)
        
        let transition = CATransition()
        transition.type = kCATransitionPush
        transition.subtype = direction
        
        self.Swiped_View.layer.add(transition, forKey: kCATransition)
        CATransaction.commit()
    }
    
    func UpdateButtonStatus() {
        
        Settings_View.fadeOut(duration: 0.0, delay: 0.0)
        
        let scaleX: Int = (4 - pageControl.numberOfPages) * 8
        pageControl.transform = CGAffineTransform(translationX: CGFloat(scaleX), y: 0)
        
        let myGrayColor = UIColor.init(red: 200.0/255.0, green: 200.0/255.0, blue: 200.0/255.0, alpha: 1.0)
        
        switch current_Button_Sel_Number {
        case -1:
            Bought_ColorView_1.backgroundColor = UIColor.clear
            Buy_ColorView_2.backgroundColor = UIColor.init(red: 231.0/255.0, green: 67.0/255.0, blue: 117.0/255.0, alpha: 1.0)
            Sell_ColorView_3.backgroundColor = UIColor.clear
            Sold_ColorView_4.backgroundColor = UIColor.clear
            
            Bought_ColorButton_1.setTitleColor(myGrayColor, for: .normal)
            Buy_ColorButton_2.setTitleColor(UIColor.white, for: .normal)
            Sell_ColorButton_3.setTitleColor(myGrayColor, for: .normal)
            Sold_ColorButton_4.setTitleColor(myGrayColor, for: .normal)
            
            swipe_view_1.isHidden = true
            swipe_view_2.isHidden = false
            swipe_view_3.isHidden = true
            swipe_view_4.isHidden = true
        
        case 0:
            Bought_ColorView_1.backgroundColor = UIColor.init(red: 231.0/255.0, green: 67.0/255.0, blue: 117.0/255.0, alpha: 1.0)
            Buy_ColorView_2.backgroundColor = UIColor.clear
            Sell_ColorView_3.backgroundColor = UIColor.clear
            Sold_ColorView_4.backgroundColor = UIColor.clear
            
            Bought_ColorButton_1.setTitleColor(UIColor.white, for: .normal)
            Buy_ColorButton_2.setTitleColor(myGrayColor, for: .normal)
            Sell_ColorButton_3.setTitleColor(myGrayColor, for: .normal)
            Sold_ColorButton_4.setTitleColor(myGrayColor, for: .normal)
            
            swipe_view_1.isHidden = false
            swipe_view_2.isHidden = true
            swipe_view_3.isHidden = true
            swipe_view_4.isHidden = true
            
            LargeSearch_Button.setBackgroundImage(UIImage(named: "Search_1.png"), for: .normal)
            
        case 1:
            Bought_ColorView_1.backgroundColor = UIColor.clear
            Buy_ColorView_2.backgroundColor = UIColor.init(red: 231.0/255.0, green: 67.0/255.0, blue: 117.0/255.0, alpha: 1.0)
            Sell_ColorView_3.backgroundColor = UIColor.clear
            Sold_ColorView_4.backgroundColor = UIColor.clear
            
            Bought_ColorButton_1.setTitleColor(myGrayColor, for: .normal)
            Buy_ColorButton_2.setTitleColor(UIColor.white, for: .normal)
            Sell_ColorButton_3.setTitleColor(myGrayColor, for: .normal)
            Sold_ColorButton_4.setTitleColor(myGrayColor, for: .normal)
            
            swipe_view_1.isHidden = true
            swipe_view_2.isHidden = false
            swipe_view_3.isHidden = true
            swipe_view_4.isHidden = true
         
            LargeSearch_Button.setBackgroundImage(UIImage(named: "Search_1.png"), for: .normal)
            
        case 2:
            Sell_ColorView_3.backgroundColor = UIColor.init(red: 231.0/255.0, green: 67.0/255.0, blue: 117.0/255.0, alpha: 1.0)
            Buy_ColorView_2.backgroundColor = UIColor.clear
            Bought_ColorView_1.backgroundColor = UIColor.clear
            Sold_ColorView_4.backgroundColor = UIColor.clear
            
            Sell_ColorButton_3.setTitleColor(UIColor.white, for: .normal)
            Buy_ColorButton_2.setTitleColor(myGrayColor, for: .normal)
            Bought_ColorButton_1.setTitleColor(myGrayColor, for: .normal)
            Sold_ColorButton_4.setTitleColor(myGrayColor, for: .normal)
            
            swipe_view_1.isHidden = true
            swipe_view_2.isHidden = true
            swipe_view_3.isHidden = false
            swipe_view_4.isHidden = true
            
            LargeSearch_Button.setBackgroundImage(UIImage(named: "Add_1.png"), for: .normal)
            
        case 3:
            Sold_ColorView_4.backgroundColor = UIColor.init(red: 231.0/255.0, green: 67.0/255.0, blue: 117.0/255.0, alpha: 1.0)
            Buy_ColorView_2.backgroundColor = UIColor.clear
            Bought_ColorView_1.backgroundColor = UIColor.clear
            Sell_ColorView_3.backgroundColor = UIColor.clear
            
            Sold_ColorButton_4.setTitleColor(UIColor.white, for: .normal)
            Buy_ColorButton_2.setTitleColor(myGrayColor, for: .normal)
            Bought_ColorButton_1.setTitleColor(myGrayColor, for: .normal)
            Sell_ColorButton_3.setTitleColor(myGrayColor, for: .normal)
            
            swipe_view_1.isHidden = true
            swipe_view_2.isHidden = true
            swipe_view_3.isHidden = true
            swipe_view_4.isHidden = false
            
            LargeSearch_Button.setBackgroundImage(UIImage(named: "Search_1.png"), for: .normal)
            
        default:
            break
        }
    }
    
    func UpdateSearchStatus_Show() {
//        including_Search_View.isHidden = false
//        including_Title_View.isHidden = true
    }
    
    func UpdateSearchStatus_Hide() {
//        including_Search_View.isHidden = true
//        including_Title_View.isHidden = false
    }
    
    @IBAction func onTappedHideSearchButton(_ sender: Any) {
        UpdateSearchStatus_Hide()
    }
    
    @IBAction func onTappedShowSearchButton(_ sender: Any) {
        UpdateSearchStatus_Show()
    }
    
    @IBAction func onTappedMainSearchButton(_ sender: Any) {
        if current_Button_Sel_Number == 2 {
            self.performSegue(withIdentifier: StorySegues.FromMainToSellAdd.rawValue, sender: self)
        } else {
            UpdateSearchStatus_Show()
        }
    }
    
    //More Button
    @IBAction func onTappedMoreShowButton(_ sender: Any) {
        Settings_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    
    @IBAction func onTappedSettingsButton(_ sender: Any) {
        Settings_View.fadeOut(duration: 0.3, delay: 0.3)
    }

    @IBAction func onTappedSignOutButton(_ sender: Any) {
        Settings_View.fadeOut(duration: 0.5, delay: 0.5, completion: {_ in
            
            if g_ByLoginSignUp == false {
                self.navigationController?.popViewController(animated: true)
            } else {
                var viewControllers = self.navigationController?.viewControllers
                viewControllers?.removeLast(4)
                self.navigationController?.setViewControllers(viewControllers!, animated: true)
            }
        })
    }
    
    // Top View 4 Buttons
    @IBAction func onTappedBought_1_Button(_ sender: Any) {
        pageControl.currentPage = 0
        current_Button_Sel_Number = pageControl.currentPage
        self.UpdateButtonStatus()
    }
    
    @IBAction func onTappedBuy_2_Button(_ sender: Any) {
        pageControl.currentPage = 1
        current_Button_Sel_Number = pageControl.currentPage
        self.UpdateButtonStatus()
    }
    
    @IBAction func onTappedSell_3_Button(_ sender: Any) {
        pageControl.currentPage = 2
        current_Button_Sel_Number = pageControl.currentPage
        self.UpdateButtonStatus()
    }
    
    @IBAction func onTappedSold_4_Button(_ sender: Any) {
        pageControl.currentPage = 3
        current_Button_Sel_Number = pageControl.currentPage
        self.UpdateButtonStatus()
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            self.LargeSearch_Button.frame.origin.y -= 300
        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField.tag {
        case 1:
            self.LargeSearch_Button.frame.origin.y += 300
        default: break
        }
    }
    
    // When KeyBoard Show
    /*func keyboardWillShow(notification: NSNotification) {
        
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if view.frame.origin.y == 0{
                let height = keyboardSize.height
                
                self.LargeSearch_Button.frame.origin.y -= height
            }
            
        }
        
    }
    func keyboardWillHide(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if view.frame.origin.y == 0 {
                let height = keyboardSize.height
                self.LargeSearch_Button.frame.origin.y += height
            }
            
        }
    }*/
    
    
    
    
    var item_images1 = [UIImage(named: "Collection_1"), UIImage(named: "Collection_2")]
    var item_name1 = ["Blue iron1", "Audio tech1"]
    var item_date1 = ["28 Sep 2018", "22 Feb 2019"]
    var item_price1 = ["£25.01", "£170.01"]
    
    var item_images2 = [UIImage(named: "Collection_1"), UIImage(named: "Collection_2")]
    var item_name2 = ["Blue iron2", "Audio tech2"]
    var item_date2 = ["28 Sep 2018", "22 Feb 2019"]
    var item_price2 = ["£25.02", "£170.02"]
    
    //Collection ==========================================================================================
    //
    //
    // tell the collection view how many cells to make
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if collectionView == self.BuyCollectionView {
             return item_images1.count
        } else {
            return item_images2.count
        }
    }
    
    // make a cell for each cell index path
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == self.BuyCollectionView {
            // get a reference to our storyboard cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BuyCollectionCell", for: indexPath as IndexPath) as! BuyCollectionCell
            
            cell.backgroundColor =  UIColor.clear
            
            //Cell shape
            cell.Round_View.layer.borderColor = UIColor.white.cgColor
            cell.Round_View.layer.borderWidth = 2

            cell.Image.image = item_images1[indexPath.item]
            cell.name.text = item_name1[indexPath.item]
            cell.date.text = item_date1[indexPath.item]
            cell.price.text = item_price1[indexPath.item]
            
            return cell

        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SellCollectionCell", for: indexPath as IndexPath) as! SellCollectionCell
            
            cell.backgroundColor =  UIColor.clear
            
            //Cell shape
            cell.Round_View.layer.borderColor = UIColor.white.cgColor
            cell.Round_View.layer.borderWidth = 2
            
            cell.Image.image = item_images2[indexPath.item]
            cell.name.text = item_name2[indexPath.item]
            cell.date.text = item_date2[indexPath.item]
            cell.price.text = item_price2[indexPath.item]
            
            return cell
        }
        
        /*cell.myImageView.sd_setShowActivityIndicatorView(true)
         cell.myImageView.sd_setIndicatorStyle(.white)
         let url = "http://35.177.9.16:8080/upload/category?url=\(g_category_Array[indexPath.item].id).png"
         cell.myImageView.sd_setImage(with: URL(string: url))
         cell.myImageView.sd_setImage(with: URL(string: g_ProfileInfo.user_rest[indexPath.item].BackgroundImage_Url))*/
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        // your code here
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        
        let newCellWidth = 180 * ScreenWidth / 375
        let newCellHeight = 230 * ScreenWidth / 375
        
        return CGSize(width: newCellWidth, height: newCellHeight)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 3.5 * ScreenWidth / 375 - 1;
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        
        let ScreenSize = UIScreen.main.bounds
        let ScreenWidth = ScreenSize.width
        return 3.5 * ScreenWidth / 375 - 1;
    }
    
    //Changing the color when tapped
    // change background color when user touches cell
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        //let cell = collectionView.cellForItem(at: indexPath)
        //cell?.backgroundColor = UIColor.cyan
    }
    
    // MARK: - UICollectionViewDelegate protocol
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // handle tap events
        print("You selected cell #\(indexPath.item)!")

        if collectionView == self.BuyCollectionView {
            
            g_BoughtORBuy_Flag = false //false: Buy, true: Bought
            self.performSegue(withIdentifier: StorySegues.FromMainToBuySub.rawValue, sender: self)
            
        } else {
            self.performSegue(withIdentifier: StorySegues.FromMainToSellSub.rawValue, sender: self)
        }
    }
    
    
    var data_images1 = [UIImage(named: "Collection_4")]
    var data_name1 = ["JVC remote1"]
    var data_date1 = ["4 May 2019"]
    var data_dispatch1 = ["20 Jul 2017"]
    var data_delivery1 = ["24 Jul 2017"]
    var data_call1 = ["07812371901"]
    
    var data_images2 = [UIImage(named: "Collection_4"), UIImage(named: "Collection_5")]
    var data_name2 = ["Braeburn", "minions handwarmers"]
    var data_date2 = ["11 Aug 2017", "23 Dec 2022"]
    var data_dispatch2 = ["unknown", "unknown"]
    var data_delivery2 = ["unknown", "unknown"]
    var data_address2 = ["Boots 6 Eve's Corner Danbury CHELMSFORD Essex CM34QF", "Boots 6 Eve's Corner Danbury CHELMSFORD Essex CM34QF"]

    //================================================================================
    // table delegate
    //
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count:Int?
        if tableView == self.boughtTableView {
            count = data_images1.count
        }
        
        if tableView == self.soldTableView {
            count = data_images2.count
        }
        return count!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell_return: UITableViewCell?
        
        if tableView == self.boughtTableView {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "BoughtTableCell") as? BoughtTableCell
            
            cell?.productImage?.image = data_images1[indexPath.row]
            cell?.brand.text = data_name1[indexPath.row]
            cell?.date.text = data_date1[indexPath.row]
            cell?.dispatch.text = data_dispatch1[indexPath.row]
            cell?.delivery.text = data_delivery1[indexPath.row]
            cell?.phoneNum.text = data_call1[indexPath.row]
            
            cell?.select_Button.tag  =  indexPath.row
            
            cell_return = cell
            //return cell!
        }
        
        if tableView == self.soldTableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: "SoldTableCell") as? SoldTableCell
            
            cell?.ProductImage?.image = data_images2[indexPath.row]
            cell?.brand.text = data_name2[indexPath.row]
            cell?.date.text = data_date2[indexPath.row]
            cell?.Dispatch.text = data_dispatch2[indexPath.row]
            cell?.Delivery.text = data_delivery2[indexPath.row]
            cell?.address.text = data_address2[indexPath.row]
            
            cell?.select_Button.tag  =  indexPath.row
            
            cell_return = cell
            //return cell!
        }
        
        return cell_return!
    }
    
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//    }
   
    //Select Table Buttons
    @IBAction func onTappedSoldSelectButton(_ sender: Any) {
        let index = (sender as! UIButton).tag
        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PickTableCell
        //print("select Button!")
        //g_Pick_Restaurant_Id = g_pickTable_Array[index].id

        self.performSegue(withIdentifier: StorySegues.FromMainToSold.rawValue, sender: self)
    }
    @IBAction func onTappedBoughtSelectButton(_ sender: Any) {
        
        let index = (sender as! UIButton).tag
        //let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? PickTableCell
        //print("select Button!")
        //g_Pick_Restaurant_Id = g_pickTable_Array[index].id
        
        g_BoughtORBuy_Flag = true //false: Buy, true: Bought
        self.performSegue(withIdentifier: StorySegues.FromMainToBuySub.rawValue, sender: self)
    }
    
    
    //================================================================================
    // Search delegate
    //
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchBar.text == "" {
            searchBar.resignFirstResponder()
        }
        
        print(searchText)
//        let count = g_chatList_Array.count
//        
//        filtered.removeAll()
//        
//        for i in 0 ... count - 1 {
//            let temp: NSString = g_chatList_Array[i].fullname as NSString
//            let range = temp.range(of: searchText, options: .caseInsensitive)
//            
//            if range.location != NSNotFound {
//                filtered.append(g_chatList_Array[i])
//            }
//        }
//        
//        if(filtered.count == 0){
//            searchActive = false;
//        } else {
//            searchActive = true;
//        }
//        self.tableView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        searchBar.resignFirstResponder()
        
        //searchActive = false;
    }
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        //searchActive = true;
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        //searchActive = false;
    }
    

}




