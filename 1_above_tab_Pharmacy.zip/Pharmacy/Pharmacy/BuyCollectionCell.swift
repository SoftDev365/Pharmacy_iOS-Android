//
//  BuyAndSellCollectionCell.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import Foundation
import UIKit

class BuyCollectionCell: UICollectionViewCell {

    @IBOutlet weak var Round_View: UIView!
    
    @IBOutlet weak var Image: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var price: UILabel!
    
}
