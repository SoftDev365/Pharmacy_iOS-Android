//
//  BuySubViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit

class BuySubViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var Pay_Button: UIButton!
    
    @IBOutlet weak var Payment_View: UIView!
    
    @IBOutlet weak var Payment_Small_View: UIView!
    @IBOutlet weak var Payment_Large_View: UIView!
    
    @IBOutlet weak var Large_UseImageView: UIImageView!
    @IBOutlet weak var Large_NoneImageView: UIImageView!
    
    @IBOutlet weak var CardNum_Text: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        if g_BoughtORBuy_Flag == true {
            Pay_Button.isHidden = true
        } else {
            Pay_Button.isHidden = false
        }

        
        Payment_Small_View.layer.cornerRadius = 3.0
        Payment_Large_View.layer.cornerRadius = 3.0
        
        CardNum_Text.keyboardType = .numberPad
        
        CardNum_Text.delegate = self
        CardNum_Text.delegate = self
        // tags
        CardNum_Text.tag = 1
        
        Large_UseImageView.image = UIImage(named: "purchase_check.png")
        Large_NoneImageView.image = UIImage(named: "purchase_none.png")
        
        
        Payment_View.fadeOut(duration: 0.0, delay: 0.0)
        Payment_Large_View.fadeOut(duration: 0.0, delay: 0.0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        //g_BoughtORBuy_Flag = true //false: Buy, true: Bought
    }

    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // Payment View ================================================
    @IBAction func onTappedPaymentButton(_ sender: Any) {
        Large_UseImageView.image = UIImage(named: "purchase_check.png")
        Large_NoneImageView.image = UIImage(named: "purchase_none.png")
        Payment_Small_View.fadeIn(duration: 0.0, delay: 0.0)
        Payment_Large_View.fadeOut(duration: 0.0, delay: 0.0)
        Payment_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    
    // Payment Small View
    @IBAction func onTappedUseSavedCardButton(_ sender: Any) {
        Payment_Large_View.fadeIn(duration: 0.3, delay: 0.3)
        Payment_Small_View.fadeOut(duration: 0.0, delay: 0.0)
    }
    
    @IBAction func onTappedSmallCancelButton(_ sender: Any) {
        Payment_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    @IBAction func onTappedLargeCancelButton(_ sender: Any) {
        Payment_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    
    @IBAction func onTappedSmallPurchaseButton(_ sender: Any) {
    }
    
    @IBAction func onTappedLargePurchaseButton(_ sender: Any) {
    }
    
    // Payment Large View
    @IBAction func onTappedLargeUseButton(_ sender: Any) {
        Large_UseImageView.image = UIImage(named: "purchase_check.png")
        Large_NoneImageView.image = UIImage(named: "purchase_none.png")
    }
    @IBAction func onTappedLargeNoneButton(_ sender: Any) {
        Large_NoneImageView.image = UIImage(named: "purchase_check.png")
        Large_UseImageView.image = UIImage(named: "purchase_none.png")
    }
    
    // UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // User finished typing (hit return): hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            self.Payment_Large_View.frame.origin.y -= 50
        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch textField.tag {
        case 1:
            self.Payment_Large_View.frame.origin.y += 50
        default: break
        }
    }
}
