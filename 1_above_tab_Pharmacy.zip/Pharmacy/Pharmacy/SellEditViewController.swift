//
//  SellSubViewController.swift
//  Pharmacy
//
//  Created by LEE on 8/28/17.
//  Copyright © 2017 Pharmacy. All rights reserved.
//

import UIKit
import FSCalendar

class SellEditViewController: UIViewController, UITextFieldDelegate, FSCalendarDataSource, FSCalendarDelegate {
    
        
    @IBOutlet weak var Calendar_Back_View: UIView!
    var str_selectDate : String = ""    // Calendar
    
    @IBOutlet weak var WeekDay_Label: UILabel!
    @IBOutlet weak var Month_Label: UILabel!
    @IBOutlet weak var Date_Label: UILabel!
    @IBOutlet weak var Year_Label: UILabel!
    
    @IBOutlet weak var product_Image1: UIImageView!
    @IBOutlet weak var product_Image2: UIImageView!
    @IBOutlet weak var product_Image3: UIImageView!
    
    @IBOutlet weak var Brand_Text: UITextField!
    @IBOutlet weak var Brand_Len_Label: UILabel!
    
    @IBOutlet weak var Price_Text: UITextField!
    @IBOutlet weak var Price_fees_Label: UILabel!
    
    @IBOutlet weak var Description_Text: UITextField!
    @IBOutlet weak var description_Len_Label: UILabel!
    
    @IBOutlet weak var Expiry_Text: UITextField!
    
    @IBOutlet weak var Quantity_Text: UITextField!
    @IBOutlet weak var Quantity_Len_Label: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.hideKeyboardWhenTappedAround()
        
        // Do any additional setup after loading the view.
        
        Calendar_Back_View.layer.cornerRadius = 3.0
        Calendar_Back_View.fadeOut(duration: 0.0, delay: 0.0)

        product_Image1.layer.borderColor = UIColor.white.cgColor
        product_Image1.layer.borderWidth = 1
        product_Image2.layer.borderColor = UIColor.white.cgColor
        product_Image2.layer.borderWidth = 1
        product_Image3.layer.borderColor = UIColor.white.cgColor
        product_Image3.layer.borderWidth = 1
        
        
        Brand_Text.delegate = self
        Brand_Text.delegate = self
        
        Description_Text.delegate = self
        Description_Text.delegate = self
        
        Quantity_Text.delegate = self
        Quantity_Text.delegate = self
        
        Price_Text.delegate = self
        Price_Text.delegate = self
        
        //Price_Text.keyboardType = .numberPad
        
        // tags
        Brand_Text.tag = 1
        Description_Text.tag = 2
        Quantity_Text.tag = 3
        Price_Text.tag = 4
        
        Brand_Text.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        Description_Text.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        Price_Text.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        showCurrentDate()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    @IBAction func onTappedBackButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onTappedLarge_CheckedButton(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }

    
    @IBAction func onTappedShowCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeIn(duration: 0.3, delay: 0.3)
    }
    
    // Calendar Back View ==========================================
    @IBAction func onTappedCancelCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }

    @IBAction func onTappedDoneCalendarButton(_ sender: Any) {
        Calendar_Back_View.fadeOut(duration: 0.3, delay: 0.3)
    }
    
    // UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // User finished typing (hit return): hide the keyboard.
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        //currentTextField = textField
        switch textField.tag {
        case 1:
            if (Brand_Text.text?.characters.count)! > 0 && (Brand_Text.text?.characters.count)! < 76 {
                Brand_Len_Label.text = "\((Brand_Text.text?.characters.count)!) / 75"
            }
        case 2:
            if (Description_Text.text?.characters.count)! > 0 && (Description_Text.text?.characters.count)! < 501 {
                description_Len_Label.text = "\((Brand_Text.text?.characters.count)!) / 500"
            }
        case 3:
            if (Quantity_Text.text?.characters.count)! > 0 && (Quantity_Text.text?.characters.count)! < 76 {
                Quantity_Len_Label.text = "\((Quantity_Text.text?.characters.count)!) / 75"
            }
        default: break
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        //        switch textField.tag {
        //        case 1:
        //        default: break
        //        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        if textField == self.Price_Text {
            
            let invalidCharacters = CharacterSet(charactersIn: ".0123456789").inverted
            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
        } else {
            let invalidCharacters = CharacterSet(charactersIn: "0123456789").inverted
            return string.rangeOfCharacter(from: invalidCharacters, options: [], range: string.startIndex ..< string.endIndex) == nil
        }
    }
    
    func textFieldDidChange(_ textField: UITextField) {
        switch textField.tag {
        case 1:
            if (Brand_Text.text?.characters.count)! > 0 && (Brand_Text.text?.characters.count)! < 76 {
                Brand_Len_Label.text = "\((Brand_Text.text?.characters.count)!) / 75"
            }
            if (Brand_Text.text?.characters.count) == 0 {
                Brand_Len_Label.text = ""
            }
        case 2:
            if (Description_Text.text?.characters.count)! > 0 && (Description_Text.text?.characters.count)! < 501 {
                description_Len_Label.text = "\((Description_Text.text?.characters.count)!) / 500"
            }
            if (Description_Text.text?.characters.count) == 0 {
                description_Len_Label.text = ""
            }
        case 3:
            if (Quantity_Text.text?.characters.count)! > 0 && (Quantity_Text.text?.characters.count)! < 76 {
                Quantity_Len_Label.text = "\((Quantity_Text.text?.characters.count)!) / 75"
            }
            if (Quantity_Text.text?.characters.count) == 0 {
                Quantity_Len_Label.text = ""
            }
        case 4:
            if (Price_Text.text?.characters.count) == 0 {
                Price_fees_Label.text = ""
                return
            }
            
            let price: Double = Double(Price_Text.text!)!
            
            if price > 0.0 {
                Price_fees_Label.text = "£\(String(format: "%.2f", price * 0.9352)) after fees"
            }
            
        default: break
        }
    }

    // Calendar =====================================================
    //Select Point
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        
        if monthPosition == .next || monthPosition == .previous {
            calendar.setCurrentPage(date, animated: true)
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd MMM yyyy"
        
        str_selectDate = dateFormatter.string(from: date)
        Expiry_Text.text = str_selectDate
        
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: date)
        
        let weekday = date.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: date)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: date)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func showCurrentDate() {
        
        let todayDate = Date()
        let dateFormatter_month = DateFormatter()
        dateFormatter_month.dateFormat = "MMM"
        let nameOfMonth = dateFormatter_month.string(from: todayDate)
        
        let weekday = todayDate.dayOfTheWeek()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: todayDate)
        //let month = calendar.component(.month, from: date)
        let day = calendar.component(.day, from: todayDate)
        
        WeekDay_Label.text = weekday
        Date_Label.text = "\(day)"
        //Month_Label.text = "\(month)"
        Month_Label.text = nameOfMonth
        Year_Label.text = "\(year)"
    }
}
