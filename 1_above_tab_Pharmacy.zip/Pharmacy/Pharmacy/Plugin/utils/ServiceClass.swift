//
//  ServiceClass.swift
//  Wealth
//
//  Created by Rohit Ajmera on 12/17/16.
//  Copyright © 2016 Rohit Ajmera. All rights reserved.
//

import UIKit
import AFNetworking

class Global: NSObject {
    
    let IDIOM = UI_USER_INTERFACE_IDIOM()
    let IPAD =  UIUserInterfaceIdiom.pad
    let IPHONE = UIUserInterfaceIdiom.phone
    
    let kOFFSET_FOR_KEYBOARD:Float = 80.0
    static let APP_TIMEOUT:TimeInterval = 100.0
    
    let APIHEADER      =   "http://35.177.9.16:8080/"

    let USER_SIGNUP    =   "user/signup"
    let USER_LOGIN     =   "user/login"
    
    let RESET_PASS     =   "user/reset_password"
    let FORGOT_PASS    =   "user/forgot_password"
    
    let CHANGE_PHOTO   =   "user/change_photo"
    let CHANGE_PROFILE =   "user/change_profile"
    
    let SET_FAVORITE   =   "user/set_favorite"
    
    // category, restaurant, review
    let Explorer_Main   =  "category/get_main_cat"
    let More_Category   =  "category/get_header_cat"
    let Sub_Category    =  "category/get_sub_cat?id="
    
    // question
    let Get_Questions   =  "question/get_questions"
    
    // Zirafer
    let Get_Zirafers    =  "zirafer/get_zirafers"
    let get_ziraferProfile  = "zirafer/get_zirafer?id="
}


class ServiceClass: NSObject {
    
    let GlobalVar = Global()
  
    func servicePostMethodWithAPIHeaderValue(apiValue: String, headerValue: String, parameters params: NSObject, timeout: TimeInterval = Global.APP_TIMEOUT, completion completionBlock: (((NSDictionary)?) -> Void)?) -> () {
        
        let url = "\(apiValue)\(headerValue)"
        let manager = AFHTTPSessionManager()
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("DSFKJ#lmkdsf@&&", password: "5sdf42151SDF5JKNHDSF@#LMDSFL")
        manager.requestSerializer.timeoutInterval = timeout
        manager.responseSerializer = AFJSONResponseSerializer()
        
        manager.post(url, parameters: params, progress: { (nil) in
            
        }, success: { (task, responseObject) in
            
            let responseObject = responseObject as! NSDictionary
            completionBlock!(responseObject)  
            
        })
        
        { (task, error) in
            
            ProgressHUD.dismiss()
            
            let alertView = UIAlertController(title: "", message: "\(error.localizedDescription)", preferredStyle: .alert)
                            alertView.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) -> Void in
            
                            }))
                            alertView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
                            UIApplication.shared.delegate?.window!!.rootViewController?.present(alertView, animated: true, completion: nil)

        }
        
    }
    
    
     /*func servicePostMethodWithAPIHeaderValue_NSDictionary(apiValue: String, headerValue: String, parameters params: [NSObject : AnyObject], timeout: TimeInterval = Global.APP_TIMEOUT, completion completionBlock: (((NSDictionary)?) -> Void)?) -> () {
        
        let url = "\(apiValue)\(headerValue)"
        let manager = AFHTTPSessionManager()
        manager.requestSerializer = AFJSONRequestSerializer()
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("DSFKJ#lmkdsf@&&", password: "5sdf42151SDF5JKNHDSF@#LMDSFL")
        manager.requestSerializer.timeoutInterval = timeout
        manager.responseSerializer = AFJSONResponseSerializer()
        
        manager.post(url, parameters: params, progress: { (nil) in
            
        }, success: { (task, responseObject) in
            
            let responseObject = responseObject as! NSDictionary
            
            completionBlock!(responseObject)
            
        }) { (task, error) in
            
            ProgressHUD.dismiss()
        }
        
    }*/

    func serviceGetMethodWithAPIHeaderValue(apiValue: String, headerValue: String, fields: String, completion completionBlock: @escaping (NSDictionary) -> Void) {
        let requestLink = "\(apiValue)\(headerValue)"
        let urlWithParams = requestLink + fields
        let myUrl = NSURL(string: urlWithParams);
        print(urlWithParams)
        let request = NSMutableURLRequest(url: myUrl! as URL)
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest, completionHandler: {
            data, response, error in
            if error != nil
            {
                ProgressHUD.dismiss()
                print("error=\(error)")
                return
            }
            do {
                let dictonary = try JSONSerialization.jsonObject(with: data!, options: []) as? [String:AnyObject]
                completionBlock(NSDictionary(dictionary: dictonary!))
                    
            } catch let error as NSError {
                print(error)
            }
        })
        task.resume()
    }
    
    /*
    func serviceGetMethodWithAPIHeaderValue(apiValue: String, headerValue: String, fields: String, completion completionBlock: @escaping (NSDictionary) -> Void) {
        
        let requestLink = "\(apiValue)\(headerValue)"        //\(fields)/"
        
        let manager = AFHTTPSessionManager()
        manager.requestSerializer = AFJSONRequestSerializer()
        
        manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "content-type")
        //manager.requestSerializer.setValue("application/json", forHTTPHeaderField: "Accept")
        //manager.requestSerializer.setAuthorizationHeaderFieldWithUsername("DSFKJ#lmkdsf@&&", password: "5sdf42151SDF5JKNHDSF@#LMDSFL")
        
        manager.requestSerializer.timeoutInterval = 100.0
        manager.responseSerializer = AFJSONResponseSerializer()
        
        manager.get(requestLink, parameters: fields, progress: { (nil) in
            
        }, success: { (task, responseObject) in
            
            let responseObject = responseObject as! NSDictionary
            
            completionBlock(responseObject)
            
        }) { (task, error) in
            
            //ProgressHUD.dismiss()
            
            let alertView = UIAlertController(title: "", message: "\(error.localizedDescription)", preferredStyle: .alert)
            alertView.addAction(UIAlertAction(title: "OK", style: .default, handler: { (alertAction) -> Void in
                
            }))
            alertView.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            UIApplication.shared.delegate?.window!!.rootViewController?.present(alertView, animated: true, completion: nil)
            
        }
        
    }*/
}

