//
//  Config.swift
//  Onefortheride
//
//  Created by mac on 25/11/15.
//  Copyright © 2015 mac. All rights reserved.
//

import Foundation
import MapKit

/*
 enum ProfileViewIndex: Int {
 case RESTAURANTS    = 0
 case SEARCHES       = 1
 case FRIENDS        = 2
 case REWARDS        = 3
 }*/

enum StorySegues: String {

    case FromSignInToSignUp        =    "SignInToSignUp"
    case FromSignToMain            =    "SignToMain"
    
    case FromSignUpToGPhcSubmit    =    "SignUpToGPhcSubmit"
    
    case FromGPhcSubmitToVerification   =   "GPhcSubmitToVerification"
    
    case FromVerificationToMain    =    "VerificationToMain"
    
    case FromMainToBuySub          =    "MainToBuySub"
    case FromMainToSellSub         =    "MainToSellSub"
    case FromMainToSellAdd         =    "MainToSellAdd"
    case FromMainToSold            =    "MainToSold"
}

enum UserDialogs: String {
    /*case SigninIncorrect        = "Your login information is incorrect."
     case EmailIsTaken           = "That email address is already taken."*/
    case CompleteRequireFields  = "Please complete all required fields."
    /*case RequireEmailAddress    = "Email address should be required."
     case PasswordRecoveryFailed = "Recovery is failed. Try again."*/
    case PasswordNotMatch       = "Passwords do not match"
    case FacebookSignOK       = "success Login with Facebook"
    case GoogleSignOK       = "success Login with Google"
}

// ----------------------------------------------------------------------------------------------
// Center Map

let CENTER_MAP_LAT = 56.949000 as CLLocationDegrees
let CENTER_MAP_LON = 24.105000 as CLLocationDegrees

// ----------------------------------------------------------------------------------------------
// Zoom Map

// 320 PIXEL
let SCREEN_320_LAT = 0.055 as CLLocationDegrees
let SCREEN_320_LON = 0.055 as CLLocationDegrees

// 375 PIXEL
let SCREEN_375_LAT = 0.050 as CLLocationDegrees
let SCREEN_375_LON = 0.050 as CLLocationDegrees

// 414 PIXEL
let SCREEN_414_LAT = 0.045 as CLLocationDegrees
let SCREEN_414_LON = 0.045 as CLLocationDegrees

// iPad
let SCREEN_IPAD_LAT = 0.025 as CLLocationDegrees
let SCREEN_IPAD_LON = 0.025 as CLLocationDegrees

// Zoom Level on Detail View
let DETAIL_ZOOM_LAT = 0.03 as CLLocationDegrees
let DETAIL_ZOOM_LON = 0.03 as CLLocationDegrees



















