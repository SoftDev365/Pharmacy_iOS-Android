//
//  Global.swift
//  Amoureuse
//
//  Created by LEE on 3/30/17.
//  Copyright © 2017 LEE. All rights reserved.
//

import Foundation
import UIKit


//By SignUp to Main Page
var g_ByLoginSignUp: Bool = false

var g_email: String = ""
var g_password: String = ""

var g_BoughtORBuy_Flag: Bool = false // false: Buy, true: Bought









//for pop remove
var g_numerOfpage_Flag: Int = 0
//var g_numerOfpage_nearMe_Flag: Bool = false

// for Profile To Question Flag
var g_profileToquestion: Bool = false

//for Sort in pick page
var g_sort_int: Int = 0



// Frist Vist ---------------------------------
var g_FristVist_Main: Bool = true
var g_FristVist_More: Bool = true

//for profile favorite ------------------------
struct category_Info{
    var id:                  Int
    var name:                String
    var type:                String
}

//Exprorer Page Category
var g_Main_Category_Array:   Array<category_Info>   = Array<category_Info>()
var g_More_Category_Array:   Array<category_Info>   = Array<category_Info>()

//var g_subTitleLabel:         String = ""
var g_subTitleLabel_Temp:    String = "Temp"
var g_subID:                 Int    = -1
var g_Sub_Category_Array:    Array<category_Info>   = Array<category_Info>()

// More
var g_MoreCategory_current_Select: Int = -1

//Questions -----------------------------------
struct question_Info{
    var id:                  Int
    var question:            String
}
struct answers_Info{
    var id:                  Int
    var name:                String
}
struct Nearme_Info{
    var questions:           question_Info
    var answers            = [answers_Info]()
}
var g_Nearme_Array:         Array<Nearme_Info>      = Array<Nearme_Info>()


//Zirafers page's collection data ----------------------------------------------
struct zirafer_Info {
    var id: Int
    var name: String
    var profession: String
    var quote: String
    var social_link = [String]()
}
var g_zirafers_Array:        Array<zirafer_Info>   = Array<zirafer_Info>()
var g_zirafersTozirProfile_selectedIndexNumber_Id: Int = -1

// Zirafer profile photo and review --------------------------------------------
struct top_picks_Info {
    var id: Int
    var zirafer_id: Int
    var rest_id: Int
    var description: String
}
struct reviews_Info {
    var id: Int
    var zirafer_id: Int
    var rest_id: Int
    var review: String
    var rating = [Double]()
}
struct restaurants_Info {
    var id: Int
    var name: String
    var rating: Double
    var price: Int
    var phone_number: String
    
    var category_id = [Int]()
    var opening_hours = [String]()
    var pictures = [String]()
    var location = [0.0, 0.0]
}
struct Zir_restaurants_Info {
    var id: Int
    var name: String
}

struct zirafer_Profile_Info {
    var info: zirafer_Info
    var top_picks = [top_picks_Info]()
    var reviews = [reviews_Info]()
    var restaurants = [restaurants_Info]()
    
    var Zir_restaurants = [Zir_restaurants_Info]()
}

var g_Init_Temp: zirafer_Info = zirafer_Info(id: -1, name: "", profession: "", quote: "", social_link: [])
var g_zirafer_Profile: zirafer_Profile_Info = zirafer_Profile_Info(info: g_Init_Temp, top_picks: [], reviews:[], restaurants: [], Zir_restaurants: [])


























//adminView
var g_MenuCurSel: Int = 0
var g_LoginFlag:   Bool = false

//=====================================================================================
// Firebase
//var g_UID: String = ""

//=====================================================================================
struct ProfileInfo{
    
    var id:             Int
    
    var email:          String
    var type:           String
    var name:           String
    var quote:          String
    
    var avatarUrl:      String
    var avatarimage:    UIImage
    
    var home:           Array<String> = Array<String>()
    var user_rest:      Array<category_Info> = Array<category_Info>()
}
var g_ProfileInfo: ProfileInfo = ProfileInfo(
    
    id:     -1,
    email:  "",
    type:   "", // "e", "f", "g"
    name:   "",
    quote:  "",
    
    avatarUrl:  "",
    avatarimage: UIImage(named: "AnonymousImag.png")!,
    
    home: [],
    user_rest: []
)
























